import type { ReactNode } from 'react';

type InternalHeaderProps = {
  activePath: string;
  tone?: 'light' | 'dark';
};

const navItems = [
  { label: 'WORK', href: '/#selected-works' },
  { label: 'ATLAS', href: '/atlas' },
  { label: 'MARKETS', href: '/markets' },
  { label: 'METHOD', href: '/method' },
  { label: 'ABOUT', href: '/about' },
  { label: 'RESUME', href: '/resume' },
  { label: 'AI INFO', href: '/ai-information' },
  { label: 'CONTACT', href: '/#contact' },
] as const;

export function InternalHeader({ activePath, tone = 'light' }: InternalHeaderProps) {
  const isDark = tone === 'dark';
  
  const textClass = isDark ? 'text-[#f1efe8]' : 'text-ink';
  const textMutedClass = isDark ? 'text-[#f1efe8]/54' : 'text-ink/54';
  const textMutedNavClass = isDark ? 'text-[#f1efe8]/58 hover:text-[#f1efe8]' : 'text-ink/58 hover:text-ink';
  const bgClass = isDark ? 'bg-[#080807]/82' : 'bg-[#f1efe8]/82';
  const borderClass = isDark ? 'border-[#f1efe8]/12' : 'border-ink/12';
  const borderContactClass = isDark ? 'border-[#f1efe8]/28' : 'border-ink/28';
  const textContactClass = isDark ? 'text-[#f1efe8]/75 hover:text-[#f1efe8]' : 'text-ink/75 hover:text-ink';

  return (
    <header className="sticky top-0 z-50 mx-auto w-full max-w-[1480px] px-4 py-6 md:px-8 xl:px-10">
      <div className={`grid items-start gap-5 border-b ${borderClass} ${bgClass} pb-5 text-[10px] uppercase tracking-[0.3em] backdrop-blur-sm md:grid-cols-[1fr_auto_1fr]`}>
        <a href="/" id="header-brand-link" className="hover-target" data-cursor-text="HOME">
          <span className={`block font-medium ${textClass}`}>SULAYMAN BOWLES</span>
          <span className={`mt-2 block font-serif text-sm italic normal-case tracking-normal ${textMutedClass}`}>
            Technical SEO · AI Search · Finance/Data
          </span>
        </a>
        
        <nav className="flex flex-wrap items-center gap-x-3 gap-y-2 md:justify-center md:gap-x-5" aria-label="Main navigation">
          {navItems.map((item) => {
            const active = activePath === item.href || (item.href === '/ai-information' && activePath === '/ai-information');
            const cleanId = `header-nav-${item.label.toLowerCase().replace(/\s+/g, '-')}`;
            
            return (
              <a
                key={item.href}
                href={item.href}
                id={cleanId}
                data-cursor-text={item.label}
                className={`hover-target relative group overflow-visible px-3 py-1 transition-colors ${active ? textClass : textMutedNavClass}`}
              >
                <span className="block transition-transform duration-500 will-change-transform group-hover:px-2">
                  {item.label}
                </span>
                <span className={`absolute left-0 top-1 transition-opacity duration-300 ${active ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'} ${textClass}`}>
                  [
                </span>
                <span className={`absolute right-0 top-1 transition-opacity duration-300 ${active ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'} ${textClass}`}>
                  ]
                </span>
              </a>
            );
          })}
        </nav>
        
        <a 
          href="/#contact" 
          id="header-contact-link" 
          data-cursor-text="CONTACT" 
          className={`hover-target flex items-center gap-4 justify-self-start ${textContactClass} transition-colors md:justify-self-end`}
        >
          <span className={`h-7 w-7 rounded-full border ${borderContactClass} flex-shrink-0`} />
          <span>CONTACT</span>
        </a>
      </div>
    </header>
  );
}

export default InternalHeader;
