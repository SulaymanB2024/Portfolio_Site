Seven-study model package

Authored observations and assumptions retain their October 12–13, 2026 cutoffs. No credentials, live data or external Python packages are needed for the core calculations.

From the extracted directory:
  python3 model.py
  python3 pitches/models.py
  python3 pitches/test_models.py
  python3 pitches/ramp/model.py
  python3 pitches/flock-safety/model.py
  python3 pitches/elevenlabs/model.py
  python3 pitches/elevenlabs/verify_model.py
  node --test pitches/companion/scenario-math.test.mjs

For the browser companion, serve pitches/companion over HTTP and open startup-models.html. Keep its five runtime files together.

The figures and executed notebooks preserve the prepared edition. Plot/notebook authoring requires the versions in requirements.txt from the original repository. Author/export scripts that reference the full portfolio directory require that full checkout. They are not necessary to recompute the core economics.
