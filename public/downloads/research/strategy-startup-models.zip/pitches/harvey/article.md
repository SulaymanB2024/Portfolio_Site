# Harvey: Who Keeps the Value of Faster Legal Work?

Harvey could own more of the legal workflow. I test how recovered time becomes customer profit and what the $15.5 billion financing benchmark requires.

The interesting question about Harvey is what happens after a lawyer finishes the work faster. A client may receive an answer sooner. A firm may deliver a fixed-fee matter at lower cost, recover time previously written off, or take on work it would otherwise decline. Harvey earns a durable business when enough of that benefit becomes a reason to renew and spend more.

I can see a strong company in that mechanism. I am less comfortable with the price already attached to it. Harvey announced a $550 million financing at a $15.5 billion valuation on September 9, 2026. At that benchmark, an illustrative investment needs a much larger outcome than “lawyers find the tool useful.” With 25% future dilution, a 20% annualized return over five years requires about $51.4 billion of exit equity value.

My pitch is conditional: Harvey could become the place legal work is assembled, reviewed, and reused. I would want to own that business if retained customer value, delivery economics, and entry terms support the return. The latest financing headline alone does not establish any of those three conditions.

## Faster work changes the economics unevenly

Time saved is an intermediate result. On a fixed-fee engagement, doing the same accepted work with fewer resources can improve the firm's economics. On non-billable work, recovered time can create capacity. On work billed by the hour, fewer collectible hours can reduce revenue unless the firm has another way to capture the benefit.

That last case is not an argument that firms will reject AI. Clients can demand faster delivery, partners can reduce write-offs, and new fee arrangements can reward better execution. It does mean that I cannot value every saved hour at the firm's billing rate. I need to know what kind of hour disappeared and what happened to the capacity it released.

The distinction also changes who buys the product. An in-house department may value avoided external fees or additional work completed with a fixed team. A law firm may value capacity to serve more clients, a better fixed-fee margin, or improved service. A product can succeed with both buyers, but the value proof should follow their different economics.

Harvey's own [law-firm ROI calculator](https://www.harvey.ai/roi-calculator/law-firm) describes converting recovered time into billable work and profit. It also states that the results are general estimates and that example prices are illustrative. That is the right place to begin the analysis. The conversion from time to profit is the variable I would investigate most closely.

## Put a value bridge under the renewal

Consider a hypothetical 100-lawyer deployment. I assume 60 active users, each recovering six hours per week across 46 weeks. Those hours come only from non-billable, written-off, or fixed-fee work where reducing time does not remove an otherwise collectible hourly fee. I subtract 20% of gross saved time for additional review and rework before crediting any capacity.

That leaves 13,248 hours a year. I assume a $2,400 annual license per purchased seat and $50,000 of first-year implementation, for $290,000 of total first-year cost. These are my scenario inputs, not Harvey's quoted prices or observed deployment results. The firm's existing payroll is not treated as a cash saving.

The next assumption is decisive: what share of the released hours produces incremental contribution? I use $200 of contribution per monetized hour after the incremental costs of the additional work. That is deliberately different from a billing rate. A full hour of revenue can require additional delivery cost and may not be collectible in full.

**What fraction of released time earns incremental contribution?**

| Assumed monetization | Incremental contribution | First-year total cost | Net first-year benefit |
| --- | --- | --- | --- |
| 10.0% | $264,960 | $290,000 | −$25,040 |
| 25.0% | $662,400 | $290,000 | $372,400 |
| 40.0% | $1,059,840 | $290,000 | $769,840 |

Entirely hypothetical 100-seat deployment. 60% adoption; 6 eligible hours/week × 46 weeks; 20% additional review; $200 contribution/monetized hour. $2,400 license/seat/year and $50,000 implementation are assumed, not Harvey pricing. Collectible hourly fees and unchanged payroll are not counted as savings.

![At 10% monetization the hypothetical deployment loses $25,040 in year one; 25% gains $372,400 and 40% gains $769,840 after $290,000 of assumed costs.](../../figures/harvey-time-to-contribution.png)

A hypothetical deployment turns eligible recovered time into incremental contribution only when the firm monetizes it. These are authored inputs, not Harvey prices, measured time savings, or reported ROI.

At 10% monetization, the deployment does not cover its first-year cost. At 25%, it generates $372,400 of modeled net benefit. The break-even share is about 10.9%. That sounds attainable, but it is a conditional result: the starting assumptions already require active use, meaningful time savings, and an eligible kind of work.

I would verify the bridge on completed matters. How much review was required? Was the saved time on work that previously generated a collectible fee? Did the firm actually complete additional work, avoid a contractor or hire, or improve the margin on the same fixed-fee matter? If capacity was merely available, I would report available capacity. I would not rename it profit.

Adoption and review can undo a persuasive payback calculation. If only 30 of the 100 purchased seats are active, the same 25% monetization assumption yields just $41,200 of first-year net benefit. At 60 active seats it yields $372,400. The license bill has not changed; the usable capacity has. I would measure those two inputs before trusting a firm-wide average of hours saved.

**Required monetization changes with adoption and review**

| Active share of 100 purchased seats | 20% added review | 40% added review | 60% added review |
| --- | --- | --- | --- |
| 30.0% | 21.9% | 29.2% | 43.8% |
| 60.0% | 10.9% | 14.6% | 21.9% |
| 90.0% | 7.3% | 9.7% | 14.6% |

Hypothetical share of net released hours that must produce contribution to cover $290,000 first-year cost. The six-hour weekly saving and $200 contribution/hour remain fixed. These are payback requirements, not observed adoption or probabilities.

This is also where a strong renewal can become misleading. A client may buy seats widely during an AI rollout, then consolidate them once actual usage becomes clear. I would want the renewal after that consolidation, along with the change in spending and accepted work. A large initial contract is weaker evidence of a durable business than a customer that expands after learning its own economics.

## What Harvey could own

I do not think a permanent lead in the underlying model is the most defensible version of the thesis. Models can improve, and competitors can incorporate those improvements. The business I would want Harvey to build is a system that knows the matter, the documents available to the team, the firm's preferred work product, and the review process required before it goes to a client.

The value of that system would come from accumulated workflow: finding the right material, producing a useful draft, making the reasoning inspectable, and carrying corrections into the next task. A customer would then be replacing a process, with its permissions and habits, rather than switching between two text generators. That can make the product harder to displace. It does not make the customer's confidential data a freely reusable training asset; the advantage has to respect contractual rights and the boundaries between matters.

Harvey's current product set includes document analysis, research, shared workspaces, and organizational analytics. The [platform overview](https://www.harvey.ai/platform) describes that direction. Whether the pieces create a compounding advantage is a separate question. I would look for lower review effort, repeat use across matters, and expansion within existing customers as the workflow becomes established.

The company's reported adoption is substantial. In August 2025, it disclosed more than $100 million of ARR and more than 500 customers. In the September 2026 financing announcement, it said 80% of Am Law 100 firms used Harvey. These are company disclosures from different dates and different measures. They establish breadth and momentum; they do not tell me current ARR, seat penetration inside those firms, or the profitability of serving them. [Three-year update](https://www.harvey.ai/blog/harveys-three-year-anniversary), [latest financing](https://www.harvey.ai/blog/harvey-raises-dollar550m-at-a-dollar155b-valuation-to-help-legal-teams-own-their-intelligence).

If most major firms already have some use of the product, the next stage of growth increasingly depends on deeper adoption, new practices, in-house buyers, or other markets. Counting another prominent logo becomes less informative than understanding how the customers already acquired change their spending.

## More capable work can cost more to deliver

A legal agent may search a large document set, call tools repeatedly, revise its answer, and ask for review. The relevant unit cost is the cost of accepted work, including unsuccessful attempts. A cheaper token is helpful, but it cannot settle the economics if the system uses many more tokens or produces work that needs expensive correction.

Harvey's August 2026 [Tenet research preview](https://www.harvey.ai/blog/post-training-update-harvey-tenet) describes post-training an open-weight model for legal work, including more efficient reasoning and tool use. I view that as evidence that the company is working on an important cost lever. The research does not disclose the gross margin of Harvey's customer business.

To show the sensitivity, I normalize an illustrative company at $400 million ARR and the same assumed $2,400 annual seat price. That corresponds to roughly 166,667 purchased seats. With 65% active, I test annual model-and-workflow costs of $250, $900, and $1,800 per active seat, plus other delivery costs equal to 15% of ARR. None of these inputs is an estimate of Harvey's actual cost or active-seat count.

**The same illustrative ARR with different costs of active use**

| Model/workflow cost / active seat / year | Modeled delivery gross profit | Modeled gross margin |
| --- | --- | --- |
| $250 | $313m | 78.2% |
| $900 | $242m | 60.6% |
| $1,800 | $145m | 36.2% |

$400m ARR is an illustrative normalization, not verified current Harvey ARR. Assumed $2,400 annual seat price, 65% active licenses and other delivery costs of 15% ARR. Selling, R&D and administration remain below gross profit. No actual Harvey margin or inference cost is inferred.

The resulting hypothetical gross margins range from 78.2% to 36.2%. Selling, research, and administration still have to be funded below that line. The same ARR can therefore represent very different earnings potential. A lower-margin business might grow quickly and remain valuable, but it should not receive a software valuation merely because it sells subscriptions.

There is an uncomfortable incentive inside seat pricing too. Low usage can make delivery margin look better in the short term because the purchased license generates revenue without much inference cost. It can weaken renewal later. I would examine adoption, customer value, and delivery cost together rather than choose the metric that looks best in isolation.

## Work backward from $15.5 billion

The September funding announcement does not report current ARR. I use $200 million, $400 million, and $600 million only as starting normalizations for the hurdle analysis. They are not three estimates of a hidden actual number. The required exit equity value can be calculated without choosing any of them.

For a hypothetical investor entering at an equity benchmark of $15.5 billion, I assume five years, a 20% annualized return, and a 25% reduction in the investor's ownership from future issuance. The required exit value is $15.5 billion × 1.20⁵ ÷ 0.75, or $51.43 billion. At an assumed exit equity value of twenty times ARR, the company needs $2.57 billion of ARR.

**ARR required for a 20% annualized five-year return**

| Assumed exit equity / ARR | Required exit equity | Required exit ARR |
| --- | --- | --- |
| 10× | $51.425bn | $5.143bn |
| 15× | $51.425bn | $3.428bn |
| 20× | $51.425bn | $2.571bn |
| 25× | $51.425bn | $2.057bn |

Hypothetical entry at $15.5bn equivalent equity value; 25% future ownership dilution; no fees, distributions or preference waterfall. Multiples are assumptions. Headline funding valuation does not establish an actual security's entry price or rights.

![A 20% five-year return after 25% ownership dilution needs $51.43bn exit equity value, equivalent to $5.14bn ARR at 10 times or $2.57bn at 20 times.](../../figures/harvey-return-hurdle.png)

Reverse underwriting at the $15.5bn financing benchmark. Exit equity/ARR multiples are assumed; security rights, fees and a preference waterfall are not modeled. The calculation does not require a claim about current Harvey ARR.

Starting at the illustrative $400 million, reaching $2.57 billion in five years requires about 45% annual ARR growth. Starting at $200 million requires considerably more; starting at $600 million requires less. That is why current verified ARR matters so much to this pitch. An attractive story cannot fill in the starting denominator.

## Three paths from the same starting point

For a second view, I compound the $400 million normalization under three paths. At 25% annual growth and ten times exit ARR, the modeled investor loses about 10.0% a year after dilution. At 40% growth and twenty times ARR, the return is 15.8%. At 55% growth and twenty-five times ARR, it is 34.1%. These are deliberately conditional paths, with no assigned likelihood.

**Conditional paths from an illustrative $400m starting ARR**

| Path | ARR growth / year | Exit ARR | Exit equity / ARR | Investor annual return |
| --- | --- | --- | --- | --- |
| Downside | 25.0% | $1.221bn | 10× | -10.0% |
| Base | 40.0% | $2.151bn | 20× | 15.8% |
| Upside | 55.0% | $3.579bn | 25× | 34.1% |

The $400m starting ARR is not a company disclosure or an estimate. Five-year scenarios; 25% ownership dilution; entry benchmark $15.5bn. No probability weights, security preferences, fees, dividends or secondary premiums. These are underwriting conditions, not forecasts.

The multiples are assumptions about future equity value relative to run-rate revenue, not current comparable-company evidence. They also assume that net cash and debt do not require another adjustment. I have not modeled preference waterfalls, transaction fees, distributions, or a premium charged by a secondary seller. The financing announcement does not give me the information needed to turn its headline into the return on a particular security.

Future dilution is also tied to the operating result. If serving customers consumes more cash than expected, the company may need more financing. A 25% assumption then fails alongside the margin assumption. I would connect the growth plan to cash needs before treating dilution as an independent, fixed adjustment.

## The competitor already has a route to the buyer

The strongest challenge to my positive thesis is that a good legal workflow is valuable to other vendors too. Thomson Reuters is integrating research and drafting into CoCounsel Legal using Westlaw and Practical Law, with review steps and document workflows. Its [2026 product update](https://legal.thomsonreuters.com/blog/behind-the-build-of-the-next-generation-of-cocounsel-legal/) describes the same broad movement toward completed work rather than isolated answers.

That creates a serious countercase. A customer that already relies on an incumbent's content and software can get a more capable workflow through an existing relationship. Harvey has to earn enough incremental value to justify another contract and another system. A head start in adoption does not remove that purchasing decision.

Nor would I let a benchmark score settle it. Harvey's [Legal Agent Benchmark](https://www.harvey.ai/blog/introducing-harveys-legal-agent-benchmark) evaluates reviewable work against detailed criteria, including an all-pass standard. That is more relevant than a quiz about legal knowledge. It still cannot establish the customer's realized economics, the review cost of live matters, or superiority across all the work a firm performs.

The benchmark matters most if improvements reduce the cost of producing accepted work in customer deployments. A gain that needs more review, applies to a narrow task set, or disappears on the firm's documents may not reach the renewal decision.

## What would make me invest

I would advance the pitch if verified cohorts showed broad paid use, strong retention after seat consolidation, and expansion tied to completed work. I would want a measured route from that work to customer contribution, along with delivery gross margin after models, tool calls, support, and deployment. Finally, I would need the security's rights and entry economics to support the return hurdle.

I would become more cautious if customers retained the brand but cut seats, if accepted work remained expensive to review, or if the best workflows were available through an incumbent at a much lower incremental price. A rapid rise in usage could strengthen the customer thesis and weaken the margin thesis at the same time. I would not assume one settles the other.

At the latest disclosed financing benchmark, I would require that operating evidence before committing. Harvey has a credible opportunity to own more of the legal workflow. The price asks it to capture a substantial part of the resulting value, grow for years, and leave enough of the outcome for the investor. Those are the claims I would underwrite.

## Scope

September 9, 2026 financing is the entry benchmark, not an observable common-share price. $200m/$400m/$600m starting ARR, prices, adoption, costs, future growth and margins are illustrative, not verified current Harvey data. Customer value and return models are separate. No security rights, fees or preference waterfall is inferred.

## Sources

- [September 2026 financing](https://www.harvey.ai/blog/harvey-raises-dollar550m-at-a-dollar155b-valuation-to-help-legal-teams-own-their-intelligence) — Harvey, 2026-09-09; verified 2026-10-12. Company announces $550m at $15.5bn and use by 80% of Am Law 100. No current ARR, audit, cash balance or security terms in this release. Model treats the valuation as an equivalent equity benchmark, not a purchasable common-share price.
- [Three-year business update](https://www.harvey.ai/blog/harveys-three-year-anniversary) — Harvey, 2025-08-04; verified 2026-10-12. Company reported more than $100m ARR and more than 500 customers at this older checkpoint. Does not establish October 2026 ARR.
- [Law-firm ROI calculator](https://www.harvey.ai/roi-calculator/law-firm) — Harvey, Current page; verified 2026-10-12. Describes conversion of recovered time into work/profit and explicitly illustrative pricing. Our deployment inputs and ROI are independently authored scenarios, not extracted calculator results.
- [Platform overview](https://www.harvey.ai/platform) — Harvey, Current page; verified 2026-10-12. Product scope: agents, document analysis, research, workspaces and analytics. Marketing direction does not establish comparative superiority or actual customer profit.
- [Tenet research preview](https://www.harvey.ai/blog/post-training-update-harvey-tenet) — Harvey, 2026-08-20; verified 2026-10-12. Company research on post-training, efficient reasoning and tool use. Does not disclose production delivery margin or the unit cost of accepted customer work.
- [Legal Agent Benchmark](https://www.harvey.ai/blog/introducing-harveys-legal-agent-benchmark) — Harvey, 2026-05-06; verified 2026-10-12. Matter-based work-product evaluation and all-pass criteria. No benchmark result is converted into a claim of live-matter reliability or ROI.
- [CoCounsel Legal 2026 product update](https://legal.thomsonreuters.com/blog/behind-the-build-of-the-next-generation-of-cocounsel-legal/) — Thomson Reuters, 2026-08-24; verified 2026-10-12. Primary competitor description of research, drafting, review and document workflows. Does not establish comparative market share or pricing.
