# Flock Safety: The Renewal Has to Pay for the Camera

Flock's most attractive promise to a customer creates its hardest obligation to an investor. A public agency can buy an annual service instead of assembling cameras, connectivity, maintenance and investigative software itself. The vendor has to make that bundle work in the street, keep it working and earn the next budget approval.

I see a potentially strong installed-service business here. I would underwrite it through the cash recovered from each deployment cohort. A subscription label is useful evidence of the billing relationship; it does not settle the cost of delivering the relationship. The decisive question is how much cash a camera leaves behind before it fails, gets replaced or loses permission to operate.

## One invoice, several economic jobs

Flock's [current pricing page](https://www.flocksafety.com/pricing) describes an annual bundle covering devices, software, LTE connectivity, installation, maintenance and support. Quotes depend on the deployment. This makes the offer easier for a buyer to administer and gives Flock several responsibilities that continue after the sale.

I would split those responsibilities into four economic jobs: acquiring the account, deploying the equipment, operating it reliably and retaining the contract. A good result in one job can conceal a poor result in another. Annual advance collection might fund installation, for example, while a growing replacement burden consumes the apparent margin later. An account can expand its bill while also adding installation work and field-service demand.

A municipal record makes the distinction tangible. The [May 28, 2025 Arden Hills agenda packet](https://www.cityofardenhills.org/AgendaCenter/ViewFile/Agenda/_05282025-1325?packet=true) describes a proposed regional deployment of nineteen readers at a $3,000 annual lease rate per camera. It separately says the sheriff's office intended to pay installation costs. That is a dated proposal, not proof of a universal current price or executed contract. It is enough to show why I would read the actual order and its funding arrangements before treating a subscription as a comparable unit.

The buyer is also purchasing an operating relationship. A functioning camera can become part of an agency's routine; an unreliable one can turn into repeated visits, support tickets and political explanations. I would want uptime measured across the full installed base and the cash cost of sustaining it. A polished software demonstration answers neither question.

## The network can help the sale and complicate the renewal

The strategic case is that connected evidence can be more useful than isolated equipment. Compatible workflows, permitted sharing and familiar training could make an existing deployment easier to expand than replace. That is a plausible source of customer value and switching friction. I would regard it as an investment hypothesis until renewal and expansion cohorts demonstrate its strength.

There is a second side to the same mechanism. A customer's decision to participate affects other customers' expectations about coverage and sharing. Restrictions that preserve local confidence might limit some uses of the network; permissive sharing might make the service less acceptable to another community. The largest technically available network is not automatically the largest commercially durable network.

This is why I would separate physical coverage from authorized, useful coverage. The first counts equipment. The second asks whether a customer can use the relevant information under its approved rules. A sales presentation could emphasize the first while the renewal debate centers on the second. I would want the product and account team to explain that difference before contracting, rather than discover it during a public hearing.

For an investor, this changes the retention model. Churn may arrive through ordinary dissatisfaction with service, a budget decision or a policy decision that affects a whole local account at once. Thousands of individual units do not necessarily represent thousands of independent renewal decisions. A cohort organized only by camera installation date could miss the concentration of decision-making authority.

## A cohort that starts with the same revenue

I use a deliberately small model: one hypothetical cohort of one hundred installed units over five years. Every scenario charges $3,000 per active unit each year, without price increases or expansion. The amount resembles the dated public proposal above; it is an authored input, not an estimate of Flock's average price. All costs and retention rates below are assumptions.

**Hypothetical inputs per installed unit**

| Input | Base | Renewal pressure | Service drag |
| --- | --- | --- | --- |
| Annual subscription | $3,000 | $3,000 | $3,000 |
| Deployment cost | $2,300 | $2,300 | $3,200 |
| Acquisition cost | $700 | $700 | $1,000 |
| Annual service cost | $650 | $650 | $1,050 |
| Annual replacement reserve | $250 | $250 | $400 |
| Annual unit retention | 95% | 80% | 80% |
| Removal cost on non-renewal | $300 | $300 | $300 |

The service allowance covers an illustrative operating cost pool; the replacement reserve is a modeled cash allowance, not a reported accounting expense. Retention applies to units at annual renewal, with fractional units representing an expected cohort. No tax, corporate overhead, financing, early refunds, expansion, final shutdown cost or terminal value is included. Results therefore measure this cohort's cash contribution, not company free cash flow.

The timing is explicit. Deployment and acquisition happen at the opening, alongside first-year subscription collection. Renewal receipts arrive at the start of later years; service and replacement allowances are paid at year-end. Units that do not renew generate a removal charge at the next year's opening. That convention makes advance collection visible in the present-value calculation. It does not assume Flock actually collects or pays every contract on those dates.

In the base, the opening deployment and acquisition use $300,000. The first subscription collection also brings in $300,000. The year still ends $90,000 behind after service and replacement allowances. Billing ahead helps finance the opening; it does not eliminate the cost of serving the first year.

Year two begins with ninety-five active units. They bring in $285,000, incur $85,500 of service and reserve allowances, and leave a $1,500 removal charge for five departing units. That year's $198,000 cash contribution more than repays the first-year deficit. The cumulative balance becomes positive in year two. These are the mechanics I would want an actual cohort disclosure to explain.

## Retention and service cost move different parts of the bridge

The renewal-pressure case changes just retention from 95% to 80%. It keeps the deployment and operating inputs fixed. First-year cash remains negative $90,000 because the cohort has not yet reached renewal. The difference emerges in the cash available later, when fewer units pay the annual bill.

The service-drag case combines 80% retention with more expensive acquisition, deployment and ongoing service. The opening revenue is still $300,000. First-year cash falls to negative $265,000 and cumulative payback moves to year four. The subscription label and opening run-rate are identical to the base. Their economic content is considerably weaker.

**Hypothetical cohort results, before corporate costs**

| Result | Base | Renewal pressure | Service drag |
| --- | --- | --- | --- |
| Opening annual subscription run-rate | $300,000 | $300,000 | $300,000 |
| First-year cumulative cash | −$90,000 | −$90,000 | −$265,000 |
| Cumulative payback year | 2 | 2 | 4 |
| Five-year cumulative cash | $644,555 | $388,224 | $83,336 |
| Cash present value at assumed 12% discount rate | $507,451 | $311,944 | $52,026 |

Present value follows the stated collection/payment timing. It is the value of modeled cohort cash after initial acquisition and deployment, before corporate costs, taxes and financing. The 12% rate is an assumption, not a recommended security return or a valuation of Flock.

I would read this comparison as an argument for disclosure, not as a prediction. In this example, changing renewal assumptions removes roughly $256,000 of five-year cash; adding cost pressure removes another $305,000. The base could finance overhead and growth much more comfortably than the service-drag case. Neither figure establishes what the real business earns.

It also explains why acquisition efficiency deserves its own row. A company can reduce the equipment bill and still weaken the economics through longer procurement cycles, expensive pilots or sales effort spread across small deployments. I would count the complete acquisition cost of a cohort, including failed attempts allocated consistently, rather than divide sales expense by the most attractive installations.

[FIGURE:flock-cohort]

## A renewal objection can become a cash event

The retention risk has a concrete public example. [Ayer's September 1, 2026 announcement](https://www.ayer.ma.us/m/newsflash/home/detail/73) says its Select Board voted the previous day to terminate the Flock contract and disable and remove the technology, citing resident concerns. That establishes one decision. It does not tell me Flock's company-wide churn rate, how other customers will respond or whether the equipment had been economically productive.

What it changes is the plausibility of my downside mechanism. A community can choose to leave even if the vendor can point to a working product. For the cohort, lost subscription income and decommissioning work can arrive together. For new sales, the same debate could lengthen approvals and raise acquisition cost. I would test those channels separately; counting every public cancellation as the beginning of an inevitable collapse would be as careless as ignoring it.

There is another timing limit in my model. Annual non-renewal is gentler than an early cancellation that returns part of a prepaid bill. A cancellation clause, refund obligation or removal backlog could change the cash bridge before the next renewal date. The five-year model excludes these events rather than pretending every collected dollar is permanently earned. Actual order forms and cash receipts would be needed to size them.

An account-level stress test would also matter. I would group units by agency and common budget authority, then test a cluster leaving together. A smooth 80% expected-unit curve helps compare scenarios but understates the liquidity swings of concentrated contracts. A business financed through predictable subscription cash should show how it handles unpredictable clusters of departures.

## Guardrails belong in the product economics

Flock's [August 13, 2026 announcement](https://www.flocksafety.com/blog/flock-guardrails-address-lpr-privacy-concerns-and-police-transparency) describes a seven-day retention recommendation, offense-based sharing controls and additional oversight. It says existing customers keep their approved retention periods, and law-enforcement customers will be required to adopt Audit Assistance by year-end. Announced controls and deadlines are evidence of the product direction; they do not establish complete implementation or prevent every misuse.

The [Evidence Policy updated August 12](https://www.flocksafety.com/legal/flock-evidence-policy) describes seven-day standard retention unless the individual agreement specifies otherwise. That exception matters commercially. Buyers need a coherent account of what their own deployment will do, rather than assume a marketing default automatically changes an existing contract. I would judge sales, onboarding and support on whether that account stays consistent.

My investment view would improve if stronger controls made the service easier to authorize and renew while remaining useful. They could be part of the moat: institutional customers often need an auditable workflow as much as a capable sensor. Building that workflow requires product effort, training and review processes. I would expect a credible economic model to include their costs.

There is a temptation to treat those costs as friction that will disappear with scale. Some may decline per account through better software and standardized onboarding. Other work may grow with deployment diversity or remain necessary because a local official must make a local decision. I would separate automation opportunities from obligations that should persist. Lower costs produced by weaker oversight would not strengthen my thesis.

## The strongest case against my caution

The strongest bullish argument is that I am giving field equipment too much weight in a business whose durable value increasingly comes from the workflow. A reliable installed network, useful integrations and familiar operating procedures could support recurring revenue well beyond the cost of the original camera. Maintenance might be efficient at regional scale, and customers might buy more products without restarting the whole sales process.

That would make the base model too narrow. It has no expansion, no higher-value software attachment and no revenue from another product. A service business with demonstrated cross-selling, modest incremental acquisition cost and durable renewals could deserve a better economic interpretation than a static five-year camera cohort suggests.

I would still require the additional products to earn their own cash. A new drone deployment, video product or software module can add revenue and obligations at the same time. Attach rate alone is not enough. I would look for contribution after the installation, support and product-specific capital requirements of the bundle, with shared costs allocated consistently.

The company’s [March 13, 2025 financing announcement](https://www.flocksafety.com/blog/flock-safety-secures-major-funding) reported a $275 million raise at a $7.5 billion valuation and said ARR had surpassed $300 million. Those are historical company checkpoints. The page also displays a later template date, so I use its explicit original publication date. I do not use the old financing as a current share price or splice it into an unverified current revenue multiple.

Capital raised can support manufacturing and deployment before the cohort pays back. It also makes reported growth harder to interpret without the cash bridge: a company can fund an attractive expansion or subsidize unattractive units. My countercase would win with evidence that newer cohorts recover cash faster while maintaining service quality and renewal durability.

## What would change my judgment

I would want five views of the same installed base: initial deployment and acquisition cash; collections and refunds; annual service and replacement cash; renewal and expansion by customer authority; and removals or shutdown obligations. Those views should reconcile. A camera count, an ARR total and a gross-margin percentage measured on different populations would leave the central question open.

The comparison that would most improve my view is a newer cohort with shorter cash payback, stable uptime and stable renewal after the controls are fully adopted. That would suggest the operating system is becoming more efficient without relying on looser promises. I would then test whether expansion adds cash at a lower acquisition burden than the original sale.

The evidence that would weaken my view is the opposite combination: rising installation/support cash, concentrated customer departures and new growth that needs more capital per retained dollar. In that case, the headline subscription growth could outrun the cash available to finance it. A lower financing valuation would not automatically repair that operating problem.

My present judgment is conditional interest in the installed-service franchise. Flock offers a coherent way to bundle a difficult operating job. The business becomes compelling when permitted customer value survives renewal and those renewals repay the full cost of putting the service in place. That is the record I would ask for before moving from an appealing subscription story to an investment case.
