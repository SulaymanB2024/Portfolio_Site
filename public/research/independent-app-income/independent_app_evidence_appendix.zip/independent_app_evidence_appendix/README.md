# Independent App Income Distribution - Downloadable Data Appendix

Publication target: sulayman-bowles.dev  
Research cutoff: 2026-07-14  
Monte Carlo seed: 20260714  
Draws: 500,000

## Headline

The model estimates that **15.4%** of independent developers making a serious commercial attempt generate at least **$1,000 in current gross monthly revenue** across apps they own, with a plausible interval of **8.4% to 25.0%**. At the app level the corresponding estimate is **10.2%** (5.3% to 17.4%).

These are modeled uncertainty intervals, not sampling-error confidence intervals. No public dataset observes store universe, owner independence, monetization model, and current revenue together.

## Files

- `definitions.csv`: explicit population and revenue definitions.
- `denominator_estimates.csv`: app- and developer-level ranges for denominators A-F, current and three-month sustained.
- `threshold_estimates.csv`: ranges for any revenue through $100,000/month and replacement-income profit.
- `revenue_bands.csv`: central modeled distribution by denominator.
- `unit_economics.csv`: formulas and assumptions for subscription, ads, paid downloads, commission, and profit.
- `cases.csv`: reconstructed and extended public app/portfolio evidence table.
- `evidence_classes.csv`: population and bias audit for each evidence class.
- `sources.csv`: direct source table.
- `claim_ledger.csv`: trace from publication claims to sources/models.
- `methodology_assumptions.csv`: formulas and model assumptions.
- `sensitivity_analysis.csv`: one-way and denominator sensitivities.
- `portfolio_model.csv` and `portfolio_summary.csv`: developer/app aggregation mechanics.
- `source_quality_rubric.csv`: 0-16 claim credibility framework.
- `chart_data.csv`: publication-chart inputs.
- `model_summary.json`: machine-readable headline outputs.
- `model_reproduction.py`: standalone Monte Carlo reproduction.

## Important data note

The uploaded ZIP was a Google Search Console export, not an app-revenue dataset. The File Library contained the research dossier, but no separate standalone app-level evidence dataset was available. `cases.csv` reconstructs the dossier cases and adds current primary-source/verified-dashboard evidence; it should not be treated as a prevalence sample.
