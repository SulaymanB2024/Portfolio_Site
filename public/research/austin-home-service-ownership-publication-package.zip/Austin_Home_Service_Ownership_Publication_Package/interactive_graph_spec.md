# Interactive Graph Specification

## Public default

- Display current active consumer brands only.
- Default owner-type filter: sponsor-backed platform.
- Use a layered chain, not a force-directed network.
- Columns: consumer brand → immediate platform/local operator/franchise system → ultimate owner/controller.
- Show evidence rating and unresolved/pending state on every row.
- Open a row to reveal interest type, local-language coding, evidence IDs and notes.

## Filters

- Search by brand, platform, sponsor, public parent or local owner.
- Sector: HVAC/plumbing/electrical; roofing/exterior; foundation; pest.
- Owner type.
- Evidence rating.
- Unresolved only.
- Retained brands only.
- Franchises only.
- Current vs historical/pending edges.

## Deep view

The optional deep layer adds legal entities, DBAs, holding companies, minority investors, former sponsors, acquisitions, combinations and rebrands. It must preserve edge labels. “Franchise of” cannot render as “subsidiary of.” Pending `Acquired by` edges must not replace current parents.

## Node and edge behavior

- Brand nodes link to mobile ownership cards.
- Sponsor and platform nodes open a list of associated Austin-facing brands.
- Evidence IDs open the source ledger.
- Historical edges use lower opacity.
- Pending edges use a dashed line.
- Minority-investment edges use a distinct line pattern from majority-control edges.
- Unresolved controllers end in an explicit unresolved node or no owner edge; they never default to “independent.”

## Accessibility

- Every graph relationship must also appear as text.
- Keyboard focus must follow the chain order.
- Color cannot be the only signal for pending, minority or unresolved status.
- Mobile layout stacks the chain vertically.
- The graph should remain usable with JavaScript disabled through a static ownership table.

## Files

- `graph.json`: full graph and mobile chains.
- Four category JSON files.
- `graph_sponsor_platform_view.json`.
- `ownership_graph.html`: self-contained public prototype.
- `ownership_table.html`: self-contained fallback and filtering tool.
