# Unresolved and Rejected Claims

## Claims rejected from publication

1. “Austin’s home-service market is X% private-equity owned.” The available denominator is brands, not revenue or companies.
2. “Brand A is independent because no acquisition announcement was found.” Absence of public news is not ownership evidence.
3. “KKR owns Mr. Rooter Austin.” KKR owns Neighborly; the local Austin franchisee is separately owned.
4. “Apax owns Benjamin Franklin Plumbing of Austin.” Apax owns the franchisor. The local franchisee remains unresolved.
5. “Trivest owns Alta Pest Control.” Trivest’s investment was explicitly non-control minority; founders retained control.
6. “Blackstone owns Service Wizard.” The Blackstone-Champions agreement was announced, but closing was not established by the snapshot.
7. “Massey owns the current EcoShield Austin branch.” Massey acquired an EcoShield Austin division in 2015; the current brand/operator chain is unresolved.
8. “Ja-Mar is locally owned” based only on current site language. Dunes Point’s platform acquisition is direct transaction evidence.
9. “The platform caused higher prices, lower service, layoffs or customer harm.” No causal analysis supports such a statement.
10. Company size rankings based on Google reviews, permits, locations or search visibility. Those measures are not comparable revenue data.

## High-priority unresolved cases

The highest-priority records are Service Wizard’s sponsor closing, Daniel’s current standalone brand status, the Benjamin Franklin and Ram Jack local franchisees, Olshan’s current controller, Advanced Foundation Repair’s general-partner chain, Hawx’s current sponsor, Ranger’s individual controller, EcoShield’s current Austin operator, and the exact legal entities behind several retained acquired brands.

See `master_unresolved.csv` for the full question, current treatment, evidence needed and priority.
