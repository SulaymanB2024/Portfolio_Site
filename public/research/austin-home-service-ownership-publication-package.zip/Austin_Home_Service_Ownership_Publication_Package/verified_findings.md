# Verified Findings and Calculations

**Denominator:** 67 active Austin-facing consumer-brand records as of 2026-07-26.

| Owner type | Brands | Share of 67-brand universe |
|---|---:|---:|
| Founder/family/local ownership | 32 | 47.8% |
| Sponsor-backed platform | 14 | 20.9% |
| Public-company owned | 4 | 6.0% |
| Local franchise operator | 5 | 7.5% |
| Private/control unresolved | 11 | 16.4% |
| Minority-invested, founder-controlled | 1 | 1.5% |

## Additional findings

- A/B and not unresolved: **48 of 67 (71.6%)**.
- Retained consumer names after a transaction: **11**.
- Local franchise records: **5**.
- Private/control-unresolved records: **11**.
- Current or historical transaction records: **29**.
- Preserved conflicts: **20**.
- Open research questions: **25**.

## Sector counts

| Sector | Brands | Share of 67-brand universe |
|---|---:|---:|
| HVAC, plumbing and electrical | 26 | 38.8% |
| Roofing and exterior | 9 | 13.4% |
| Foundation repair | 12 | 17.9% |
| Pest control | 20 | 29.9% |

## Current multi-brand clusters

- Southern Home Services / Gryphon: Fox, Precision, Daniel’s.
- SAS Service Partners / Storr Group: Austin Air Conditioning, Roger’s Plumbing. Cool Atmosphere is historical/absorbed.
- Neighborly franchisor / KKR: Mr. Rooter Austin, Aire Serv Cedar Park, Aire Serv Round Rock. These are associations through the franchisor, not KKR ownership of the local franchisees.
- Rollins: Orkin and HomeTeam.

## Interpretation rule

These percentages describe **brand records in the publication universe**. They are not market share, revenue share, customer share, job share, permit share, review share or search share.
