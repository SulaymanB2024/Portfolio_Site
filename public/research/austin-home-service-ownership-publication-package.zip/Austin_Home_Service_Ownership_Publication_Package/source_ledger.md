# Source Ledger

**Snapshot:** 2026-07-26  
**Sources:** 130  

Source IDs are used across every CSV, JSON graph, article citation and ownership card. A syndication or copied release is not treated as an independent source merely because it has another URL.

## I001 — Austin Home-Service Market Census

- **Publisher:** Deep Research Model A
- **Type:** uploaded research report (research input)
- **Quality:** C
- **Independence group:** `model_a`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** source_inputs/Austin Home-Service Market Census.docx
- **Supports:** market discovery, inclusion leads, coverage gaps
- **Note:** Structured deliverables named in the report were not embedded in the DOCX or separately uploaded; the report is treated as a discovery memo, not a source-of-truth dataset.

## I002 — Who Owns Austin’s Home-Service Companies

- **Publisher:** Deep Research Model B
- **Type:** uploaded research report (research input)
- **Quality:** C
- **Independence group:** `model_b`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** source_inputs/Who Owns Austin’s Home-Service Companies.docx
- **Supports:** ownership leads and transaction chronology
- **Note:** The report states that it did not receive Model A’s structured files. Several row-level citations were mismatched and were replaced in this package.

## S001 — Southern Home Services Acquires Austin-based Precision Heating & Air Conditioning

- **Publisher:** Southern Home Services
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `southern`
- **Publication date:** 2020-07
- **Access date:** 2026-07-26
- **URL or file:** https://www.southernhomeservices.com/blog/2020/july/southern-home-services-acquires-austin-based-pre/
- **Supports:** Precision acquisition and retained brand

## S002 — Southern HVAC Expands into Texas With Fox Service Company Acquisition

- **Publisher:** Southern Home Services
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `southern`
- **Publication date:** 2020-07
- **Access date:** 2026-07-26
- **URL or file:** https://www.southernhomeservices.com/blog/2020/july/southern-hvactm-expands-into-texas-with-fox-serv/
- **Supports:** Fox acquisition

## S003 — Southern Home Services Announces Acquisition of Daniel’s Plumbing and Air Conditioning

- **Publisher:** Southern Home Services
- **Type:** transaction archive (primary)
- **Quality:** A
- **Independence group:** `southern`
- **Publication date:** 2022-04-07
- **Access date:** 2026-07-26
- **URL or file:** https://www.southernhomeservices.com/blog/2022/april/
- **Supports:** Daniel’s acquisition announcement

## S004 — Daniel’s Plumbing and Air Conditioning | Austin, TX

- **Publisher:** Southern Home Services
- **Type:** current brand page (primary)
- **Quality:** A
- **Independence group:** `southern`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.southernhomeservices.com/daniels/
- **Supports:** Daniel’s current brand listing and Austin service

## S005 — Southern Home Services Site Map

- **Publisher:** Southern Home Services
- **Type:** current corporate page (primary)
- **Quality:** A
- **Independence group:** `southern`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.southernhomeservices.com/site-map/
- **Supports:** Current listing of Fox, Precision, and Daniel’s brands

## S006 — North American Essential Home Services

- **Publisher:** Gryphon Investors
- **Type:** current portfolio page (primary)
- **Quality:** A
- **Independence group:** `gryphon`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.gryphon-inv.com/companies/north-american-essential-home-services-naehs/
- **Supports:** Current Gryphon portfolio relationship to Southern Home Services holding structure

## S007 — Gryphon Investors Completes Majority Investment in Southern Home Services

- **Publisher:** Southern Home Services / Gryphon Investors
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `southern_gryphon_release`
- **Publication date:** 2021-10
- **Access date:** 2026-07-26
- **URL or file:** https://www.southernhomeservices.com/blog/2021/october/gryphon-investors-completes-majority-investment-/
- **Supports:** Gryphon majority investment; management retained meaningful stake

## S008 — Radiant Home Maintenance Plan Terms

- **Publisher:** Radiant Plumbing & Air Conditioning
- **Type:** current legal terms (primary)
- **Quality:** A
- **Independence group:** `radiant`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://radiantplumbing.com/maintenance-plan/
- **Supports:** Radiant Plumbing Service, LLC doing business as Radiant

## S009 — T3 Services Group Partners

- **Publisher:** T3 Services Group
- **Type:** current platform page (primary)
- **Quality:** A
- **Independence group:** `t3`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.t3servicesgroup.com/
- **Supports:** Radiant listed within T3 platform

## S010 — T3 Services Group

- **Publisher:** The Riverside Company
- **Type:** current portfolio page (primary)
- **Quality:** A
- **Independence group:** `riverside`
- **Publication date:** 2020-11
- **Access date:** 2026-07-26
- **URL or file:** https://www.riversidecompany.com/investment-portfolio/t3-services-group
- **Supports:** Current Riverside portfolio relationship to T3

## S011 — The Master Trades Group Acquires Stan’s Home Services

- **Publisher:** The Master Trades Group
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `mtg_release`
- **Publication date:** 2024-03-25
- **Access date:** 2026-07-26
- **URL or file:** https://www.prnewswire.com/news-releases/the-master-trades-group-acquires-stans-home-services-302098640.html
- **Supports:** Completed acquisition of Stan’s by Master Trades Group

## S012 — Treaty Oak Equity Sells Stan’s Home Services

- **Publisher:** Treaty Oak Equity
- **Type:** seller announcement / portfolio history (primary)
- **Quality:** B
- **Independence group:** `treaty_oak`
- **Publication date:** 2024-03
- **Access date:** 2026-07-26
- **URL or file:** https://treatyoak.com/
- **Supports:** Treaty Oak historical ownership and exit

## S013 — Master Trades Group (fka LTP Home Services Group)

- **Publisher:** L Catterton
- **Type:** current portfolio page (primary)
- **Quality:** A
- **Independence group:** `l_catterton`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.lcatterton.com/investments.html
- **Supports:** Current L Catterton investment in Master Trades Group

## S014 — L Catterton to Acquire LTP Home Services Group

- **Publisher:** L Catterton
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `l_catterton`
- **Publication date:** 2022-03-22
- **Access date:** 2026-07-26
- **URL or file:** https://www.lcatterton.com/Press.html
- **Supports:** L Catterton acquisition of LTP, now Master Trades Group

## S015 — Abacus Privacy Policy

- **Publisher:** Abacus Plumbing, Air Conditioning & Electrical
- **Type:** current legal policy (primary)
- **Quality:** A
- **Independence group:** `abacus`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.abacusplumbing.com/privacy-policy/
- **Supports:** Abacus described as wholly owned subsidiary of Wrench Group, LLC

## S016 — TSG Consumer Partners and Oak Hill Partner with Leonard Green and Management

- **Publisher:** Wrench Group
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `wrench_release`
- **Publication date:** 2022-11-09
- **Access date:** 2026-07-26
- **URL or file:** https://www.wrenchgroup.com/articles/tsg-consumer-partners-and-oak-hill-partner-with-leonard-green-and-management-to-enhance-the-wrench-groups-next-phase-of-growth
- **Supports:** Leonard Green and management retained majority; TSG and Oak Hill made significant minority investment

## S017 — Wrench Group Portfolio Company

- **Publisher:** Leonard Green & Partners
- **Type:** current sponsor page (primary)
- **Quality:** B
- **Independence group:** `leonard_green`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.leonardgreen.com/
- **Supports:** Current Wrench Group sponsor relationship

## S018 — Goettl Austin

- **Publisher:** Goettl Air Conditioning & Plumbing
- **Type:** current local service page (primary)
- **Quality:** A
- **Independence group:** `goettl`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.goettl.com/austin/
- **Supports:** Current Austin service; Dayton Services history/rebrand

## S019 — Cortec Group Investment in Goettl

- **Publisher:** Cortec Group
- **Type:** sponsor portfolio / transaction page (primary)
- **Quality:** A
- **Independence group:** `cortec`
- **Publication date:** 2021-12
- **Access date:** 2026-07-26
- **URL or file:** https://www.cortecgroup.com/
- **Supports:** Cortec investment in Goettl

## S020 — Brookfield Infrastructure Completes Acquisition of Enercare

- **Publisher:** Brookfield Infrastructure
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `brookfield`
- **Publication date:** 2018-10-16
- **Access date:** 2026-07-26
- **URL or file:** https://bip.brookfield.com/press-releases/bip/brookfield-infrastructure-completes-c43-billion-acquisition-enercare-inc
- **Supports:** Enercare and Service Experts acquisition completed

## S021 — Strand Brothers Service Experts - Austin

- **Publisher:** Service Experts
- **Type:** current local service page (primary)
- **Quality:** A
- **Independence group:** `service_experts`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.serviceexperts.com/austin-tx/
- **Supports:** Current Austin Strand Brothers operation

## S022 — Brookfield Infrastructure 2025 Annual Report

- **Publisher:** Brookfield Infrastructure
- **Type:** annual report (primary)
- **Quality:** A
- **Independence group:** `brookfield`
- **Publication date:** 2026
- **Access date:** 2026-07-26
- **URL or file:** https://bip.brookfield.com/sites/brookfield-bip-v2/files/Brookfield-BIP-IR-V2/BIPC/annual-reports/bip-2025-20-f.pdf
- **Supports:** Current Brookfield ownership reporting for operating businesses including Service Experts

## S023 — Champions Group Acquires Service Wizard of Austin

- **Publisher:** Champions Group Holdings
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `champions`
- **Publication date:** 2022-11-22
- **Access date:** 2026-07-26
- **URL or file:** https://championsgroupholdings.com/2022/11/22/growth-continues-with-service-wizard-of-austin/
- **Supports:** Service Wizard acquisition

## S024 — Blackstone Announces Agreement to Acquire Champions Group

- **Publisher:** Blackstone
- **Type:** pending transaction announcement (primary)
- **Quality:** A
- **Independence group:** `blackstone`
- **Publication date:** 2026-02-17
- **Access date:** 2026-07-26
- **URL or file:** https://www.blackstone.com/news/press/blackstone-announces-agreement-to-acquire-champions-group/
- **Supports:** Agreement to acquire Champions; expected close in first half of 2026

## S025 — Service Wizard Austin

- **Publisher:** Service Wizard Heating & Air Conditioning
- **Type:** current local service page (primary)
- **Quality:** A
- **Independence group:** `service_wizard`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://servicewizardac.com/
- **Supports:** Current Austin/Hutto operation

## S026 — ARS/Rescue Rooter Austin

- **Publisher:** ARS/Rescue Rooter
- **Type:** current local service page (primary)
- **Quality:** A
- **Independence group:** `ars`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.ars.com/austin
- **Supports:** Current Austin residential HVAC/plumbing operation

## S027 — GI Partners Acquires Majority Interest in American Residential Services

- **Publisher:** GI Partners
- **Type:** transaction / portfolio page (primary)
- **Quality:** A
- **Independence group:** `gi_partners`
- **Publication date:** 2020-09-15
- **Access date:** 2026-07-26
- **URL or file:** https://www.gipartners.com/
- **Supports:** GI majority investment; Charlesbank and management retained significant stakes

## S028 — American Residential Services Portfolio

- **Publisher:** GI Partners
- **Type:** current portfolio page (primary)
- **Quality:** A
- **Independence group:** `gi_partners`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.gipartners.com/portfolio/
- **Supports:** Current ARS portfolio relationship

## S029 — Mr. Rooter Plumbing of Austin

- **Publisher:** Mr. Rooter Plumbing
- **Type:** current local franchise page (primary)
- **Quality:** A
- **Independence group:** `mr_rooter_austin`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.mrrooter.com/austin/
- **Supports:** Brett Bidwell identified as local owner; independently owned and operated

## S030 — KKR Completes Acquisition of Neighborly

- **Publisher:** KKR
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `kkr`
- **Publication date:** 2021
- **Access date:** 2026-07-26
- **URL or file:** https://www.kkr.com/newsroom/news/news-details/2021/kkr-completes-acquisition-neighborly
- **Supports:** KKR acquisition of Neighborly completed

## S031 — Authority Brands

- **Publisher:** Apax Partners
- **Type:** current portfolio page (primary)
- **Quality:** A
- **Independence group:** `apax`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.apax.com/partnerships/authority-brands/
- **Supports:** Apax current majority owner of Authority Brands

## S032 — BCI Corporate Annual Report 2022-2023

- **Publisher:** British Columbia Investment Management Corporation
- **Type:** annual report (primary)
- **Quality:** A
- **Independence group:** `bci`
- **Publication date:** 2023
- **Access date:** 2026-07-26
- **URL or file:** https://www.bci.ca/wp-content/uploads/2018/01/2022-2023-corporate-annual-report_financial-statements-2.pdf
- **Supports:** BCI significant minority investment in Authority Brands

## S033 — Benjamin Franklin Plumbing of Austin

- **Publisher:** Benjamin Franklin Plumbing
- **Type:** current local franchise page (primary)
- **Quality:** B
- **Independence group:** `ben_franklin_austin`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.benjaminfranklinplumbing.com/austin/
- **Supports:** Current Austin franchise and local-operation claim; local franchisee legal identity not established

## S034 — Aire Serv of Cedar Park

- **Publisher:** Aire Serv
- **Type:** current local franchise page (primary)
- **Quality:** B
- **Independence group:** `aireserv_cedar_park`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.aireserv.com/cedar-park/
- **Supports:** Current Cedar Park/Leander franchise; independently owned and operated

## S035 — Aire Serv of Round Rock

- **Publisher:** Aire Serv
- **Type:** current local franchise page (primary)
- **Quality:** A
- **Independence group:** `aireserv_round_rock`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.aireserv.com/round-rock/
- **Supports:** Current Round Rock/Austin service and Chris Rattray owner/operator

## S036 — Aire Serv is a Neighborly Company

- **Publisher:** Aire Serv / Neighborly
- **Type:** current franchisor page (primary)
- **Quality:** A
- **Independence group:** `neighborly`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.aireserv.com/about/
- **Supports:** Aire Serv membership in Neighborly franchise system

## S037 — SAS Service Partners Acquires Austin Air Conditioning

- **Publisher:** SAS Service Partners
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `sas`
- **Publication date:** 2023-10-03
- **Access date:** 2026-07-26
- **URL or file:** https://sasservicepartners.com/news/austin-air-conditioning
- **Supports:** Austin Air Conditioning acquisition and Storr backing
- **Note:** The article page’s rendered date conflicts with the SAS news index. This package uses the chronological news index date and logs the conflict.

## S038 — SAS Service Partners Acquires Roger’s Plumbing

- **Publisher:** SAS Service Partners
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `sas`
- **Publication date:** 2024-07-20
- **Access date:** 2026-07-26
- **URL or file:** https://sasservicepartners.com/news/rogers-plumbing
- **Supports:** Roger’s Plumbing acquisition and Storr backing
- **Note:** The article page’s rendered year conflicts with the SAS news index. This package uses the chronological news index date and logs the conflict.

## S039 — Cool Atmosphere Joins SAS Service Partners

- **Publisher:** SAS Service Partners
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `sas`
- **Publication date:** 2024-06-07
- **Access date:** 2026-07-26
- **URL or file:** https://sasservicepartners.com/news/cool-atmosphere
- **Supports:** Cool Atmosphere acquisition and Storr backing
- **Note:** The article page’s rendered year conflicts with the SAS news index. This package uses the chronological news index date and logs the conflict.

## S040 — SAS Service Partners News Index

- **Publisher:** SAS Service Partners
- **Type:** current transaction index (primary)
- **Quality:** A
- **Independence group:** `sas`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://sasservicepartners.com/news
- **Supports:** Chronology for Austin Air Conditioning, Cool Atmosphere, and Roger’s Plumbing acquisitions

## S041 — Austin Air Conditioning

- **Publisher:** Austin Air Conditioning
- **Type:** current local service page (primary)
- **Quality:** A
- **Independence group:** `austin_air`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://austinairconditioning.com/
- **Supports:** Current Austin operation and locally operated wording

## S042 — Roger’s Plumbing

- **Publisher:** Roger’s Plumbing
- **Type:** current local service page (primary)
- **Quality:** A
- **Independence group:** `rogers_plumbing`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://callrogersplumbing.com/
- **Supports:** Current Leander/Austin plumbing operation

## S043 — Cool Atmosphere

- **Publisher:** Cool Atmosphere
- **Type:** current brand page / redirect (primary)
- **Quality:** B
- **Independence group:** `cool_atmosphere`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://coolatmosphereheatingandair.com/
- **Supports:** Current combination into Austin Air Conditioning

## S044 — SAS Service Partners Meet the Team Archive

- **Publisher:** SAS Service Partners
- **Type:** current/archive company page (primary)
- **Quality:** B
- **Independence group:** `sas`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://sasservicepartners.com/meet-the-team-old
- **Supports:** Austin Air transaction closed; seller rolled substantial equity

## S045 — Roofing Services Solutions Acquires Ja-Mar Roofing & Sheet Metal

- **Publisher:** Dunes Point Capital
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `dunes_point`
- **Publication date:** 2025-04-08
- **Access date:** 2026-07-26
- **URL or file:** https://www.dunespointcapital.com/news/roofing-services-solutions-acquires-ja-mar-roofing-sheet-metal/
- **Supports:** Ja-Mar acquisition

## S046 — Roofing Services Solutions

- **Publisher:** Dunes Point Capital
- **Type:** current portfolio page (primary)
- **Quality:** A
- **Independence group:** `dunes_point`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.dunespointcapital.com/portfolio/roofing-services-solutions/
- **Supports:** Current Dunes Point Capital ownership of Roofing Services Solutions

## S047 — Ja-Mar Roofing & Sheet Metal

- **Publisher:** Ja-Mar Roofing & Sheet Metal
- **Type:** current company page (primary)
- **Quality:** A
- **Independence group:** `ja_mar`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://jamarroofing.com/
- **Supports:** Current Austin operation; local-owner/local-company wording

## S048 — Groundworks Austin

- **Publisher:** Groundworks
- **Type:** current service-area page (primary)
- **Quality:** A
- **Independence group:** `groundworks`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.groundworks.com/service-areas/foundation-repair-austin-tx/
- **Supports:** Current Austin service from San Antonio-area office

## S049 — KKR Makes Significant Investment in Groundworks

- **Publisher:** Groundworks / KKR
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `groundworks_kkr_release`
- **Publication date:** 2023-03
- **Access date:** 2026-07-26
- **URL or file:** https://www.groundworks.com/resources/kkr-makes-significant-investment-in-groundworks/
- **Supports:** KKR control/significant investment; Cortec remained shareholder

## S050 — Cortec Groundworks Investment History

- **Publisher:** Cortec Group
- **Type:** portfolio history (primary)
- **Quality:** A
- **Independence group:** `cortec`
- **Publication date:** 2026-05
- **Access date:** 2026-07-26
- **URL or file:** https://www.cortecgroup.com/portfolio/groundworks/
- **Supports:** Cortec exited majority in March 2023 and retained minority positions

## S051 — Groundworks Acquires Foundation Support Specialists

- **Publisher:** Groundworks
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `groundworks`
- **Publication date:** 2022-07-18
- **Access date:** 2026-07-26
- **URL or file:** https://www.groundworks.com/resources/groundworks-acquires-foundation-support-specialists/
- **Supports:** Foundation Support Specialists acquisition

## S052 — Citation Capital Acquires Majority Stake in Aptive Environmental

- **Publisher:** Citation Capital
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `citation`
- **Publication date:** 2024-08-27
- **Access date:** 2026-07-26
- **URL or file:** https://www.citationcapital.com/news/citation-capital-invests-in-aptive-environmental
- **Supports:** Citation majority stake; management retained significant interest

## S053 — Aptive Austin Branch

- **Publisher:** Aptive Environmental
- **Type:** current local branch page (primary)
- **Quality:** A
- **Independence group:** `aptive`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://aptivepestcontrol.com/locations/texas-tx/austin-pest-control/local-branch/
- **Supports:** Current Austin branch

## S054 — Trivest Makes Minority Investment in Alta Pest Control

- **Publisher:** Trivest Partners
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `trivest`
- **Publication date:** 2024-04
- **Access date:** 2026-07-26
- **URL or file:** https://www.trivest.com/news/trivest-partners-announces-investment-in-alta-pest-control/
- **Supports:** Non-control minority investment; founders retained operational and financial control

## S055 — Rollins Completes Acquisition of HomeTeam Pest Defense

- **Publisher:** Rollins, Inc.
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `rollins`
- **Publication date:** 2008-04-03
- **Access date:** 2026-07-26
- **URL or file:** https://www.rollins.com/news-events/press-releases/detail/28/rollins-inc-completes-acquisition-of-hometeam-pest-defense
- **Supports:** HomeTeam acquisition completed

## S056 — Rollins Brands

- **Publisher:** Rollins, Inc.
- **Type:** current corporate brand page (primary)
- **Quality:** A
- **Independence group:** `rollins`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.rollins.com/about-us/brands/default.aspx
- **Supports:** Current Orkin and HomeTeam parent relationship

## S057 — Rentokil Completes Terminix Acquisition

- **Publisher:** Rentokil Initial plc
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `rentokil`
- **Publication date:** 2022-10-12
- **Access date:** 2026-07-26
- **URL or file:** https://www.rentokil-initial.com/media/news-releases/news-2022/terminix_completion.aspx
- **Supports:** Terminix acquisition completed

## S058 — PCM Growth Acquires Hawx Services

- **Publisher:** PCM Growth
- **Type:** transaction announcement / portfolio page (primary)
- **Quality:** B
- **Independence group:** `pcm`
- **Publication date:** 2021-03-12
- **Access date:** 2026-07-26
- **URL or file:** https://www.pcmgrowth.com/
- **Supports:** Last documented sponsor acquisition of Hawx; current continuity not independently reconfirmed

## S059 — Massey Services Acquires EcoShield’s Austin Division

- **Publisher:** Massey Services
- **Type:** transaction announcement (primary)
- **Quality:** A
- **Independence group:** `massey`
- **Publication date:** 2015
- **Access date:** 2026-07-26
- **URL or file:** https://www.masseyservices.com/massey-services-acquires-ecoshield-pest-controls-austin-division/
- **Supports:** Historical acquisition of EcoShield Austin division; not treated as proof of current EcoShield brand ownership

## S060 — Structural Pest Control Service

- **Publisher:** Texas Department of Agriculture
- **Type:** regulatory page (primary)
- **Quality:** A
- **Independence group:** `texas_agriculture`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://texasagriculture.gov/Regulatory-Programs/Pesticides/Structural-Pest-Control-Service
- **Supports:** Texas structural pest control licensing framework

## S100 — ABC Home & Commercial Services - About Austin

- **Publisher:** ABC Home & Commercial Services
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `abc`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.abchomeandcommercial.com/austin/about
- **Supports:** ABC Austin presence; Bobby Jenkins and family ownership

## S101 — Fox Service Company

- **Publisher:** Fox Service Company
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `fox`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.foxservice.com/
- **Supports:** Current Austin HVAC/plumbing/electrical brand

## S102 — Precision Heating & Air

- **Publisher:** Precision Heating & Air
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `precision`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.precisionheatac.com/
- **Supports:** Current Austin-facing Precision brand

## S103 — Radiant Plumbing, Air Conditioning & Electrical

- **Publisher:** Radiant
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `radiant`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://radiantplumbing.com/
- **Supports:** Current Austin operation

## S104 — Stan’s Heating, Air, Plumbing & Electrical

- **Publisher:** Stan’s
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `stans`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://stansac.com/
- **Supports:** Current Austin and suburb service area

## S105 — McCullough Heating & Air Conditioning

- **Publisher:** McCullough Heating & Air Conditioning
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `mccullough`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://coolmenow.com/
- **Supports:** Current Greater Austin service and local-ownership claim

## S106 — McCullough BBB Profile

- **Publisher:** Better Business Bureau
- **Type:** current company / identity page (secondary)
- **Quality:** B
- **Independence group:** `bbb`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bbb.org/us/tx/austin/profile/air-conditioning-contractor/mccullough-heating-air-conditioning-inc-0825-37920
- **Supports:** McCullough legal-name and president lead

## S107 — Efficient AC, Electric & Plumbing - About

- **Publisher:** Efficient AC, Electric & Plumbing
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `efficient`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://efficienttexas.com/about-us/
- **Supports:** George and Molly Drazic ownership and current Austin operation

## S108 — Reliant Plumbing - About

- **Publisher:** Reliant Plumbing
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `reliant`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.reliantplumbing.com/about-us/
- **Supports:** Max Hicks/family ownership and current Austin operation

## S109 — Christianson Air Conditioning & Plumbing

- **Publisher:** Christianson
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `christianson`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.christiansonco.com/
- **Supports:** Current Austin/Round Rock operation and family-ownership claim

## S110 — Excalibur Plumbing

- **Publisher:** Excalibur Plumbing
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `excalibur`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.excaliburplumbing.com/
- **Supports:** Current Austin/Leander service, master license, Blake Smith

## S111 — Excalibur Plumbing BBB Profile

- **Publisher:** Better Business Bureau
- **Type:** current company / identity page (secondary)
- **Quality:** B
- **Independence group:** `bbb`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bbb.org/us/tx/leander/profile/plumber/excalibur-plumbing-llc-0825-90055054
- **Supports:** Excalibur Plumbing LLC and managing member lead

## S112 — Whitestone Plumbing

- **Publisher:** Whitestone Plumbing
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `whitestone`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://callwhitestone.com/
- **Supports:** Current Cedar Park/Austin service and local-ownership claim

## S113 — Whitestone Plumbing BBB Profile

- **Publisher:** Better Business Bureau
- **Type:** current company / identity page (secondary)
- **Quality:** B
- **Independence group:** `bbb`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bbb.org/us/tx/cedar-park/profile/plumber/whitestone-plumbing-0825-1000193219
- **Supports:** Ben Helton owner lead

## S114 — Crow’s Plumbing Service

- **Publisher:** Crow’s Plumbing Service
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `crows`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://crowsplumbing.com/
- **Supports:** Current Round Rock/Greater Austin operation and license

## S115 — Crow’s Plumbing BBB Profile

- **Publisher:** Better Business Bureau
- **Type:** current company / identity page (secondary)
- **Quality:** B
- **Independence group:** `bbb`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bbb.org/us/tx/round-rock/profile/plumber/crows-plumbing-service-0825-90034943
- **Supports:** Jack Crow managing-member lead

## S116 — AirFix Mechanical

- **Publisher:** AirFix Mechanical
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `airfix`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.getyourairfix.com/
- **Supports:** Current Austin/Round Rock HVAC operation and AirFix Mechanical LLC identity

## S117 — Austin Major Air & Heat BBB Profile

- **Publisher:** Better Business Bureau
- **Type:** current company / identity page (secondary)
- **Quality:** B
- **Independence group:** `bbb`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bbb.org/us/tx/austin/profile/air-conditioning-contractor/austin-major-air-heat-0825-43724
- **Supports:** Current operating history and Adoni Enterprises, Inc. alias

## S118 — Kidd Roofing Austin

- **Publisher:** Kidd Roofing
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `kidd`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.kiddroof.com/austin-roofing/
- **Supports:** Current Austin residential and commercial roofing office

## S119 — Kidd Roofing BBB Profile

- **Publisher:** Better Business Bureau
- **Type:** current company / identity page (secondary)
- **Quality:** B
- **Independence group:** `bbb`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bbb.org/us/tx/austin/profile/roofing-contractors/kidd-roofing-0825-43065
- **Supports:** D.R. Kidd Company, Inc. and current executive lead

## S120 — Hall Roofing & Construction

- **Publisher:** Hall Roofing & Construction
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `hall`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://hallroofingtx.com/
- **Supports:** Current Round Rock/Austin residential roofing operation and Erik Hall

## S121 — RoofCrafters Austin

- **Publisher:** RoofCrafters
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `roofcrafters`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://roofcrafters.com/austin/
- **Supports:** Current Leander/Austin headquarters and family/local claim

## S122 — RoofCrafters GAF Profile

- **Publisher:** GAF
- **Type:** current company / identity page (secondary)
- **Quality:** B
- **Independence group:** `gaf`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.gaf.com/en-us/roofing-contractors/residential/usa/tx/leander/roofcrafters-inc-1101351
- **Supports:** RoofCrafters, Inc. identity and Leander address

## S123 — Longhorn Roofing

- **Publisher:** Longhorn Roofing
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `longhorn`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.longhornroofing.com/
- **Supports:** Current Austin residential roofing operation and Tom Green leadership

## S124 — Anderson Roofing & Construction

- **Publisher:** Anderson Roofing & Construction
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `anderson`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://andersonroofingtexas.com/
- **Supports:** Current Leander/Austin residential roofing and family-ownership claim

## S125 — Silver Creek Exterior & Construction

- **Publisher:** Silver Creek Exterior & Construction
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `silver_creek`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://scecroofs.com/
- **Supports:** Current Austin/Central Texas residential exterior services and local claim

## S126 — Wilson Roofing

- **Publisher:** Wilson Roofing
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `wilson`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://wilsonroofing.com/
- **Supports:** Current Austin residential roofing operation

## S127 — Austin Roofing and Construction

- **Publisher:** Austin Roofing and Construction
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `austin_roofing`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.austinroofingandconstruction.com/
- **Supports:** Current Austin residential roofing office and private partnership

## S128 — Olshan Foundation Repair Austin

- **Publisher:** Olshan Foundation Repair
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `olshan`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.olshanfoundation.com/regions/texas/austin/
- **Supports:** Current Austin service-area presence

## S129 — Ram Jack Austin

- **Publisher:** Ram Jack
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `ram_jack`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.ramjack.com/austin/
- **Supports:** Current Austin franchise and independently owned/operated disclosure

## S130 — CenTex Foundation Repair

- **Publisher:** CenTex Foundation Repair
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `centex`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://centexfoundationrepair.com/
- **Supports:** Current Austin-area foundation operation and company history

## S131 — Douglas Foundation Repair

- **Publisher:** Douglas Foundation Repair
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `douglas`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://douglasfoundationrepair.com/
- **Supports:** Current Austin-area foundation operation

## S132 — Advanced Foundation Repair Austin

- **Publisher:** Advanced Foundation Repair
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `advanced`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://foundationrepairs.com/texas/austin-foundation-repair/
- **Supports:** Current Austin operation

## S133 — Advanced Foundation Repair BBB Profile

- **Publisher:** Better Business Bureau
- **Type:** current company / identity page (secondary)
- **Quality:** B
- **Independence group:** `bbb`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bbb.org/us/tx/dallas/profile/foundation-contractors/advanced-foundation-repair-lp-0875-19000054
- **Supports:** Advanced Foundation Repair, LP identity

## S134 — Baird Foundation Repair - About

- **Publisher:** Baird Foundation Repair
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `baird`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bairdfoundationrepair.com/about-us/
- **Supports:** John and Melanie Baird sole ownership and current Austin/Georgetown operation

## S135 — G.L. Hunt Foundation Repair

- **Publisher:** G.L. Hunt Foundation Repair
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `gl_hunt`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://glhunt.com/
- **Supports:** Current Austin operation and Hunt family ownership

## S136 — All in One Foundation Repair

- **Publisher:** All in One Foundation Repair
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `all_in_one`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://allinonefoundationrepair.com/
- **Supports:** Current Austin operation and local-ownership claim

## S137 — All in One Foundation Repair BBB Profile

- **Publisher:** Better Business Bureau
- **Type:** current company / identity page (secondary)
- **Quality:** B
- **Independence group:** `bbb`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bbb.org/us/tx/austin/profile/foundation-contractors/all-in-one-foundation-repair-0825-90019893
- **Supports:** Robert J. Knight owner lead

## S138 — Bats Foundation Repair - About

- **Publisher:** Bats Foundation Repair
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `bats`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://batsfoundationrepair.com/about-us/
- **Supports:** Current Austin operation and Brent Parks ownership

## S139 — Quality Foundation Repair Austin

- **Publisher:** Quality Foundation Repair
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `quality_foundation`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://qualityfoundationrepairaustin.com/
- **Supports:** Current Austin address and service operation

## S140 — Quality Foundation Repair BBB Profile

- **Publisher:** Better Business Bureau
- **Type:** current company / identity page (secondary)
- **Quality:** B
- **Independence group:** `bbb`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bbb.org/us/tx/austin/profile/foundation-contractors/quality-foundation-repair-0825-90081815
- **Supports:** Current Austin operating identity

## S141 — Quality Foundation Repair Founder Profile

- **Publisher:** ArcSite
- **Type:** current company / identity page (secondary)
- **Quality:** C
- **Independence group:** `arcsite`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.arcsite.com/blog/quality-foundation-repair
- **Supports:** Simon Wallace founder/owner evidence

## S142 — Bruecher Foundation

- **Publisher:** Bruecher Foundation
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `bruecher`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bruecherfoundation.com/
- **Supports:** Current Austin residential foundation operation and family-business claim

## S143 — A-Tex Pest Management

- **Publisher:** A-Tex Pest Management
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `atex`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://atexpm.com/
- **Supports:** Current Greater Austin service, local claim, license number

## S144 — A-Tex Leadership

- **Publisher:** A-Tex Pest Management
- **Type:** current company / identity page (secondary)
- **Quality:** C
- **Independence group:** `linkedin`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.linkedin.com/company/a-tex-pest-management/
- **Supports:** Jason Napolski president/CEO lead

## S145 — HomeTeam Pest Defense Austin

- **Publisher:** HomeTeam Pest Defense
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `hometeam`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://pestdefense.com/austin/
- **Supports:** Current Austin service area

## S146 — Bulwark Exterminating Austin

- **Publisher:** Bulwark Exterminating
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `bulwark`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://bulwarkpestcontrol.com/locations/austin/
- **Supports:** Current Austin branch and Seever family ownership

## S147 — Berrett Home Services Austin Pest Control

- **Publisher:** Berrett Home Services
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `berrett`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://berretthomeservices.com/austin-texas/pest-control/
- **Supports:** Current Austin operation and Nathan Berrett/family history

## S148 — Berrett Pest Control BBB Profile

- **Publisher:** Better Business Bureau
- **Type:** current company / identity page (secondary)
- **Quality:** B
- **Independence group:** `bbb`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bbb.org/us/tx/garland/profile/pest-control/berrett-pest-control-0875-90510549
- **Supports:** Nathan Berrett president and corporate identity

## S149 — Alta Pest Control Austin

- **Publisher:** Alta Pest Control
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `alta`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.altapestcontrol.com/locations/austin-tx
- **Supports:** Current Austin/Pflugerville branch

## S150 — Romney Pest Control Austin

- **Publisher:** Romney Pest Control
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `romney`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://romneypestcontrol.com/austin/
- **Supports:** Current Austin service and Greg Romney family ownership

## S151 — Pest Wranglers

- **Publisher:** Pest Wranglers
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `pest_wranglers`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://pestwranglers.com/
- **Supports:** Current Round Rock/Austin operation and local-ownership claim

## S152 — Stride Pest Control

- **Publisher:** Stride Pest Control
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `stride`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://stridepestcontrol.com/
- **Supports:** Current Austin operation, Stride Pest Control LLC, Tyson Kearns owner

## S153 — Orkin Austin

- **Publisher:** Orkin
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `orkin`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.orkin.com/locations/texas-tx/austin-pest-control
- **Supports:** Current Austin branches

## S154 — Terminix Austin

- **Publisher:** Terminix
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `terminix`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.terminix.com/exterminators/tx/austin-pest-control/
- **Supports:** Current Austin branch

## S155 — Hawx Pest Control Austin

- **Publisher:** Hawx Pest Control
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `hawx`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://hawxpestcontrol.com/austin-tx-pest-control/
- **Supports:** Current Austin service page

## S156 — Ranger Termite & Pest Control

- **Publisher:** Ranger Termite & Pest Control
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `ranger`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://rangertermiteandpestcontrolinc.com/
- **Supports:** Current Austin operation since 1996

## S157 — Ranger BBB Profile

- **Publisher:** Better Business Bureau
- **Type:** current company / identity page (secondary)
- **Quality:** B
- **Independence group:** `bbb`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bbb.org/us/tx/austin/profile/pest-control/ranger-termite-pest-control-inc-0825-90002691
- **Supports:** Mark Lipscomb president/director lead

## S158 — EcoShield Pest Solutions Austin

- **Publisher:** EcoShield Pest Solutions
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `ecoshield`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.ecoshieldpest.com/locations/austin-tx
- **Supports:** Current Austin branch

## S159 — Massey Services Austin

- **Publisher:** Massey Services
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `massey`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.masseyservices.com/austin/
- **Supports:** Current Austin branch

## S160 — Massey Services - About

- **Publisher:** Massey Services
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `massey`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.masseyservices.com/about-us/
- **Supports:** Massey family ownership and Tony Massey leadership

## S161 — Natran Green Pest Control Austin

- **Publisher:** Natran Green Pest Control
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `natran`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://natran.com/austin-pest-control/
- **Supports:** Current Austin operation and Gordon Doran ownership

## S162 — X Out Pest Services

- **Publisher:** X Out Pest Services
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `xout`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://xoutpest.com/
- **Supports:** Current Austin operation

## S163 — X Out Pest Services BBB Profile

- **Publisher:** Better Business Bureau
- **Type:** current company / identity page (secondary)
- **Quality:** B
- **Independence group:** `bbb`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.bbb.org/us/tx/austin/profile/pest-control/x-out-pest-services-llc-0825-1000183342
- **Supports:** X Out Pest Services LLC and Dewey Petersen managing member

## S164 — ClearDefense Pest Control Austin

- **Publisher:** ClearDefense Pest Control
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `cleardefense`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://cleardefensepest.com/pest-control-austin-tx/
- **Supports:** Current Austin office and founder-led history

## S165 — Roberts Termite & Pest Control

- **Publisher:** Roberts Termite & Pest Control
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `roberts`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.robertspestcontrol.com/
- **Supports:** Current Greater Austin family-owned operation

## S166 — Absolute Pest Management

- **Publisher:** Absolute Pest Management
- **Type:** current company / identity page (primary)
- **Quality:** B
- **Independence group:** `absolute`
- **Publication date:** not stated
- **Access date:** 2026-07-26
- **URL or file:** https://www.absolutepestmgmt.com/
- **Supports:** Current Austin local family-owned operation and Tony Ragan leadership

## S061 — Apex Service Partners and Alpine Investors Announce Strategic Minority Investment from Apollo

- **Publisher:** Apollo
- **Type:** pending transaction announcement (primary)
- **Quality:** A
- **Independence group:** `apollo`
- **Publication date:** 2026-05
- **Access date:** 2026-07-26
- **URL or file:** https://www.apollo.com/insights-news/pressreleases/2026/05/apex-service-partners-and-alpine-investors-announce-strategic-mi
- **Supports:** Minority investment announced; expected close Q4 2026
