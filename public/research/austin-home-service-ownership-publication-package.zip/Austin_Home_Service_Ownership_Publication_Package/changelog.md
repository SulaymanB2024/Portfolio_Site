# Changelog

## Version 1.0 — 2026-07-26

Initial reconstructed publication package.

### Research-provenance changes

- Recorded that Model A’s named structured files were not available.
- Recorded that Model B did not receive Model A’s files and therefore did not perform a true reconciliation.
- Replaced mismatched Precision and Daniel’s citations.

### Census changes

- Built a 67-brand active publication universe.
- Added the SAS Service Partners/Storr cluster.
- Added Ja-Mar and other current roofing operators.
- Reversed the exclusion of Quality Foundation Repair.
- Added current public-company and local pest-control branches.
- Moved Cool Atmosphere, Dayton Services and Foundation Support Specialists to historical/rebranded status.

### Ownership changes

- Separated current and former sponsors for Stan’s.
- Marked the Blackstone-Champions transaction pending/unresolved.
- Coded Alta as minority-invested and founder-controlled.
- Coded KKR/Neighborly and Apax/Authority Brands at the franchisor level only.
- Updated Groundworks to KKR control with Cortec minority retention.
- Added Ja-Mar → Roofing Services Solutions → Dunes Point Capital.

### Data-quality controls

- Added evidence IDs, access dates, independence groups and evidence notes.
- Required every relationship edge to contain an effective-date marker and source IDs.
- Added conflict and unresolved tables instead of forcing classifications.
- Labeled footprint measures as non-market-share data.

## Future entry template

### Version X.Y — YYYY-MM-DD

**Record affected:**  
**Field changed:**  
**Previous value:**  
**New value:**  
**Effective date:**  
**Reason:**  
**New source IDs:**  
**Submitted by:**  
**Review status:** accepted / rejected / unresolved  
**Reviewer note:**
