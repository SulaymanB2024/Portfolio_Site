# Research Audit Memo

## Decision

The two research reports were not merged as delivered. They were treated as discovery and ownership-lead documents. The final dataset was rebuilt because the evidence package failed basic reconciliation and provenance tests.

## Input audit

### Model A

Model A identified a useful initial brand universe and openly described weaknesses in suburban roofing, foundation repair and the small-operator tail. It also separated included brands, aliases, legal-identity leads, candidate relationships and exclusions in principle.

The central provenance failure is that the eight named structured deliverables were not present. The DOCX contains hyperlinks to paths that do not exist in the uploaded environment. There was no `brands.csv`, alias table, search log or excluded-candidate file to inspect. The original row-level search history and deduplication decisions therefore could not be reproduced. [I001]

### Model B

Model B explicitly states that Model A’s files were unavailable. Its report is an independent top-down pass, not the promised cross-model adjudication. [I002]

Several citations failed claim matching. The Precision row cited a Fox careers page. The Daniel’s row cited FoxNews.com. The Radiant chain used a transaction database where current direct sources were available. Benjamin Franklin’s local-franchisee treatment leaned on HomeAdvisor. Those citations were rejected or replaced.

## Census corrections

The audit retained Model A’s strongest current operators and added brands that had clear current Austin evidence. Material additions include:

- Austin Air Conditioning and Roger’s Plumbing within SAS Service Partners / Storr Group
- Ja-Mar within Roofing Services Solutions / Dunes Point Capital
- ARS/Rescue Rooter Austin
- Mr. Rooter and Benjamin Franklin local franchise records
- Anderson, Silver Creek, Wilson and Austin Roofing and Construction
- Bats and Bruecher Foundation
- Orkin, Terminix, Hawx, Ranger, EcoShield, Massey, Natran, X Out, ClearDefense, Roberts and Absolute

Quality Foundation Repair was moved from exclusion to inclusion after current official, BBB and named-founder evidence was found. Cool Atmosphere was moved in the opposite direction: it remains in the history but not the active denominator because it is now combined into Austin Air Conditioning.

## Ownership corrections

- Southern/Gryphon: Fox, Precision and Daniel’s have direct current and transaction support.
- Stan’s: Treaty Oak is historical; current chain runs through Master Trades Group to L Catterton.
- Abacus: Wrench is the direct parent; Leonard Green and management retain majority, with TSG and Oak Hill significant minorities.
- Service Wizard: Champions is current; Blackstone is pending unless a closing source emerges.
- Groundworks: KKR is controlling/majority; Cortec retained minority positions.
- Alta: Trivest is non-control minority; founders retained control.
- Franchises: KKR/Neighborly and Apax/Authority Brands are franchisor-level chains, not direct local operating-company ownership.
- Ja-Mar: Dunes Point’s acquisition evidence controls the equity classification despite current local wording.

## Accepted evidence patterns

The strongest chains combine a transaction or legal source with a current parent/portfolio source. Examples include Southern/Gryphon, Stan’s/L Catterton, Abacus/Wrench, Service Experts/Brookfield, Groundworks/KKR-Cortec, Aptive/Citation, HomeTeam/Rollins and Terminix/Rentokil.

Named local-owner records are accepted when current company materials and an identity source agree. Examples include Efficient, Excalibur, Whitestone, Crow’s, Baird, Bats, Stride and X Out.

## Rejected inference patterns

The build rejects:

- Ownership inferred only from shared addresses, phone numbers or website templates
- Independence inferred from the absence of acquisition news
- Franchisor ownership presented as local franchisee ownership
- Minority investment presented as total ownership
- Old acquisition announcements used without a current-owner check
- “Local,” “family,” or “founder” wording treated as a single legal status
- Review, permit or search percentages described as market share
- Claims that ownership caused price, service or employment changes without causal evidence

## Final data quality

The active publication universe contains 67 brands. 48 records have A/B ownership structures and are not coded unresolved. 11 remain in the private/control-unresolved bucket. The graph contains 170 nodes and 102 relationships. The evidence ledger contains 130 source records. There are 20 preserved conflicts and 25 unresolved questions.

The package is defensible as a dated ownership map. It is not defensible as a complete licensed-contractor census, a revenue market-share study or a legal opinion on beneficial ownership.
