# Methodology

## Purpose and snapshot

This database maps ownership relationships behind consumer-facing residential home-service brands that advertised or documented current service in the Austin area on **2026-07-26**. It covers HVAC, plumbing, residential electrical when bundled with HVAC or plumbing, roofing and exterior services, foundation repair, and structural pest control.

The published denominator is **67 active Austin-facing brands**. It is a reconstructed publication universe, not a claim that every eligible contractor in the Austin metropolitan area has been found.

## Unit of analysis

The primary counting unit is the **consumer-facing brand**, not the legal entity, office, license, location, sponsor or website. Separate tables represent:

- Brand
- Legal entity
- DBA
- Location or service footprint
- Local franchisee
- Franchise system
- Platform
- Holding company
- Sponsor
- Public parent
- Founder or family owner

A brand can map to several entities. Several brands can map to one platform. A franchise system is not treated as the direct owner of a local franchisee unless direct ownership is independently documented.

## Geographic inclusion

A brand qualifies when a current official source documents an Austin-area office, branch, franchise territory or service area. The working geography includes Austin, Round Rock, Pflugerville, Cedar Park, Leander, Georgetown, Hutto, Manor, Lakeway, Bee Cave, Dripping Springs, Buda, Kyle and other localities a company expressly includes in its Austin or Greater Austin territory.

Presence types are labeled:

- Office or branch
- Headquarters or local base
- Franchise territory
- Service-area / dispatch presence
- Current brand page without a separately verified location

A generic city page was not sufficient when it could not be tied to a real operating identity.

## Census reconstruction

Model A named eight structured deliverables, but those files were not embedded in its DOCX or separately uploaded. Model B stated that it did not receive Model A’s files. The final database was therefore reconstructed from the two narrative reports, their cited leads, direct source review and additional gap searches. [I001][I002]

The reconstruction added or restored multiple current operators, including the SAS Service Partners/Storr cluster, Ja-Mar, Quality Foundation Repair and several local plumbing, roofing, foundation and pest companies. Historical or absorbed brands remain in `master_brands.csv` with a non-denominator status.

## Current-owner test

An old acquisition announcement does not automatically establish current ownership. A current relationship normally requires:

1. Direct evidence that the transaction closed or the relationship existed; and
2. Current evidence that the parent, sponsor, platform or brand relationship remained in force at the snapshot.

Current evidence can include a sponsor portfolio page, parent brand list, privacy policy, terms, annual report, current company page or regulatory record.

Pending agreements are not promoted to current ownership. The Blackstone-Champions agreement is recorded as pending because no closing confirmation was located before the snapshot. Former sponsors are kept in the transaction table and removed from current chains.

## Source hierarchy

1. Current legal terms, privacy policies, state filings and regulatory/license records
2. Current parent, sponsor, platform and public-company disclosures
3. Completed transaction announcements from buyer, seller, target or adviser
4. Current official brand, branch and service-area pages
5. BBB, trade-association and certification identity records
6. Reputable secondary reporting
7. Social, job, directory and search-result leads

Lead-only sources can generate an unresolved question. They do not establish ownership.

## Source independence

Two URLs do not equal two independent sources when both reproduce the same release. Each source has an `independence_group`. Syndicated press releases, portfolio excerpts copied from the target, and search snippets from the same underlying page are treated as one evidence family.

For major platform chains, the preferred pattern is one transaction or legal source plus one current parent/portfolio source. Some local owner records have only a current first-party statement plus a BBB or trade record. Those receive a lower rating when exact equity remains unavailable.

## Evidence ratings

**A — publication grade.** Direct current primary evidence, generally corroborated by a transaction, legal, parent or independent identity source.

**B — strongly supported.** The current structure is persuasive, but an intermediate legal entity, exact percentage, exact date or second independent record is missing.

**C — qualified.** Current self-report, credible identity lead, founder history or provisional relationship. The claim is published with explicit qualification.

**D — unresolved.** Evidence conflicts, is stale, or establishes only the operating brand. No controller conclusion is forced.

## Ownership-interest coding

The database distinguishes:

- Majority ownership
- Minority investment
- Non-control minority investment
- Significant minority investment
- Control percentage unspecified
- Franchise relationship
- Local owner / family control claim
- Current controller unresolved

A company is not labeled “owned by” an investor when the source says only that the investor made a minority investment. Alta is the main example: Trivest is a non-control minority investor and founders retained control. [S054]

## Franchise treatment

Three separate relationships may exist:

1. Brand to local franchisee: `Operated by`
2. Brand to franchise system: `Franchise of`
3. Franchise system to sponsor/public parent: ownership relationship

The third relationship is not applied to the local franchisee. This prevents KKR’s ownership of Neighborly from being misreported as direct ownership of Mr. Rooter Austin or Aire Serv local operators.

## “Local” coding

The following terms are not interchangeable:

- Locally owned: current equity claim
- Locally managed: local leadership
- Locally operated: local staff, office or territory
- Family founded: historical origin
- Founder led: current management role
- Retained local brand: consumer name survives a transaction
- Franchise owned: local operator owns a franchised business

Local/family claims are stored as claims with ratings. A transaction source can override an equity implication while leaving local management or history intact.

## Calculations

Every percentage uses the 67-brand active publication denominator unless otherwise stated. Unresolved records remain in the denominator and are reported separately. Historical, candidate and excluded records are not included.

The metrics are brand-record shares. They are never called market share. No revenue or size ranking is produced without a comparable measure across the universe.

## Graph construction

The default graph includes current brand-to-parent chains. Historical edges, minority investors and intermediate legal entities are optional layers. Every edge contains:

- Start date or explicit `unknown`
- End date when applicable
- Current-status flag
- Relationship status
- Interest type
- Evidence rating
- Source IDs
- Access date
- Evidence note

## Known limitations

- The small suburban and low-web-visibility tail is incomplete.
- Texas legal-entity and assumed-name records were not systematically exported for every brand.
- Pest and plumbing licenses can materially improve identity resolution; roofing lacks the same statewide licensing hook.
- Current owner pages may omit minority investors or intermediate entities.
- Private transactions may not be announced.
- A current service page does not prove a physical local office.
- Ownership does not establish revenue, service quality, pricing or market share.

## Reproduction

A reader can reproduce the central findings by:

1. Filtering `master_brands.csv` to `inclusion_status=published_active`.
2. Counting `current_owner_type` for the denominator and owner buckets.
3. Joining `master_relationships.csv` to `master_entities.csv` on entity IDs.
4. Opening the source IDs in `master_evidence.csv`.
5. Checking `master_conflicts.csv` and `master_unresolved.csv` before treating a chain as settled.
6. Rebuilding the public graph from `graph.json`.
