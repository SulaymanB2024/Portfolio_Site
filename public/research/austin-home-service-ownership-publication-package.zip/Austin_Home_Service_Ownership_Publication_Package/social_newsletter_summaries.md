# Social and Newsletter Summaries

## Social post — data finding

Austin’s home-service market contains more shared ownership than the brand names suggest. We mapped 67 active HVAC, plumbing, roofing, foundation and pest-control brands to their current platforms, public parents, sponsors, franchise systems and local owners as of July 26, 2026. The database preserves minority stakes, pending deals and unresolved cases instead of flattening every company into “local” or “PE-owned.”

## Social post — example

Fox, Precision and Daniel’s appear as separate Austin service brands. All three currently lead to Southern Home Services, then to the Gryphon-backed North American Essential Home Services structure. The map shows the consumer names and the ownership chain side by side, with source IDs for every edge.

## Social post — franchise distinction

KKR owns Neighborly. That does not mean KKR directly owns Mr. Rooter Plumbing of Austin or the local Aire Serv operators. The Austin ownership map separates local franchisees from the franchisor’s parent, one of the most common errors in roll-up research.

## Newsletter short

A new Austin ownership database traces 67 active home-service brands through legal entities, platforms, sponsors, public parents and franchise systems. Fourteen brands sit in sponsor-backed operating platforms, four have public-company parents, five are local franchises, and eleven remain unresolved at the controller level. The package includes a filterable table, graph, transaction timeline, source ledger and correction system. Counts are brand-record shares, not market share.

## Newsletter long

Home-service companies often retain their established names after a sale. That makes a normal search for an HVAC, plumbing, roofing, foundation or pest company a poor guide to who owns the business. This project reconstructs the Austin market at the consumer-brand level, then connects each brand to the current operating platform, legal entity, sponsor, public parent or local owner when the evidence supports it.

The July 26, 2026 snapshot contains 67 active brands. It corrects several common classification errors: Alta’s Trivest investment is minority and non-control; KKR’s ownership of Neighborly sits at the franchisor level; the Blackstone-Champions transaction remains pending without closing evidence; and historical divisional sales do not automatically establish the current owner of an active brand. The full database is downloadable and every relationship carries evidence IDs, dates and an evidence note.
