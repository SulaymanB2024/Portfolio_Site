# Acquisition and Investment Timeline

**Snapshot:** 2026-07-26

Pending transactions do not replace current-owner relationships. Dates marked by year or month reflect the precision available in the cited source.

## 2026

- **2026-05: Apex Service Partners** — Apollo from Alpine Investors / existing holders. minority; Alpine remains involved. Status: `pending_at_snapshot`. Current effect: No Austin-facing Apex house brand was added to the published universe. Sources: S061.
  - Note: Expected close in Q4 2026; included as a warning against premature Apollo ownership labels.
- **2026-02-17: Champions Group Holdings** — Blackstone from Odyssey Investment Partners. control if/when closed. Status: `pending_at_snapshot`. Current effect: No current-owner change recorded without closing evidence. Sources: S024.
  - Note: Expected to close in the first half of 2026; no closing confirmation located by July 26, 2026.

## 2025

- **2025-04-08: Ja-Mar Roofing & Sheet Metal** — Roofing Services Solutions. control. Status: `closed`. Current effect: Ja-Mar remains an active retained brand inside the Dunes Point-backed platform. Sources: S045|S046.

## 2024

- **2024-08-27: Aptive Environmental** — Citation Capital from Existing holders. majority; management significant minority. Status: `closed`. Current effect: Citation is current majority investor. Sources: S052.
- **2024-07-20: Roger’s Plumbing** — SAS Service Partners. control; founder joined platform. Status: `closed`. Current effect: Roger’s remains an active SAS brand. Sources: S038|S040.
  - Note: SAS article and index years conflict; the chronological index date is used.
- **2024-06-07: Cool Atmosphere** — SAS Service Partners. control; founders joined platform. Status: `closed`. Current effect: Brand later combined into Austin Air Conditioning. Sources: S039|S040.
  - Note: SAS article and index years conflict; the chronological index date is used.
- **2024-04: Alta Pest Control** — Trivest Partners from Founders / existing holders. non-control minority; founders retained control. Status: `closed`. Current effect: Alta is not coded as Trivest-controlled. Sources: S054.
- **2024-03-25: Stan’s Home Services Holdings** — The Master Trades Group from Treaty Oak Equity. control. Status: `closed`. Current effect: Stan’s now sits within Master Trades Group. Sources: S011|S012.

## 2023

- **2023-10-03: Austin Air Conditioning** — SAS Service Partners. control with seller rollover equity. Status: `closed`. Current effect: Austin Air remains an active SAS brand. Sources: S037|S040|S044.
  - Note: SAS article and index dates conflict; the chronological index date is used.
- **2023-03: Groundworks** — KKR from Cortec Group / existing holders. KKR control; Cortec retained minority. Status: `closed`. Current effect: KKR is current controller; Cortec remains a minority investor. Sources: S049|S050.

## 2022

- **2022-11-22: Service Wizard Heating & Air Conditioning** — Champions Group Holdings. control. Status: `closed`. Current effect: Service Wizard remains a Champions brand. Sources: S023.
- **2022-11-09: Wrench Group** — TSG Consumer Partners and Oak Hill Capital from Existing Leonard Green and management holders. significant minority; Leonard Green and management retained majority. Status: `closed`. Current effect: Abacus remains a Wrench subsidiary. Sources: S016.
- **2022-10-12: Terminix** — Rentokil Initial plc. control. Status: `closed`. Current effect: Terminix is current Rentokil-owned brand. Sources: S057.
- **2022-07-18: Foundation Support Specialists** — Groundworks. control. Status: `closed`. Current effect: Former brand treated as absorbed/rebranded rather than a separate current record. Sources: S051.
- **2022-04-07: Daniel’s Plumbing & Air Conditioning** — Southern Home Services. control / complete operating-company acquisition not further specified. Status: `closed`. Current effect: Daniel’s remains listed as a Southern Austin brand; consumer-brand activity is flagged. Sources: S003|S004.
- **2022-03-22: LTP Home Services Group / Master Trades Group** — L Catterton. control. Status: `closed`. Current effect: L Catterton is current sponsor of Master Trades Group. Sources: S013|S014.
- **2022: Authority Brands** — British Columbia Investment Management Corporation from Apax and existing holders. significant minority; Apax retained majority. Status: `closed`. Current effect: Franchisor capital structure only. Sources: S031|S032.

## 2021

- **2021-12: Goettl Air Conditioning & Plumbing** — Cortec Group. control percentage unspecified. Status: `closed`. Current effect: Goettl is treated as Cortec-backed. Sources: S019.
- **2021-10: Southern Home Services / NAEHS** — Gryphon Investors from MSouth Equity Partners. majority; management retained meaningful stake. Status: `closed`. Current effect: Gryphon is current controlling sponsor through NAEHS. Sources: S006|S007.
- **2021-03-12: Hawx Services** — PCM Growth. control at transaction date. Status: `closed_then_current_unverified`. Current effect: The 2021 sponsor relationship is documented; current continuity remains unresolved. Sources: S058.
- **2021: Neighborly** — KKR. control. Status: `closed`. Current effect: KKR owns the franchisor, not Austin franchisee operating companies. Sources: S030.

## 2020

- **2020-11: Radiant / T3 Services Group** — The Riverside Company. interest percentage unspecified. Status: `closed`. Current effect: Radiant sits within the Riverside-backed T3 platform. Sources: S009|S010.
  - Note: Riverside dates the T3 investment to November 2020; some secondary accounts describe a 2021 Radiant investment.
- **2020-09-15: American Residential Services** — GI Partners from Charlesbank Capital Partners / prior holders. majority; Charlesbank and management significant minority. Status: `closed`. Current effect: GI remains majority sponsor. Sources: S027|S028.
- **2020-07-18: Fox Service Company** — Southern Home Services. control / complete operating-company acquisition not further specified. Status: `closed`. Current effect: Fox remains a Southern consumer brand. Sources: S002.
  - Note: Close date not separately stated in the source captured.
- **2020-06-30: Precision Heating & Air** — Southern Home Services. control / complete operating-company acquisition not further specified. Status: `closed`. Current effect: Precision remains a Southern consumer brand. Sources: S001.
  - Note: The source states the transaction was completed June 30, 2020.

## 2018

- **2018-10-16: Enercare Inc. (including Service Experts)** — Brookfield Infrastructure. control. Status: `closed`. Current effect: Service Experts remains within Brookfield-controlled Enercare. Sources: S020.
- **2018: Stan’s Home Services** — Treaty Oak Equity. control unspecified. Status: `historical_closed`. Current effect: Treaty Oak was a former sponsor and exited in 2024. Sources: S012.

## 2015

- **2015: EcoShield Austin division (2015 assets)** — Massey Services. Austin division assets. Status: `historical_closed`. Current effect: Does not establish that the present EcoShield Austin brand is owned by Massey. Sources: S059.

## 2008

- **2008-04-03: HomeTeam Pest Defense** — Rollins, Inc.. control. Status: `closed`. Current effect: HomeTeam remains a Rollins brand. Sources: S055|S056.
