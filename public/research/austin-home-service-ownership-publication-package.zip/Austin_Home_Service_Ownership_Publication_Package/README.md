# Austin Home-Service Ownership Publication Package

**Snapshot:** 2026-07-26  
**Active publication denominator:** 67 consumer-facing brands  
**Article length:** 4,255 words

## Start here

- `Austin_Home_Service_Ownership_Publication_Package.docx` — combined publication document
- `article.md` — final linked-source article
- `ownership_graph.html` — interactive layered ownership graph
- `ownership_table.html` — filterable brand table with CSV download
- `acquisition_timeline.html` — interactive transaction chronology
- `mobile_ownership_cards.html` — compact brand-by-brand chains
- `master_dataset.json` — combined machine-readable data
- `methodology.md` — evidence, counting and classification rules
- `source_ledger.md` — full source register
- `QA_REPORT.md` — machine, runtime, accessibility and render checks for the delivered build

## Core data

The eight required `master_*.csv` files are present. `graph.json` contains all nodes, edges and mobile chains. Category-specific graph files and a sponsor/platform view are included. `manifest.csv` records file sizes and SHA-256 hashes for all other packaged files.

## Research inputs and audit boundary

The two source reports are preserved under `source_inputs/`. Model A named eight structured deliverables, but they were not embedded in its DOCX or separately supplied. Model B states that it did not receive Model A’s structured files. This package therefore reconstructs and rechecks the publication universe rather than claiming a literal row-by-row merge of unavailable inputs.

## Important boundary

Percentages are shares of the 67 active Austin-facing consumer-brand records in the reconstructed publication universe. They are not revenue, customer, job, permit, review, search or market share.

The package preserves pending, minority, franchise and unresolved relationships. It does not infer independence from silence, market share from footprint, or causation from ownership. Article source IDs link directly to the cited underlying web pages.

## Reproduce the headline counts

Filter `master_brands.csv` to `inclusion_status=published_active`, then count `current_owner_type`. Join `master_relationships.csv` to `master_entities.csv` on entity IDs and resolve source IDs through `master_evidence.csv`.

Run `python validate_package.py` after rebuilding. The generator is `build_austin_package.py`; the packaged source reports must remain in `source_inputs/` so the source-ledger integrity check can resolve I001 and I002.
