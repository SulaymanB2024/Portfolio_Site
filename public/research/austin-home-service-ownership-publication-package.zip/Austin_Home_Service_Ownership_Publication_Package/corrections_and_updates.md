# Corrections and Update System

## Public correction language

This database is a dated ownership map, not a legal opinion. Companies, owners, investors, employees, reporters and readers may submit documented corrections. Please identify the affected brand and field, state the proposed replacement, give the effective date, and attach or link direct evidence.

Useful evidence includes current legal terms, Texas entity or assumed-name filings, trade-license records, completed transaction announcements, sponsor portfolio pages, annual reports, signed company statements and current franchisee documents. Marketing copy, anonymous posts and unexplained screenshots may generate a review but will not automatically change an ownership classification.

## Submission fields

- Name and contact information
- Relationship to the company or record
- Brand and legal entity
- Field disputed
- Current published value
- Proposed value
- Effective date
- Source URL or document
- Whether the document may be published
- Explanation of any confidential material

## Review workflow

1. Log the submission with a received date.
2. Preserve the current public value during review unless it creates a clear and material factual risk.
3. Check the evidence against the same source hierarchy used for the original database.
4. Seek a second source when the correction changes a controlling owner, interest type, transaction status or franchise relationship.
5. Mark the result accepted, rejected or unresolved.
6. Update the relevant CSV, JSON, graph and card together.
7. Add a changelog entry with the prior value, new value, effective date and source IDs.
8. Retain rejected submissions internally with the reason.

## Fast corrections

Typographical errors, broken source links and obvious duplicate records can be corrected directly with a changelog note. Ownership changes, pending-deal closings, minority/majority classifications and franchisee identities require evidence review.

## Changelog entry

**Date:**  
**Brand/entity:**  
**Field:**  
**Old value:**  
**New value:**  
**Effective date:**  
**Source IDs:**  
**Reason:**  
**Review status:**  
**Reviewer:**

## Versioning

- Patch release: citation, spelling, URL or non-substantive identity fix.
- Minor release: new brand, new legal identity, resolved owner or transaction update.
- Major release: geographic expansion, methodology change or denominator rebuild.

The public page should display the snapshot date, latest modified date and direct links to the changelog and correction form.
