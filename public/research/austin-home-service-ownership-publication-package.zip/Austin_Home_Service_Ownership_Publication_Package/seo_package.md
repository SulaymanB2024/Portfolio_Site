# SEO Package

## Core metadata

**SEO title:** Who Owns Austin HVAC, Plumbing, Roofing and Pest Companies?

**H1:** Who Owns Austin’s Home-Service Companies? A Verified Map of Private Equity, Roll-Ups, and Local Brands

**Meta description:** Explore a sourced ownership map of 67 Austin-area HVAC, plumbing, roofing, foundation and pest-control brands, including private-equity platforms, public parents, franchises and local owners.

**Suggested URL slug:** `/research/who-owns-austin-home-service-companies/`

## Primary query cluster

- who owns Austin home service companies
- Austin HVAC private equity
- Austin plumbing company ownership
- Austin roofing company ownership
- Austin pest control parent company
- Austin foundation repair ownership
- home service roll-ups Austin
- private equity home services Austin
- is [brand] locally owned
- who owns [brand]
- is [brand] owned by private equity

## Brand-specific opportunities

Priority pages or sections should follow demonstrated ownership complexity, not search volume alone:

- Who owns Fox Service Company?
- Who owns Precision Heating & Air?
- Who owns Daniel’s Plumbing and Air Conditioning?
- Who owns Radiant Plumbing?
- Who owns Stan’s Heating and Air?
- Who owns Abacus Plumbing?
- Who owns Service Wizard?
- Who owns Austin Air Conditioning?
- Who owns Roger’s Plumbing?
- Who owns Ja-Mar Roofing?
- Who owns Groundworks?
- Who owns Aptive?
- Is Alta Pest Control private-equity owned?
- Who owns Mr. Rooter Plumbing of Austin?
- Who owns Terminix and Orkin?

A brand page should not exist unless it contains a verified chain, transaction chronology, local-presence evidence, current/ former owner distinction, uncertainty note and original source work.

## Heading structure

1. Who Owns Austin’s Home-Service Companies?
2. One group, several Austin names
2. The ownership map
2. What the 67-brand denominator shows
2. HVAC, plumbing and bundled electrical
3. Southern Home Services and Gryphon
3. Radiant, Stan’s, Abacus and Goettl
3. Service Experts, Service Wizard and ARS
3. The SAS/Storr cluster
2. Roofing and exterior services
2. Foundation repair
2. Pest control
2. What “local” actually means
2. Selected ownership cards
2. How ownership was verified
2. What the data cannot establish
2. Corrections and updates

## Dataset structured data

Use `Dataset` with:

- `name`
- `description`
- `datePublished`
- `dateModified`
- `temporalCoverage`: `2026-07-26`
- `spatialCoverage`: Austin-Round Rock-Georgetown area
- `creator`
- `publisher`
- `license`
- `isAccessibleForFree`
- `keywords`
- `variableMeasured`
- `distribution` entries using `DataDownload` for each CSV and JSON file
- `includedInDataCatalog` if a persistent research catalog is created
- `measurementTechnique` pointing to the methodology page

Do not put the 67-brand count in `spatialCoverage` or describe it as a market census.

## Article structured data

Use `Article` or `NewsArticle` only if the page meets editorial-news criteria. Include:

- headline and description
- author and publisher
- datePublished / dateModified
- mainEntityOfPage
- about entities for home services, private equity and Austin
- citation links to primary sources
- `isBasedOn` pointing to the dataset and methodology
- `hasPart` for interactive graph, timeline and table

Also use `BreadcrumbList`. Do not use `FAQPage` unless the questions and answers are visibly rendered and the site’s implementation complies with current search-engine guidance.

## Internal-link plan for sulayman-bowles.dev

- Research index → ownership article
- Ownership article → Search Visibility Due Diligence for Buying a Small Business
- Ownership article → Austin home-service market / PE roll-up methodology
- Ownership article → source methodology and correction log
- Search diligence article → ownership dataset as an example of brand/entity separation
- VOID service page → methodology, not an unsupported transaction-experience claim
- Relevant brand pages → master article and category section
- Future acquisition or consolidation research → transaction timeline

Anchor text should identify the exact asset: “Austin home-service ownership database,” “current sponsor and parent map,” or “home-service transaction timeline.”

## Future pages from the verified dataset

1. Category pages for HVAC/plumbing, roofing, foundation and pest only if each includes a distinct graph, findings, transactions and unresolved records.
2. Sponsor/platform profiles where at least two Austin-facing brands or a materially complex chain exist.
3. Brand ownership pages for the priority list above.
4. A corrections/changelog page with dated updates.
5. A methodology page explaining franchise, minority and current-owner rules.
6. A Texas expansion only after systematic state license and entity collection.

Avoid thin pages that merely repeat the parent name and acquisition date.
