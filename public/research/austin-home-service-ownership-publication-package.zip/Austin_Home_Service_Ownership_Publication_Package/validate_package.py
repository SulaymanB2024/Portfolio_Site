#!/usr/bin/env python3
"""Reproduce core integrity checks for the Austin home-service ownership package."""
from __future__ import annotations

from collections import Counter
from pathlib import Path
import csv
import json
import re
import subprocess
import tempfile
import zipfile

BASE = Path(__file__).resolve().parent


def read_csv(name: str) -> list[dict[str, str]]:
    with (BASE / name).open(encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def split_ids(value: str) -> list[str]:
    return [x.strip() for x in re.split(r"[|,]", value or "") if x.strip()]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def unique(rows: list[dict[str, str]], field: str, name: str) -> set[str]:
    values = [r[field] for r in rows]
    require(all(values), f"{name}: blank {field}")
    require(len(values) == len(set(values)), f"{name}: duplicate {field}")
    return set(values)


def check_source_refs(rows: list[dict[str, str]], fields: list[str], source_ids: set[str], name: str) -> None:
    for row in rows:
        for field in fields:
            for sid in split_ids(row.get(field, "")):
                require(sid in source_ids, f"{name}: unknown source {sid} in {field}")


def main() -> dict:
    brands = read_csv("master_brands.csv")
    entities = read_csv("master_entities.csv")
    relationships = read_csv("master_relationships.csv")
    transactions = read_csv("master_transactions.csv")
    evidence = read_csv("master_evidence.csv")
    footprints = read_csv("master_footprint.csv")
    conflicts = read_csv("master_conflicts.csv")
    unresolved = read_csv("master_unresolved.csv")

    brand_ids = unique(brands, "brand_id", "brands")
    entity_ids = unique(entities, "entity_id", "entities")
    relationship_ids = unique(relationships, "relationship_id", "relationships")
    transaction_ids = unique(transactions, "transaction_id", "transactions")
    source_ids = unique(evidence, "source_id", "evidence")
    footprint_ids = unique(footprints, "footprint_id", "footprints")
    conflict_ids = unique(conflicts, "conflict_id", "conflicts")
    unresolved_ids = unique(unresolved, "unresolved_id", "unresolved")

    # Source ledger integrity.
    urls = [r["url"] for r in evidence]
    for row in evidence:
        url = row["url"]
        if row["source_id"].startswith("I"):
            require(not Path(url).is_absolute(), f"evidence: input source uses absolute path {url}")
            require((BASE / url).exists(), f"evidence: packaged input source missing {url}")
        else:
            require(url.startswith(("https://", "http://")), f"evidence: invalid URL scheme for {row['source_id']}")
    require(len(urls) == len(set(urls)), "evidence: duplicate URLs")
    require(not any("utm_source=chatgpt.com" in u for u in urls), "evidence: chatgpt tracking parameter remains")
    require(all(r["access_date"] == "2026-07-26" for r in evidence), "evidence: inconsistent access date")

    check_source_refs(brands, ["presence_source_ids", "ownership_source_ids"], source_ids, "brands")
    check_source_refs(entities, ["source_ids"], source_ids, "entities")
    check_source_refs(relationships, ["source_ids"], source_ids, "relationships")
    check_source_refs(transactions, ["source_ids"], source_ids, "transactions")
    check_source_refs(footprints, ["source_ids"], source_ids, "footprints")
    check_source_refs(conflicts, ["source_ids_a", "source_ids_b"], source_ids, "conflicts")
    check_source_refs(unresolved, ["source_ids"], source_ids, "unresolved")

    # Brand denominator and published findings.
    active = [r for r in brands if r["inclusion_status"] == "published_active"]
    require(len(active) == 67, f"active denominator is {len(active)}, expected 67")
    require(all(r["consumer_brand_status"] == "active" for r in active), "active denominator contains non-active record")
    require(all(r["austin_presence_status"] == "verified_current" for r in active), "active denominator contains unverified Austin presence")
    require(all(split_ids(r["presence_source_ids"]) for r in active), "active record missing presence sources")
    require(all(split_ids(r["ownership_source_ids"]) for r in active), "active record missing ownership sources")
    require(all(r["snapshot_date"] == "2026-07-26" for r in active), "active record snapshot mismatch")

    expected_owner_counts = {
        "Founder/family/local ownership": 32,
        "Sponsor-backed platform": 14,
        "Public-company owned": 4,
        "Local franchise operator": 5,
        "Private/control unresolved": 11,
        "Minority-invested, founder-controlled": 1,
    }
    owner_counts = Counter(r["current_owner_type"] for r in active)
    require(dict(owner_counts) == expected_owner_counts, f"owner counts mismatch: {owner_counts}")
    require(sum(owner_counts.values()) == 67, "owner buckets do not reconcile")

    def sector(row: dict[str, str]) -> str:
        p = row["primary_category"]
        if p in {"HVAC / plumbing / electrical", "HVAC", "HVAC / plumbing", "Plumbing", "HVAC / electrical / plumbing"}:
            return "HVAC, plumbing and electrical"
        if p in {"Roofing / exterior", "Roofing"}:
            return "Roofing and exterior"
        return p

    expected_sector_counts = {
        "HVAC, plumbing and electrical": 26,
        "Roofing and exterior": 9,
        "Foundation repair": 12,
        "Pest control": 20,
    }
    sector_counts = Counter(sector(r) for r in active)
    require(dict(sector_counts) == expected_sector_counts, f"sector counts mismatch: {sector_counts}")
    require(sum(r["franchise_flag"].lower() == "true" for r in active) == 5, "franchise count mismatch")
    require(sum(r["retained_consumer_brand_after_transaction"].lower() == "true" for r in active) == 11, "retained-name count mismatch")
    require(sum(r["current_owner_type"] == "Private/control unresolved" for r in active) == 11, "unresolved owner bucket mismatch")
    high_medium_non_unresolved = sum(
        r["evidence_rating"] in {"A", "B"} and not r["ownership_verification_status"].startswith("unresolved")
        for r in active
    )
    require(high_medium_non_unresolved == 48, f"A/B non-unresolved count mismatch: {high_medium_non_unresolved}")

    # Relationship/graph integrity.
    allowed_edges = {
        "DBA of", "Operated by", "Subsidiary of", "Majority owned by", "Minority investment from",
        "Portfolio company of", "Franchise of", "Acquired by", "Sold by", "Combined with",
        "Rebranded as", "Locally managed by",
    }
    for r in relationships:
        require(r["from_entity_id"] in entity_ids, f"relationship {r['relationship_id']} bad from endpoint")
        require(r["to_entity_id"] in entity_ids, f"relationship {r['relationship_id']} bad to endpoint")
        require(r["edge_type"] in allowed_edges, f"relationship {r['relationship_id']} bad edge type")
        require(r["start_date"], f"relationship {r['relationship_id']} missing effective-date marker")
        require(r["current_status"] in {"True", "False"}, f"relationship {r['relationship_id']} bad current flag")
        require(r["evidence_rating"] in {"A", "B", "C", "D"}, f"relationship {r['relationship_id']} bad rating")
        require(split_ids(r["source_ids"]), f"relationship {r['relationship_id']} missing source")
        require(r["access_date"] == "2026-07-26", f"relationship {r['relationship_id']} bad access date")
        require(r["evidence_note"], f"relationship {r['relationship_id']} missing evidence note")
        require(int(r["supporting_source_count"]) == len(split_ids(r["source_ids"])), f"relationship {r['relationship_id']} source count mismatch")
        require(int(r["independent_source_group_count"]) >= 1, f"relationship {r['relationship_id']} has no independence group")

    graph = json.loads((BASE / "graph.json").read_text(encoding="utf-8"))
    require(len(graph["nodes"]) == len(entities) == 170, "graph/entity node count mismatch")
    require(len(graph["edges"]) == len(relationships) == 102, "graph edge count mismatch")
    require(len(graph["mobile_chains"]) == 67, "graph mobile chain count mismatch")
    require({n["entity_id"] for n in graph["nodes"]} == entity_ids, "graph nodes differ from master_entities")
    require({e["relationship_id"] for e in graph["edges"]} == relationship_ids, "graph edges differ from master_relationships")

    master = json.loads((BASE / "master_dataset.json").read_text(encoding="utf-8"))
    require(len(master["brands"]) == len(brands), "master_dataset brands mismatch")
    require(len(master["entities"]) == len(entities), "master_dataset entities mismatch")
    require(len(master["relationships"]) == len(relationships), "master_dataset relationships mismatch")
    require(len(master["transactions"]) == len(transactions), "master_dataset transactions mismatch")
    require(len(master["evidence"]) == len(evidence), "master_dataset evidence mismatch")
    require(len(master["footprints"]) == len(footprints), "master_dataset footprints mismatch")
    require(len(master["conflicts"]) == len(conflicts), "master_dataset conflicts mismatch")
    require(len(master["unresolved"]) == len(unresolved), "master_dataset unresolved mismatch")

    findings = json.loads((BASE / "verified_findings.json").read_text(encoding="utf-8"))
    require(findings["headline_denominator_active_austin_facing_brands"] == 67, "findings denominator mismatch")
    require(findings["owner_type_counts"] == expected_owner_counts, "findings owner counts mismatch")
    require(findings["sector_counts"] == expected_sector_counts, "findings sector counts mismatch")
    require(findings["relationship_count"] == 102, "findings relationship count mismatch")
    require(findings["transaction_count"] == 29, "findings transaction count mismatch")
    require(findings["source_count"] == 130, "findings source count mismatch")

    # JSON and HTML package integrity.
    json_names = [
        "a11y_report.json",
        "graph.json",
        "graph_foundation_repair.json",
        "graph_hvac_plumbing_electrical.json",
        "graph_pest_control.json",
        "graph_roofing_exterior.json",
        "graph_sponsor_platform_view.json",
        "master_dataset.json",
        "ownership_cards.json",
        "verified_findings.json",
    ]
    json_files = [BASE / name for name in json_names]
    for p in json_files:
        json.loads(p.read_text(encoding="utf-8"))
    html_files = list(BASE.glob("*.html"))
    for p in html_files:
        text = p.read_text(encoding="utf-8")
        require("__DATA__" not in text, f"{p.name}: unresolved data placeholder")
        require("<html" in text.lower() and "</html>" in text.lower(), f"{p.name}: malformed HTML shell")
        scripts = re.findall(r"<script>(.*?)</script>", text, flags=re.S | re.I)
        for i, script in enumerate(scripts):
            with tempfile.NamedTemporaryFile("w", suffix=".js", encoding="utf-8", delete=False) as fh:
                fh.write(script)
                temp_name = fh.name
            proc = subprocess.run(["node", "--check", temp_name], capture_output=True, text=True)
            Path(temp_name).unlink(missing_ok=True)
            require(proc.returncode == 0, f"{p.name}: JavaScript syntax error: {proc.stderr.strip()}")

    # Article source links and length.
    article = (BASE / "article.md").read_text(encoding="utf-8")
    cited = re.findall(r"\[(S\d{3})\]\((https?://[^)]+)\)", article)
    require(cited, "article has no linked source citations")
    for sid, url in cited:
        require(sid in source_ids, f"article unknown source {sid}")
        expected_url = next(r["url"] for r in evidence if r["source_id"] == sid)
        require(url == expected_url, f"article URL mismatch for {sid}")
    stripped_article = re.sub(r"\[(S\d{3})\]\(https?://[^)]+\)", r"[\1]", article)
    stripped_article = re.sub(r"<!--.*?-->", "", stripped_article, flags=re.S)
    article_words = len(re.findall(r"\b[\w’'-]+\b", stripped_article))
    require(4000 <= article_words <= 6000, f"article word count outside target: {article_words}")
    require("170 entity nodes" in article, "article node count is stale")

    # DOCX structure and accessibility report.
    docx_path = BASE / "Austin_Home_Service_Ownership_Publication_Package.docx"
    require(docx_path.exists() and docx_path.stat().st_size > 0, "DOCX missing")
    with zipfile.ZipFile(docx_path) as zf:
        bad = zf.testzip()
        require(bad is None, f"DOCX ZIP member failed CRC: {bad}")
        require("word/document.xml" in zf.namelist(), "DOCX document.xml missing")
    a11y = json.loads((BASE / "a11y_report.json").read_text(encoding="utf-8"))
    require(a11y["counts"]["high"] == 0, "DOCX a11y high-severity findings")
    require(a11y["counts"]["medium"] == 0, "DOCX a11y medium-severity findings")

    return {
        "status": "PASS",
        "snapshot_date": "2026-07-26",
        "counts": {
            "active_brands": len(active),
            "all_brand_records": len(brands),
            "entities": len(entities),
            "relationships": len(relationships),
            "transactions": len(transactions),
            "evidence_sources": len(evidence),
            "footprints": len(footprints),
            "conflicts": len(conflicts),
            "unresolved": len(unresolved),
            "html_assets": len(html_files),
            "json_assets": len(json_files),
            "article_words_excluding_link_urls": article_words,
            "linked_article_citations": len(cited),
        },
        "owner_type_counts": dict(owner_counts),
        "sector_counts": dict(sector_counts),
        "docx_a11y": a11y["counts"],
    }


if __name__ == "__main__":
    result = main()
    print(json.dumps(result, indent=2, ensure_ascii=False))
