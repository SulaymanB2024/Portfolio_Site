from __future__ import annotations

from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime
import csv
import json
import math
import re
import textwrap
import zipfile

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

OUT = Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)
SNAPSHOT_DATE = '2026-07-26'
ACCESS_DATE = '2026-07-26'

# ---------------------------
# Helpers
# ---------------------------

def clean_url(url: str) -> str:
    return re.sub(r'([?&])utm_source=chatgpt\.com(&|$)', lambda m: '' if m.group(1) == '?' else m.group(1), url).rstrip('?&')

sources: list[dict] = []
source_by_id: dict[str, dict] = {}

def add_source(
    sid: str,
    title: str,
    url: str,
    publisher: str,
    source_type: str,
    primary_secondary: str,
    independence_group: str,
    quality_rating: str,
    publication_date: str = '',
    supports_claims: str = '',
    notes: str = '',
) -> str:
    row = {
        'source_id': sid,
        'title': title,
        'url': clean_url(url),
        'publisher': publisher,
        'source_type': source_type,
        'publication_date': publication_date,
        'access_date': ACCESS_DATE,
        'primary_secondary': primary_secondary,
        'independence_group': independence_group,
        'quality_rating': quality_rating,
        'supports_claims': supports_claims,
        'notes': notes,
    }
    if sid in source_by_id:
        raise ValueError(f'Duplicate source ID {sid}')
    sources.append(row)
    source_by_id[sid] = row
    return sid


def source_join(*ids: str) -> str:
    vals: list[str] = []
    for x in ids:
        if not x:
            continue
        vals.extend([v for v in str(x).split('|') if v])
    out: list[str] = []
    seen = set()
    for v in vals:
        if v not in seen:
            out.append(v)
            seen.add(v)
    return '|'.join(out)

# ---------------------------
# Evidence ledger
# ---------------------------

add_source('I001', 'Austin Home-Service Market Census', 'source_inputs/Austin Home-Service Market Census.docx', 'Deep Research Model A', 'uploaded research report', 'research input', 'model_a', 'C', supports_claims='market discovery, inclusion leads, coverage gaps', notes='Structured deliverables named in the report were not embedded in the DOCX or separately uploaded; the report is treated as a discovery memo, not a source-of-truth dataset.')
add_source('I002', 'Who Owns Austin’s Home-Service Companies', 'source_inputs/Who Owns Austin’s Home-Service Companies.docx', 'Deep Research Model B', 'uploaded research report', 'research input', 'model_b', 'C', supports_claims='ownership leads and transaction chronology', notes='The report states that it did not receive Model A’s structured files. Several row-level citations were mismatched and were replaced in this package.')

# Platform and sponsor sources
add_source('S001', 'Southern Home Services Acquires Austin-based Precision Heating & Air Conditioning', 'https://www.southernhomeservices.com/blog/2020/july/southern-home-services-acquires-austin-based-pre/', 'Southern Home Services', 'transaction announcement', 'primary', 'southern', 'A', '2020-07', 'Precision acquisition and retained brand')
add_source('S002', 'Southern HVAC Expands into Texas With Fox Service Company Acquisition', 'https://www.southernhomeservices.com/blog/2020/july/southern-hvactm-expands-into-texas-with-fox-serv/', 'Southern Home Services', 'transaction announcement', 'primary', 'southern', 'A', '2020-07', 'Fox acquisition')
add_source('S003', 'Southern Home Services Announces Acquisition of Daniel’s Plumbing and Air Conditioning', 'https://www.southernhomeservices.com/blog/2022/april/', 'Southern Home Services', 'transaction archive', 'primary', 'southern', 'A', '2022-04-07', 'Daniel’s acquisition announcement')
add_source('S004', 'Daniel’s Plumbing and Air Conditioning | Austin, TX', 'https://www.southernhomeservices.com/daniels/', 'Southern Home Services', 'current brand page', 'primary', 'southern', 'A', supports_claims='Daniel’s current brand listing and Austin service')
add_source('S005', 'Southern Home Services Site Map', 'https://www.southernhomeservices.com/site-map/', 'Southern Home Services', 'current corporate page', 'primary', 'southern', 'A', supports_claims='Current listing of Fox, Precision, and Daniel’s brands')
add_source('S006', 'North American Essential Home Services', 'https://www.gryphon-inv.com/companies/north-american-essential-home-services-naehs/', 'Gryphon Investors', 'current portfolio page', 'primary', 'gryphon', 'A', supports_claims='Current Gryphon portfolio relationship to Southern Home Services holding structure')
add_source('S007', 'Gryphon Investors Completes Majority Investment in Southern Home Services', 'https://www.southernhomeservices.com/blog/2021/october/gryphon-investors-completes-majority-investment-/', 'Southern Home Services / Gryphon Investors', 'transaction announcement', 'primary', 'southern_gryphon_release', 'A', '2021-10', 'Gryphon majority investment; management retained meaningful stake')
add_source('S008', 'Radiant Home Maintenance Plan Terms', 'https://radiantplumbing.com/maintenance-plan/', 'Radiant Plumbing & Air Conditioning', 'current legal terms', 'primary', 'radiant', 'A', supports_claims='Radiant Plumbing Service, LLC doing business as Radiant')
add_source('S009', 'T3 Services Group Partners', 'https://www.t3servicesgroup.com/', 'T3 Services Group', 'current platform page', 'primary', 't3', 'A', supports_claims='Radiant listed within T3 platform')
add_source('S010', 'T3 Services Group', 'https://www.riversidecompany.com/investment-portfolio/t3-services-group', 'The Riverside Company', 'current portfolio page', 'primary', 'riverside', 'A', '2020-11', 'Current Riverside portfolio relationship to T3')
add_source('S011', 'The Master Trades Group Acquires Stan’s Home Services', 'https://www.prnewswire.com/news-releases/the-master-trades-group-acquires-stans-home-services-302098640.html', 'The Master Trades Group', 'transaction announcement', 'primary', 'mtg_release', 'A', '2024-03-25', 'Completed acquisition of Stan’s by Master Trades Group')
add_source('S012', 'Treaty Oak Equity Sells Stan’s Home Services', 'https://treatyoak.com/', 'Treaty Oak Equity', 'seller announcement / portfolio history', 'primary', 'treaty_oak', 'B', '2024-03', 'Treaty Oak historical ownership and exit')
add_source('S013', 'Master Trades Group (fka LTP Home Services Group)', 'https://www.lcatterton.com/investments.html', 'L Catterton', 'current portfolio page', 'primary', 'l_catterton', 'A', supports_claims='Current L Catterton investment in Master Trades Group')
add_source('S014', 'L Catterton to Acquire LTP Home Services Group', 'https://www.lcatterton.com/Press.html', 'L Catterton', 'transaction announcement', 'primary', 'l_catterton', 'A', '2022-03-22', 'L Catterton acquisition of LTP, now Master Trades Group')
add_source('S015', 'Abacus Privacy Policy', 'https://www.abacusplumbing.com/privacy-policy/', 'Abacus Plumbing, Air Conditioning & Electrical', 'current legal policy', 'primary', 'abacus', 'A', supports_claims='Abacus described as wholly owned subsidiary of Wrench Group, LLC')
add_source('S016', 'TSG Consumer Partners and Oak Hill Partner with Leonard Green and Management', 'https://www.wrenchgroup.com/articles/tsg-consumer-partners-and-oak-hill-partner-with-leonard-green-and-management-to-enhance-the-wrench-groups-next-phase-of-growth', 'Wrench Group', 'transaction announcement', 'primary', 'wrench_release', 'A', '2022-11-09', 'Leonard Green and management retained majority; TSG and Oak Hill made significant minority investment')
add_source('S017', 'Wrench Group Portfolio Company', 'https://www.leonardgreen.com/', 'Leonard Green & Partners', 'current sponsor page', 'primary', 'leonard_green', 'B', supports_claims='Current Wrench Group sponsor relationship')
add_source('S018', 'Goettl Austin', 'https://www.goettl.com/austin/', 'Goettl Air Conditioning & Plumbing', 'current local service page', 'primary', 'goettl', 'A', supports_claims='Current Austin service; Dayton Services history/rebrand')
add_source('S019', 'Cortec Group Investment in Goettl', 'https://www.cortecgroup.com/', 'Cortec Group', 'sponsor portfolio / transaction page', 'primary', 'cortec', 'A', '2021-12', 'Cortec investment in Goettl')
add_source('S020', 'Brookfield Infrastructure Completes Acquisition of Enercare', 'https://bip.brookfield.com/press-releases/bip/brookfield-infrastructure-completes-c43-billion-acquisition-enercare-inc', 'Brookfield Infrastructure', 'transaction announcement', 'primary', 'brookfield', 'A', '2018-10-16', 'Enercare and Service Experts acquisition completed')
add_source('S021', 'Strand Brothers Service Experts - Austin', 'https://www.serviceexperts.com/austin-tx/', 'Service Experts', 'current local service page', 'primary', 'service_experts', 'A', supports_claims='Current Austin Strand Brothers operation')
add_source('S022', 'Brookfield Infrastructure 2025 Annual Report', 'https://bip.brookfield.com/sites/brookfield-bip-v2/files/Brookfield-BIP-IR-V2/BIPC/annual-reports/bip-2025-20-f.pdf', 'Brookfield Infrastructure', 'annual report', 'primary', 'brookfield', 'A', '2026', 'Current Brookfield ownership reporting for operating businesses including Service Experts')
add_source('S023', 'Champions Group Acquires Service Wizard of Austin', 'https://championsgroupholdings.com/2022/11/22/growth-continues-with-service-wizard-of-austin/', 'Champions Group Holdings', 'transaction announcement', 'primary', 'champions', 'A', '2022-11-22', 'Service Wizard acquisition')
add_source('S024', 'Blackstone Announces Agreement to Acquire Champions Group', 'https://www.blackstone.com/news/press/blackstone-announces-agreement-to-acquire-champions-group/', 'Blackstone', 'pending transaction announcement', 'primary', 'blackstone', 'A', '2026-02-17', 'Agreement to acquire Champions; expected close in first half of 2026')
add_source('S025', 'Service Wizard Austin', 'https://servicewizardac.com/', 'Service Wizard Heating & Air Conditioning', 'current local service page', 'primary', 'service_wizard', 'A', supports_claims='Current Austin/Hutto operation')
add_source('S026', 'ARS/Rescue Rooter Austin', 'https://www.ars.com/austin', 'ARS/Rescue Rooter', 'current local service page', 'primary', 'ars', 'A', supports_claims='Current Austin residential HVAC/plumbing operation')
add_source('S027', 'GI Partners Acquires Majority Interest in American Residential Services', 'https://www.gipartners.com/', 'GI Partners', 'transaction / portfolio page', 'primary', 'gi_partners', 'A', '2020-09-15', 'GI majority investment; Charlesbank and management retained significant stakes')
add_source('S028', 'American Residential Services Portfolio', 'https://www.gipartners.com/portfolio/', 'GI Partners', 'current portfolio page', 'primary', 'gi_partners', 'A', supports_claims='Current ARS portfolio relationship')
add_source('S029', 'Mr. Rooter Plumbing of Austin', 'https://www.mrrooter.com/austin/', 'Mr. Rooter Plumbing', 'current local franchise page', 'primary', 'mr_rooter_austin', 'A', supports_claims='Brett Bidwell identified as local owner; independently owned and operated')
add_source('S030', 'KKR Completes Acquisition of Neighborly', 'https://www.kkr.com/newsroom/news/news-details/2021/kkr-completes-acquisition-neighborly', 'KKR', 'transaction announcement', 'primary', 'kkr', 'A', '2021', 'KKR acquisition of Neighborly completed')
add_source('S031', 'Authority Brands', 'https://www.apax.com/partnerships/authority-brands/', 'Apax Partners', 'current portfolio page', 'primary', 'apax', 'A', supports_claims='Apax current majority owner of Authority Brands')
add_source('S032', 'BCI Corporate Annual Report 2022-2023', 'https://www.bci.ca/wp-content/uploads/2018/01/2022-2023-corporate-annual-report_financial-statements-2.pdf', 'British Columbia Investment Management Corporation', 'annual report', 'primary', 'bci', 'A', '2023', 'BCI significant minority investment in Authority Brands')
add_source('S033', 'Benjamin Franklin Plumbing of Austin', 'https://www.benjaminfranklinplumbing.com/austin/', 'Benjamin Franklin Plumbing', 'current local franchise page', 'primary', 'ben_franklin_austin', 'B', supports_claims='Current Austin franchise and local-operation claim; local franchisee legal identity not established')
add_source('S034', 'Aire Serv of Cedar Park', 'https://www.aireserv.com/cedar-park/', 'Aire Serv', 'current local franchise page', 'primary', 'aireserv_cedar_park', 'B', supports_claims='Current Cedar Park/Leander franchise; independently owned and operated')
add_source('S035', 'Aire Serv of Round Rock', 'https://www.aireserv.com/round-rock/', 'Aire Serv', 'current local franchise page', 'primary', 'aireserv_round_rock', 'A', supports_claims='Current Round Rock/Austin service and Chris Rattray owner/operator')
add_source('S036', 'Aire Serv is a Neighborly Company', 'https://www.aireserv.com/about/', 'Aire Serv / Neighborly', 'current franchisor page', 'primary', 'neighborly', 'A', supports_claims='Aire Serv membership in Neighborly franchise system')

# SAS / Storr cluster
add_source('S037', 'SAS Service Partners Acquires Austin Air Conditioning', 'https://sasservicepartners.com/news/austin-air-conditioning', 'SAS Service Partners', 'transaction announcement', 'primary', 'sas', 'A', '2023-10-03', 'Austin Air Conditioning acquisition and Storr backing', notes='The article page’s rendered date conflicts with the SAS news index. This package uses the chronological news index date and logs the conflict.')
add_source('S038', 'SAS Service Partners Acquires Roger’s Plumbing', 'https://sasservicepartners.com/news/rogers-plumbing', 'SAS Service Partners', 'transaction announcement', 'primary', 'sas', 'A', '2024-07-20', 'Roger’s Plumbing acquisition and Storr backing', notes='The article page’s rendered year conflicts with the SAS news index. This package uses the chronological news index date and logs the conflict.')
add_source('S039', 'Cool Atmosphere Joins SAS Service Partners', 'https://sasservicepartners.com/news/cool-atmosphere', 'SAS Service Partners', 'transaction announcement', 'primary', 'sas', 'A', '2024-06-07', 'Cool Atmosphere acquisition and Storr backing', notes='The article page’s rendered year conflicts with the SAS news index. This package uses the chronological news index date and logs the conflict.')
add_source('S040', 'SAS Service Partners News Index', 'https://sasservicepartners.com/news', 'SAS Service Partners', 'current transaction index', 'primary', 'sas', 'A', supports_claims='Chronology for Austin Air Conditioning, Cool Atmosphere, and Roger’s Plumbing acquisitions')
add_source('S041', 'Austin Air Conditioning', 'https://austinairconditioning.com/', 'Austin Air Conditioning', 'current local service page', 'primary', 'austin_air', 'A', supports_claims='Current Austin operation and locally operated wording')
add_source('S042', 'Roger’s Plumbing', 'https://callrogersplumbing.com/', 'Roger’s Plumbing', 'current local service page', 'primary', 'rogers_plumbing', 'A', supports_claims='Current Leander/Austin plumbing operation')
add_source('S043', 'Cool Atmosphere', 'https://coolatmosphereheatingandair.com/', 'Cool Atmosphere', 'current brand page / redirect', 'primary', 'cool_atmosphere', 'B', supports_claims='Current combination into Austin Air Conditioning')
add_source('S044', 'SAS Service Partners Meet the Team Archive', 'https://sasservicepartners.com/meet-the-team-old', 'SAS Service Partners', 'current/archive company page', 'primary', 'sas', 'B', supports_claims='Austin Air transaction closed; seller rolled substantial equity')

# Roofing, foundation, pest platform sources
add_source('S045', 'Roofing Services Solutions Acquires Ja-Mar Roofing & Sheet Metal', 'https://www.dunespointcapital.com/news/roofing-services-solutions-acquires-ja-mar-roofing-sheet-metal/', 'Dunes Point Capital', 'transaction announcement', 'primary', 'dunes_point', 'A', '2025-04-08', 'Ja-Mar acquisition')
add_source('S046', 'Roofing Services Solutions', 'https://www.dunespointcapital.com/portfolio/roofing-services-solutions/', 'Dunes Point Capital', 'current portfolio page', 'primary', 'dunes_point', 'A', supports_claims='Current Dunes Point Capital ownership of Roofing Services Solutions')
add_source('S047', 'Ja-Mar Roofing & Sheet Metal', 'https://jamarroofing.com/', 'Ja-Mar Roofing & Sheet Metal', 'current company page', 'primary', 'ja_mar', 'A', supports_claims='Current Austin operation; local-owner/local-company wording')
add_source('S048', 'Groundworks Austin', 'https://www.groundworks.com/service-areas/foundation-repair-austin-tx/', 'Groundworks', 'current service-area page', 'primary', 'groundworks', 'A', supports_claims='Current Austin service from San Antonio-area office')
add_source('S049', 'KKR Makes Significant Investment in Groundworks', 'https://www.groundworks.com/resources/kkr-makes-significant-investment-in-groundworks/', 'Groundworks / KKR', 'transaction announcement', 'primary', 'groundworks_kkr_release', 'A', '2023-03', 'KKR control/significant investment; Cortec remained shareholder')
add_source('S050', 'Cortec Groundworks Investment History', 'https://www.cortecgroup.com/portfolio/groundworks/', 'Cortec Group', 'portfolio history', 'primary', 'cortec', 'A', '2026-05', 'Cortec exited majority in March 2023 and retained minority positions')
add_source('S051', 'Groundworks Acquires Foundation Support Specialists', 'https://www.groundworks.com/resources/groundworks-acquires-foundation-support-specialists/', 'Groundworks', 'transaction announcement', 'primary', 'groundworks', 'A', '2022-07-18', 'Foundation Support Specialists acquisition')
add_source('S052', 'Citation Capital Acquires Majority Stake in Aptive Environmental', 'https://www.citationcapital.com/news/citation-capital-invests-in-aptive-environmental', 'Citation Capital', 'transaction announcement', 'primary', 'citation', 'A', '2024-08-27', 'Citation majority stake; management retained significant interest')
add_source('S053', 'Aptive Austin Branch', 'https://aptivepestcontrol.com/locations/texas-tx/austin-pest-control/local-branch/', 'Aptive Environmental', 'current local branch page', 'primary', 'aptive', 'A', supports_claims='Current Austin branch')
add_source('S054', 'Trivest Makes Minority Investment in Alta Pest Control', 'https://www.trivest.com/news/trivest-partners-announces-investment-in-alta-pest-control/', 'Trivest Partners', 'transaction announcement', 'primary', 'trivest', 'A', '2024-04', 'Non-control minority investment; founders retained operational and financial control')
add_source('S055', 'Rollins Completes Acquisition of HomeTeam Pest Defense', 'https://www.rollins.com/news-events/press-releases/detail/28/rollins-inc-completes-acquisition-of-hometeam-pest-defense', 'Rollins, Inc.', 'transaction announcement', 'primary', 'rollins', 'A', '2008-04-03', 'HomeTeam acquisition completed')
add_source('S056', 'Rollins Brands', 'https://www.rollins.com/about-us/brands/default.aspx', 'Rollins, Inc.', 'current corporate brand page', 'primary', 'rollins', 'A', supports_claims='Current Orkin and HomeTeam parent relationship')
add_source('S057', 'Rentokil Completes Terminix Acquisition', 'https://www.rentokil-initial.com/media/news-releases/news-2022/terminix_completion.aspx', 'Rentokil Initial plc', 'transaction announcement', 'primary', 'rentokil', 'A', '2022-10-12', 'Terminix acquisition completed')
add_source('S058', 'PCM Growth Acquires Hawx Services', 'https://www.pcmgrowth.com/', 'PCM Growth', 'transaction announcement / portfolio page', 'primary', 'pcm', 'B', '2021-03-12', 'Last documented sponsor acquisition of Hawx; current continuity not independently reconfirmed')
add_source('S059', 'Massey Services Acquires EcoShield’s Austin Division', 'https://www.masseyservices.com/massey-services-acquires-ecoshield-pest-controls-austin-division/', 'Massey Services', 'transaction announcement', 'primary', 'massey', 'A', '2015', 'Historical acquisition of EcoShield Austin division; not treated as proof of current EcoShield brand ownership')
add_source('S060', 'Structural Pest Control Service', 'https://texasagriculture.gov/Regulatory-Programs/Pesticides/Structural-Pest-Control-Service', 'Texas Department of Agriculture', 'regulatory page', 'primary', 'texas_agriculture', 'A', supports_claims='Texas structural pest control licensing framework')

# Current Austin presence and local-ownership sources
local_sources = [
    ('S100','ABC Home & Commercial Services - About Austin','https://www.abchomeandcommercial.com/austin/about','ABC Home & Commercial Services','ABC Austin presence; Bobby Jenkins and family ownership','abc'),
    ('S101','Fox Service Company','https://www.foxservice.com/','Fox Service Company','Current Austin HVAC/plumbing/electrical brand','fox'),
    ('S102','Precision Heating & Air','https://www.precisionheatac.com/','Precision Heating & Air','Current Austin-facing Precision brand','precision'),
    ('S103','Radiant Plumbing, Air Conditioning & Electrical','https://radiantplumbing.com/','Radiant','Current Austin operation','radiant'),
    ('S104','Stan’s Heating, Air, Plumbing & Electrical','https://stansac.com/','Stan’s','Current Austin and suburb service area','stans'),
    ('S105','McCullough Heating & Air Conditioning','https://coolmenow.com/','McCullough Heating & Air Conditioning','Current Greater Austin service and local-ownership claim','mccullough'),
    ('S106','McCullough BBB Profile','https://www.bbb.org/us/tx/austin/profile/air-conditioning-contractor/mccullough-heating-air-conditioning-inc-0825-37920','Better Business Bureau','McCullough legal-name and president lead','bbb'),
    ('S107','Efficient AC, Electric & Plumbing - About','https://efficienttexas.com/about-us/','Efficient AC, Electric & Plumbing','George and Molly Drazic ownership and current Austin operation','efficient'),
    ('S108','Reliant Plumbing - About','https://www.reliantplumbing.com/about-us/','Reliant Plumbing','Max Hicks/family ownership and current Austin operation','reliant'),
    ('S109','Christianson Air Conditioning & Plumbing','https://www.christiansonco.com/','Christianson','Current Austin/Round Rock operation and family-ownership claim','christianson'),
    ('S110','Excalibur Plumbing','https://www.excaliburplumbing.com/','Excalibur Plumbing','Current Austin/Leander service, master license, Blake Smith','excalibur'),
    ('S111','Excalibur Plumbing BBB Profile','https://www.bbb.org/us/tx/leander/profile/plumber/excalibur-plumbing-llc-0825-90055054','Better Business Bureau','Excalibur Plumbing LLC and managing member lead','bbb'),
    ('S112','Whitestone Plumbing','https://callwhitestone.com/','Whitestone Plumbing','Current Cedar Park/Austin service and local-ownership claim','whitestone'),
    ('S113','Whitestone Plumbing BBB Profile','https://www.bbb.org/us/tx/cedar-park/profile/plumber/whitestone-plumbing-0825-1000193219','Better Business Bureau','Ben Helton owner lead','bbb'),
    ('S114','Crow’s Plumbing Service','https://crowsplumbing.com/','Crow’s Plumbing Service','Current Round Rock/Greater Austin operation and license','crows'),
    ('S115','Crow’s Plumbing BBB Profile','https://www.bbb.org/us/tx/round-rock/profile/plumber/crows-plumbing-service-0825-90034943','Better Business Bureau','Jack Crow managing-member lead','bbb'),
    ('S116','AirFix Mechanical','https://www.getyourairfix.com/','AirFix Mechanical','Current Austin/Round Rock HVAC operation and AirFix Mechanical LLC identity','airfix'),
    ('S117','Austin Major Air & Heat BBB Profile','https://www.bbb.org/us/tx/austin/profile/air-conditioning-contractor/austin-major-air-heat-0825-43724','Better Business Bureau','Current operating history and Adoni Enterprises, Inc. alias','bbb'),
    ('S118','Kidd Roofing Austin','https://www.kiddroof.com/austin-roofing/','Kidd Roofing','Current Austin residential and commercial roofing office','kidd'),
    ('S119','Kidd Roofing BBB Profile','https://www.bbb.org/us/tx/austin/profile/roofing-contractors/kidd-roofing-0825-43065','Better Business Bureau','D.R. Kidd Company, Inc. and current executive lead','bbb'),
    ('S120','Hall Roofing & Construction','https://hallroofingtx.com/','Hall Roofing & Construction','Current Round Rock/Austin residential roofing operation and Erik Hall','hall'),
    ('S121','RoofCrafters Austin','https://roofcrafters.com/austin/','RoofCrafters','Current Leander/Austin headquarters and family/local claim','roofcrafters'),
    ('S122','RoofCrafters GAF Profile','https://www.gaf.com/en-us/roofing-contractors/residential/usa/tx/leander/roofcrafters-inc-1101351','GAF','RoofCrafters, Inc. identity and Leander address','gaf'),
    ('S123','Longhorn Roofing','https://www.longhornroofing.com/','Longhorn Roofing','Current Austin residential roofing operation and Tom Green leadership','longhorn'),
    ('S124','Anderson Roofing & Construction','https://andersonroofingtexas.com/','Anderson Roofing & Construction','Current Leander/Austin residential roofing and family-ownership claim','anderson'),
    ('S125','Silver Creek Exterior & Construction','https://scecroofs.com/','Silver Creek Exterior & Construction','Current Austin/Central Texas residential exterior services and local claim','silver_creek'),
    ('S126','Wilson Roofing','https://wilsonroofing.com/','Wilson Roofing','Current Austin residential roofing operation','wilson'),
    ('S127','Austin Roofing and Construction','https://www.austinroofingandconstruction.com/','Austin Roofing and Construction','Current Austin residential roofing office and private partnership','austin_roofing'),
    ('S128','Olshan Foundation Repair Austin','https://www.olshanfoundation.com/regions/texas/austin/','Olshan Foundation Repair','Current Austin service-area presence','olshan'),
    ('S129','Ram Jack Austin','https://www.ramjack.com/austin/','Ram Jack','Current Austin franchise and independently owned/operated disclosure','ram_jack'),
    ('S130','CenTex Foundation Repair','https://centexfoundationrepair.com/','CenTex Foundation Repair','Current Austin-area foundation operation and company history','centex'),
    ('S131','Douglas Foundation Repair','https://douglasfoundationrepair.com/','Douglas Foundation Repair','Current Austin-area foundation operation','douglas'),
    ('S132','Advanced Foundation Repair Austin','https://foundationrepairs.com/texas/austin-foundation-repair/','Advanced Foundation Repair','Current Austin operation','advanced'),
    ('S133','Advanced Foundation Repair BBB Profile','https://www.bbb.org/us/tx/dallas/profile/foundation-contractors/advanced-foundation-repair-lp-0875-19000054','Better Business Bureau','Advanced Foundation Repair, LP identity','bbb'),
    ('S134','Baird Foundation Repair - About','https://www.bairdfoundationrepair.com/about-us/','Baird Foundation Repair','John and Melanie Baird sole ownership and current Austin/Georgetown operation','baird'),
    ('S135','G.L. Hunt Foundation Repair','https://glhunt.com/','G.L. Hunt Foundation Repair','Current Austin operation and Hunt family ownership','gl_hunt'),
    ('S136','All in One Foundation Repair','https://allinonefoundationrepair.com/','All in One Foundation Repair','Current Austin operation and local-ownership claim','all_in_one'),
    ('S137','All in One Foundation Repair BBB Profile','https://www.bbb.org/us/tx/austin/profile/foundation-contractors/all-in-one-foundation-repair-0825-90019893','Better Business Bureau','Robert J. Knight owner lead','bbb'),
    ('S138','Bats Foundation Repair - About','https://batsfoundationrepair.com/about-us/','Bats Foundation Repair','Current Austin operation and Brent Parks ownership','bats'),
    ('S139','Quality Foundation Repair Austin','https://qualityfoundationrepairaustin.com/','Quality Foundation Repair','Current Austin address and service operation','quality_foundation'),
    ('S140','Quality Foundation Repair BBB Profile','https://www.bbb.org/us/tx/austin/profile/foundation-contractors/quality-foundation-repair-0825-90081815','Better Business Bureau','Current Austin operating identity','bbb'),
    ('S141','Quality Foundation Repair Founder Profile','https://www.arcsite.com/blog/quality-foundation-repair','ArcSite','Simon Wallace founder/owner evidence','arcsite'),
    ('S142','Bruecher Foundation','https://www.bruecherfoundation.com/','Bruecher Foundation','Current Austin residential foundation operation and family-business claim','bruecher'),
    ('S143','A-Tex Pest Management','https://atexpm.com/','A-Tex Pest Management','Current Greater Austin service, local claim, license number','atex'),
    ('S144','A-Tex Leadership','https://www.linkedin.com/company/a-tex-pest-management/','A-Tex Pest Management','Jason Napolski president/CEO lead','linkedin'),
    ('S145','HomeTeam Pest Defense Austin','https://pestdefense.com/austin/','HomeTeam Pest Defense','Current Austin service area','hometeam'),
    ('S146','Bulwark Exterminating Austin','https://bulwarkpestcontrol.com/locations/austin/','Bulwark Exterminating','Current Austin branch and Seever family ownership','bulwark'),
    ('S147','Berrett Home Services Austin Pest Control','https://berretthomeservices.com/austin-texas/pest-control/','Berrett Home Services','Current Austin operation and Nathan Berrett/family history','berrett'),
    ('S148','Berrett Pest Control BBB Profile','https://www.bbb.org/us/tx/garland/profile/pest-control/berrett-pest-control-0875-90510549','Better Business Bureau','Nathan Berrett president and corporate identity','bbb'),
    ('S149','Alta Pest Control Austin','https://www.altapestcontrol.com/locations/austin-tx','Alta Pest Control','Current Austin/Pflugerville branch','alta'),
    ('S150','Romney Pest Control Austin','https://romneypestcontrol.com/austin/','Romney Pest Control','Current Austin service and Greg Romney family ownership','romney'),
    ('S151','Pest Wranglers','https://pestwranglers.com/','Pest Wranglers','Current Round Rock/Austin operation and local-ownership claim','pest_wranglers'),
    ('S152','Stride Pest Control','https://stridepestcontrol.com/','Stride Pest Control','Current Austin operation, Stride Pest Control LLC, Tyson Kearns owner','stride'),
    ('S153','Orkin Austin','https://www.orkin.com/locations/texas-tx/austin-pest-control','Orkin','Current Austin branches','orkin'),
    ('S154','Terminix Austin','https://www.terminix.com/exterminators/tx/austin-pest-control/','Terminix','Current Austin branch','terminix'),
    ('S155','Hawx Pest Control Austin','https://hawxpestcontrol.com/austin-tx-pest-control/','Hawx Pest Control','Current Austin service page','hawx'),
    ('S156','Ranger Termite & Pest Control','https://rangertermiteandpestcontrolinc.com/','Ranger Termite & Pest Control','Current Austin operation since 1996','ranger'),
    ('S157','Ranger BBB Profile','https://www.bbb.org/us/tx/austin/profile/pest-control/ranger-termite-pest-control-inc-0825-90002691','Better Business Bureau','Mark Lipscomb president/director lead','bbb'),
    ('S158','EcoShield Pest Solutions Austin','https://www.ecoshieldpest.com/locations/austin-tx','EcoShield Pest Solutions','Current Austin branch','ecoshield'),
    ('S159','Massey Services Austin','https://www.masseyservices.com/austin/','Massey Services','Current Austin branch','massey'),
    ('S160','Massey Services - About','https://www.masseyservices.com/about-us/','Massey Services','Massey family ownership and Tony Massey leadership','massey'),
    ('S161','Natran Green Pest Control Austin','https://natran.com/austin-pest-control/','Natran Green Pest Control','Current Austin operation and Gordon Doran ownership','natran'),
    ('S162','X Out Pest Services','https://xoutpest.com/','X Out Pest Services','Current Austin operation','xout'),
    ('S163','X Out Pest Services BBB Profile','https://www.bbb.org/us/tx/austin/profile/pest-control/x-out-pest-services-llc-0825-1000183342','Better Business Bureau','X Out Pest Services LLC and Dewey Petersen managing member','bbb'),
    ('S164','ClearDefense Pest Control Austin','https://cleardefensepest.com/pest-control-austin-tx/','ClearDefense Pest Control','Current Austin office and founder-led history','cleardefense'),
    ('S165','Roberts Termite & Pest Control','https://www.robertspestcontrol.com/','Roberts Termite & Pest Control','Current Greater Austin family-owned operation','roberts'),
    ('S166','Absolute Pest Management','https://www.absolutepestmgmt.com/','Absolute Pest Management','Current Austin local family-owned operation and Tony Ragan leadership','absolute'),
]
for sid, title, url, publisher, supports, group in local_sources:
    primary_secondary = 'secondary' if publisher in {'Better Business Bureau','GAF','ArcSite'} or url.startswith('https://www.linkedin.com') else 'primary'
    quality = 'B' if primary_secondary == 'primary' else ('B' if publisher in {'Better Business Bureau','GAF'} else 'C')
    add_source(sid, title, url, publisher, 'current company / identity page', primary_secondary, group, quality, supports_claims=supports)

# ---------------------------
# Brand master and footprint
# ---------------------------

brands: list[dict] = []
brand_by_name: dict[str, dict] = {}
footprints: list[dict] = []

def add_brand(
    brand_name: str,
    primary_category: str,
    categories: str,
    owner_type_bucket: str,
    current_platform: str,
    ultimate_owner: str,
    ownership_interest: str,
    ownership_status: str,
    evidence_rating: str,
    local_claim_type: str,
    franchise_flag: bool,
    retained_brand: bool,
    presence_type: str,
    service_area: str,
    presence_sources: str,
    ownership_sources: str,
    notes: str = '',
    aliases: str = '',
    consumer_status: str = 'active',
    inclusion_status: str = 'published_active',
    address_or_base: str = '',
) -> str:
    bid = f'B{len(brands)+1:03d}'
    row = {
        'brand_id': bid,
        'brand_name': brand_name,
        'aliases': aliases,
        'primary_category': primary_category,
        'categories': categories,
        'consumer_brand_status': consumer_status,
        'inclusion_status': inclusion_status,
        'austin_presence_status': 'verified_current' if inclusion_status.startswith('published') else 'not_in_headline_denominator',
        'austin_presence_type': presence_type,
        'address_or_base': address_or_base,
        'service_area_summary': service_area,
        'current_owner_type': owner_type_bucket,
        'current_platform_or_franchise_system': current_platform,
        'current_ultimate_owner_or_controller': ultimate_owner,
        'ownership_interest': ownership_interest,
        'ownership_verification_status': ownership_status,
        'evidence_rating': evidence_rating,
        'local_claim_type': local_claim_type,
        'franchise_flag': franchise_flag,
        'retained_consumer_brand_after_transaction': retained_brand,
        'snapshot_date': SNAPSHOT_DATE,
        'presence_source_ids': source_join(presence_sources),
        'ownership_source_ids': source_join(ownership_sources),
        'notes': notes,
    }
    if brand_name in brand_by_name:
        raise ValueError(f'Duplicate brand {brand_name}')
    brands.append(row)
    brand_by_name[brand_name] = row
    footprints.append({
        'footprint_id': f'F{len(footprints)+1:03d}',
        'brand_id': bid,
        'brand_name': brand_name,
        'primary_category': primary_category,
        'presence_type': presence_type,
        'address_or_base': address_or_base,
        'service_area_summary': service_area,
        'footprint_measure_type': 'current official branch/location/service-area evidence',
        'footprint_value': '1 verified Austin-facing brand record',
        'source_ids': source_join(presence_sources),
        'verified_date': ACCESS_DATE,
        'notes': 'This is a presence record, not revenue or market share.'
    })
    return bid

# HVAC / plumbing / electrical (26)
add_brand('ABC Home & Commercial Services','HVAC / plumbing / electrical','HVAC|plumbing|electrical|pest control','Founder/family/local ownership','', 'Jenkins family / Bobby Jenkins','controlling family ownership stated; exact cap table not public','verified_current_chain','B','locally owned and operated; family owned',False,False,'Austin office / multi-service operator','Austin and surrounding Central Texas communities','S100','S100',address_or_base='Austin')
add_brand('Fox Service Company','HVAC / plumbing / electrical','HVAC|plumbing|electrical','Sponsor-backed platform','Southern Home Services','Gryphon Investors via North American Essential Home Services','Gryphon majority; management meaningful minority at holding-company level','verified_current_chain','A','retained Austin brand after acquisition',False,True,'Austin office / local brand','Austin metro','S101','S002|S005|S006|S007')
add_brand('Precision Heating & Air','HVAC','HVAC','Sponsor-backed platform','Southern Home Services','Gryphon Investors via North American Essential Home Services','Gryphon majority; management meaningful minority at holding-company level','verified_current_chain','A','retained Austin brand after acquisition',False,True,'Austin office / local brand','Austin metro','S102','S001|S005|S006|S007')
add_brand('Daniel’s Plumbing & Air Conditioning','HVAC / plumbing','HVAC|plumbing','Sponsor-backed platform','Southern Home Services','Gryphon Investors via North American Essential Home Services','Gryphon majority; management meaningful minority at holding-company level','verified_chain_brand_activity_conflict','A','retained Austin brand after acquisition',False,True,'current Southern brand page; consumer routing conflict','Austin metro','S004','S003|S004|S005|S006|S007',notes='Southern’s current brand page and site map list Daniel’s. Consumer-facing routing/brand consolidation signals remain inconsistent, so the brand is counted as current-facing but flagged.')
add_brand('Radiant Plumbing, Air Conditioning & Electrical','HVAC / plumbing / electrical','HVAC|plumbing|electrical','Sponsor-backed platform','T3 Services Group','The Riverside Company','investment/control percentage not publicly specified','verified_current_chain','A','retained Austin brand after investment',False,True,'Austin headquarters / local brand','Austin and San Antonio markets','S103','S008|S009|S010')
add_brand('Stan’s Heating, Air, Plumbing & Electrical','HVAC / plumbing / electrical','HVAC|plumbing|electrical','Sponsor-backed platform','The Master Trades Group','L Catterton','L Catterton control through Master Trades Group','verified_current_chain','A','retained Austin brand after acquisition',False,True,'Austin office / broad metro service area','Austin, Round Rock, Cedar Park, Pflugerville, Leander, Georgetown, Lakeway, Bee Cave, Manor, Buda, Kyle, Dripping Springs, Hutto and other suburbs','S104','S011|S013|S014')
add_brand('Strand Brothers Service Experts','HVAC / plumbing','HVAC|plumbing','Public-company owned','Service Experts / Enercare','Brookfield Infrastructure','wholly owned within Brookfield-controlled Enercare structure','verified_current_chain','A','retained local name within national platform',False,True,'Austin service center','Austin metro','S021','S020|S022')
add_brand('Service Wizard Heating & Air Conditioning','HVAC / plumbing','HVAC|plumbing','Sponsor-backed platform','Champions Group Holdings','Ultimate sponsor unresolved at snapshot; last closed sponsor Odyssey, Blackstone acquisition announced','platform acquisition verified; sponsor transfer pending/unconfirmed','verified_platform_ultimate_owner_pending','B','retained Austin brand after acquisition',False,True,'Austin/Hutto operation','Austin, Hutto and surrounding areas','S025','S023|S024',notes='No public closing confirmation was located for the announced Blackstone transaction by the July 26, 2026 snapshot.')
add_brand('Abacus Plumbing, Air Conditioning & Electrical','HVAC / plumbing / electrical','HVAC|plumbing|electrical','Sponsor-backed platform','Wrench Group, LLC','Leonard Green & Partners and management; TSG Consumer Partners and Oak Hill minority','Leonard Green and management majority; TSG and Oak Hill significant minority','verified_current_chain','A','retained consumer brand within platform',False,True,'Austin market branch','Austin metro','S015','S015|S016|S017')
add_brand('Goettl Air Conditioning & Plumbing','HVAC / plumbing','HVAC|plumbing','Sponsor-backed platform','Goettl Air Conditioning & Plumbing','Cortec Group','control percentage not publicly specified','verified_current_chain','B','national platform brand; Dayton Services rebranded',False,False,'Austin branch','Austin metro','S018','S019')
add_brand('ARS/Rescue Rooter Austin','HVAC / plumbing','HVAC|plumbing','Sponsor-backed platform','American Residential Services, LLC','GI Partners; Charlesbank and management retain significant interests','GI Partners majority; Charlesbank and management significant minority','verified_current_chain','A','national platform brand',False,False,'Austin branch','Austin metro','S026','S027|S028')
add_brand('Mr. Rooter Plumbing of Austin','Plumbing','plumbing','Local franchise operator','Neighborly / Mr. Rooter franchise system','Brett Bidwell owns local franchisee; KKR owns Neighborly franchisor','local franchisee ownership; franchisor separately sponsor-owned','verified_franchise_structure','A','locally owned franchise',True,False,'Austin franchise territory','Austin metro','S029','S029|S030')
add_brand('Benjamin Franklin Plumbing of Austin','Plumbing','plumbing','Local franchise operator','Authority Brands / Benjamin Franklin Plumbing','Local franchisee unresolved; Apax majority and BCI minority at franchisor level','franchisee interest unresolved; Apax majority/BCI minority at franchisor','verified_franchisor_local_operator_unresolved','B','locally operated franchise; owner name unresolved',True,False,'Austin/Cedar Park franchise territory','Austin metro','S033','S031|S032|S033')
add_brand('Aire Serv of Cedar Park','HVAC','HVAC','Local franchise operator','Neighborly / Aire Serv franchise system','Local franchisee legal identity unresolved; KKR owns Neighborly franchisor','local franchisee; franchisor sponsor ownership separate','verified_franchisor_local_operator_partial','B','independently owned/operated franchise',True,False,'Cedar Park franchise territory','Cedar Park, Leander and nearby Austin suburbs','S034','S030|S034|S036')
add_brand('Aire Serv of Round Rock','HVAC','HVAC','Local franchise operator','Neighborly / Aire Serv franchise system','Chris Rattray local owner/operator; KKR owns Neighborly franchisor','local franchisee ownership; franchisor sponsor ownership separate','verified_franchise_structure','A','locally owned/operated franchise',True,False,'Round Rock franchise territory','Round Rock, Austin and nearby suburbs','S035','S030|S035|S036')
add_brand('McCullough Heating & Air Conditioning','HVAC / plumbing','HVAC|plumbing|home energy','Founder/family/local ownership','', 'Local ownership asserted; exact current equity holders unresolved','current local ownership claim; president identified, exact cap table unavailable','self_reported_local_current','B','locally owned',False,False,'Austin office / metro service area','Austin, Cedar Park, Georgetown, Lakeway, Leander, Pflugerville and Round Rock','S105','S105|S106')
add_brand('Efficient AC, Electric & Plumbing','HVAC / electrical / plumbing','HVAC|electrical|plumbing','Founder/family/local ownership','', 'George Drazic and Molly Drazic','current owners identified by company','verified_current_chain','A','100% local ownership stated',False,False,'Austin office','Austin metro','S107','S107')
add_brand('Reliant Plumbing','Plumbing','plumbing','Founder/family/local ownership','', 'Max Hicks / Hicks family','founder/family ownership stated; exact cap table not public','verified_local_owner','B','family owned and locally operated',False,False,'Austin-area offices','Austin, Lakeway, Georgetown and surrounding areas','S108','S108')
add_brand('Christianson Air Conditioning & Plumbing','HVAC / plumbing','HVAC|plumbing','Founder/family/local ownership','', 'Christianson family','family ownership stated; exact current equity allocation not public','self_reported_local_current','B','family owned',False,False,'Round Rock office / Austin service area','Austin and Round Rock metro','S109','S109')
add_brand('Excalibur Plumbing','Plumbing','plumbing','Founder/family/local ownership','Excalibur Plumbing, LLC','Blake Smith','managing member/owner evidence','verified_current_chain','A','locally owned',False,False,'Leander/Austin office','Austin, Leander and nearby suburbs','S110','S110|S111')
add_brand('Austin Air Conditioning','HVAC','HVAC','Sponsor-backed platform','SAS Service Partners','Storr Group','Storr-backed platform; seller rollover equity documented','verified_current_chain','A','locally operated retained brand after acquisition',False,True,'Austin-area operating brand','Central Texas','S041','S037|S040|S044')
add_brand('Roger’s Plumbing','Plumbing','plumbing','Sponsor-backed platform','SAS Service Partners','Storr Group','Storr-backed platform; founder joined platform','verified_current_chain','A','retained Leander/Austin brand after acquisition',False,True,'Leander headquarters / Austin service area','North Austin and Central Texas','S042','S038|S040')
add_brand('Whitestone Plumbing','Plumbing','plumbing','Founder/family/local ownership','', 'Ben Helton','owner identified by current business profile; company asserts local ownership','verified_local_owner','B','locally owned',False,False,'Cedar Park base','Cedar Park, Leander and Austin metro','S112','S112|S113')
add_brand('Crow’s Plumbing Service','Plumbing','plumbing','Founder/family/local ownership','', 'Jack Crow','managing member identified; current company and license evidence','verified_local_owner','B','local operator',False,False,'Round Rock base','Greater Austin','S114','S114|S115')
add_brand('AirFix Mechanical','HVAC','HVAC','Founder/family/local ownership','AirFix Mechanical, LLC','Exact equity owner unresolved','current legal entity and local operation verified; controller unresolved','verified_entity_control_unresolved','C','locally owned claim',False,False,'Round Rock/Austin base','Austin and Round Rock metro','S116','S116')
add_brand('Austin Major Air & Heat','HVAC','HVAC','Private/control unresolved','Adoni Enterprises, Inc. (alternate legal identity lead)','Current controller unresolved','operating identity lead only','unresolved_control','D','none relied upon',False,False,'Austin operator','Austin metro','S117','S117',notes='Included as a current operating company, but not classified as independent or locally owned without stronger current equity evidence.')

# Roofing (9)
add_brand('Kidd Roofing','Roofing / exterior','roofing|exterior','Private/control unresolved','D.R. Kidd Company, Inc.','Current controller unresolved','executive identity available; equity control not established','unresolved_control','C','private-company history; no ownership conclusion',False,False,'Austin office','Austin and Central Texas','S118','S118|S119')
add_brand('Hall Roofing & Construction','Roofing / exterior','roofing|exterior','Founder/family/local ownership','', 'Erik Hall','owner/leader identified in current company materials','verified_local_owner','B','local owner-operated',False,False,'Round Rock office','Austin, Round Rock, Cedar Park, Georgetown, Hutto, Leander and Pflugerville','S120','S120')
add_brand('RoofCrafters','Roofing / exterior','roofing|exterior','Founder/family/local ownership','RoofCrafters, Inc.','Family/local ownership asserted; exact controller unresolved','current entity and local/family claim; cap table unavailable','self_reported_local_current','C','family-owned / locally based',False,False,'Leander headquarters','Austin metro','S121','S121|S122')
add_brand('Longhorn Roofing','Roofing','roofing','Founder/family/local ownership','', 'Tom Green','current owner/leader identified','verified_local_owner','B','locally owned',False,False,'Austin operator','Austin metro','S123','S123')
add_brand('Ja-Mar Roofing & Sheet Metal','Roofing / exterior','roofing|sheet metal|exterior','Sponsor-backed platform','Roofing Services Solutions','Dunes Point Capital','acquired by sponsor-backed platform','verified_current_chain','A','retained Austin brand; current site also uses local-owner wording',False,True,'Austin office / retained brand','Austin and Central Texas','S047','S045|S046|S047',notes='The current “local owners” wording is treated as management/operating language unless the company documents a post-transaction equity structure.')
add_brand('Anderson Roofing & Construction','Roofing','roofing','Founder/family/local ownership','', 'Anderson family / local owners','family ownership asserted; exact current equity holders not public','self_reported_local_current','C','family owned and operated',False,False,'Leander base','Austin and surrounding communities','S124','S124')
add_brand('Silver Creek Exterior & Construction','Roofing / exterior','roofing|exterior','Founder/family/local ownership','', 'Local owners; identities unresolved','local ownership asserted; exact owners not established','self_reported_local_current','C','locally owned',False,False,'Central Texas operator','Austin and Central Texas','S125','S125')
add_brand('Wilson Roofing','Roofing','roofing','Private/control unresolved','', 'Current controller unresolved','current operation verified; no publication-grade controller evidence','unresolved_control','D','none relied upon',False,False,'Austin office','Austin metro','S126','S126')
add_brand('Austin Roofing and Construction','Roofing','roofing','Private/control unresolved','', 'Current controlling partners unresolved','current private partnership verified; control allocation unavailable','unresolved_control','D','local office; ownership not inferred',False,False,'Austin office','Austin metro','S127','S127')

# Foundation (12)
add_brand('Olshan Foundation Repair','Foundation repair','foundation repair|waterproofing','Private/control unresolved','Olshan Foundation Repair','Current controlling owner unresolved','current Austin presence verified; controller not established','unresolved_control','D','no local/family label assigned',False,False,'Austin office / service area','Austin metro','S128','S128')
add_brand('Ram Jack Austin','Foundation repair','foundation repair','Local franchise operator','Ram Jack franchise system','Local franchisee identity unresolved','independently owned franchise; local owner unresolved','verified_franchisor_local_operator_unresolved','B','independently owned and operated franchise',True,False,'Austin franchise territory','Austin metro','S129','S129')
add_brand('CenTex Foundation Repair','Foundation repair','foundation repair','Private/control unresolved','', 'Current controller unresolved','founder history and current operation known; present equity unclear','unresolved_control','D','founder history only',False,False,'Central Texas operator','Austin and Central Texas','S130','S130')
add_brand('Douglas Foundation Repair','Foundation repair','foundation repair','Private/control unresolved','', 'Current controller unresolved','current Austin operation verified; controller not established','unresolved_control','D','none relied upon',False,False,'Austin office','Austin metro','S131','S131')
add_brand('Advanced Foundation Repair','Foundation repair','foundation repair','Private/control unresolved','Advanced Foundation Repair, LP','Current controller unresolved','legal entity and current Austin operation verified; controller not established','unresolved_control','D','none relied upon',False,False,'Austin service area','Austin metro','S132','S132|S133')
add_brand('Baird Foundation Repair','Foundation repair','foundation repair','Founder/family/local ownership','', 'John Baird and Melanie Baird','sole owners stated in current company material','verified_current_chain','A','family owned',False,False,'Georgetown/Austin office','Austin and Central Texas','S134','S134')
add_brand('Groundworks','Foundation repair','foundation repair|waterproofing','Sponsor-backed platform','Groundworks Companies, LLC','KKR; Cortec retains minority positions','KKR controlling/majority; Cortec minority','verified_current_chain','A','national platform serving Austin',False,False,'Austin service area dispatched from San Antonio-area office','Austin metro','S048','S049|S050')
add_brand('G.L. Hunt Foundation Repair','Foundation repair','foundation repair','Founder/family/local ownership','', 'Gary Hunt / Hunt family','family ownership stated in current company materials','verified_local_owner','B','family owned',False,False,'Austin office','Austin metro and Central Texas','S135','S135')
add_brand('All in One Foundation Repair','Foundation repair','foundation repair','Founder/family/local ownership','', 'Robert J. Knight','owner identified by business profile; local claim current','verified_local_owner','B','locally owned',False,False,'Austin operator','Austin metro','S136','S136|S137')
add_brand('Bats Foundation Repair','Foundation repair','foundation repair','Founder/family/local ownership','', 'Brent Parks','principal owner/managing member identified','verified_current_chain','A','locally owned',False,False,'Austin operator','Austin metro','S138','S138')
add_brand('Quality Foundation Repair','Foundation repair','foundation repair','Founder/family/local ownership','', 'Simon Wallace','founder/owner identified by current independent profile and active business evidence','verified_local_owner','B','local operator',False,False,'Austin address','Austin metro','S139|S140','S140|S141',notes='Reverses Model A’s exclusion. The company has a current Austin address, active official site, and a named founder/owner trail.')
add_brand('Bruecher Foundation','Foundation repair','foundation repair','Founder/family/local ownership','', 'Bruecher family / local owners','family-business claim current; exact equity holders unresolved','self_reported_local_current','C','family owned',False,False,'Austin operator','Austin metro','S142','S142')

# Pest control (20; ABC already counted above)
add_brand('Aptive Environmental','Pest control','pest control','Sponsor-backed platform','Aptive Environmental','Citation Capital; management retains significant interest','Citation majority; management significant minority','verified_current_chain','A','national branch',False,False,'Austin branch','Austin metro','S053','S052|S053')
add_brand('A-Tex Pest Management','Pest control','pest control','Founder/family/local ownership','', 'Local ownership asserted; exact equity holders unresolved','current local claim and president/CEO lead; cap table unavailable','self_reported_local_current','C','locally owned',False,False,'Austin-area operator','Greater Austin','S143','S143|S144')
add_brand('HomeTeam Pest Defense','Pest control','pest control','Public-company owned','HomeTeam Pest Defense','Rollins, Inc.','wholly owned public-company subsidiary/brand','verified_current_chain','A','national branch',False,False,'Austin service branch','Austin and surrounding suburbs','S145','S055|S056')
add_brand('Bulwark Exterminating','Pest control','pest control','Founder/family/local ownership','', 'Seever family','family ownership stated in current company material','verified_local_owner','B','family owned',False,False,'Austin branch','Austin metro','S146','S146')
add_brand('Berrett Home Services / Berrett Pest Control','Pest control','pest control','Founder/family/local ownership','', 'Nathan Berrett / Berrett family','founder/president and family operation identified','verified_current_chain','A','family owned and operated',False,False,'Austin service area','Austin metro','S147','S147|S148')
add_brand('Alta Pest Control','Pest control','pest control','Minority-invested, founder-controlled','Alta Pest Control','Founders retain control; Trivest Partners is minority investor','Trivest non-control minority; founders retain operational and financial control','verified_current_chain','A','Austin-founded company with minority outside capital',False,False,'Pflugerville/Austin branch','Austin metro','S149','S054|S149')
add_brand('Romney Pest Control','Pest control','pest control','Founder/family/local ownership','', 'Greg Romney and family','founder/family ownership stated','verified_local_owner','B','locally owned',False,False,'dispatch/service area from Selma office','Austin and San Antonio metros','S150','S150')
add_brand('Pest Wranglers','Pest control','pest control','Founder/family/local ownership','Wranglers Service Group, Inc.','Local owners; individual controller unresolved','local ownership asserted; legal entity lead available','self_reported_local_current','C','locally owned',False,False,'Round Rock base','Austin, Round Rock and nearby suburbs','S151','S151')
add_brand('Stride Pest Control','Pest control','pest control','Founder/family/local ownership','Stride Pest Control, LLC','Tyson Kearns','owner and legal entity identified in current company material','verified_current_chain','A','locally owned',False,False,'Austin operator','Austin metro','S152','S152')
add_brand('Orkin','Pest control','pest control','Public-company owned','Orkin','Rollins, Inc.','wholly owned public-company brand/subsidiary','verified_current_chain','A','national branch',False,False,'Austin branches','Austin metro','S153','S056|S153')
add_brand('Terminix','Pest control','pest control','Public-company owned','Terminix / Rentokil North America','Rentokil Initial plc','completed strategic acquisition','verified_current_chain','A','national branch',False,False,'Austin branch','Austin metro','S154','S057|S154')
add_brand('Hawx Pest Control','Pest control','pest control','Private/control unresolved','Hawx Services','Last documented sponsor PCM Growth/PCM Encore; current continuity unresolved','2021 acquisition documented; current controller not independently reconfirmed','unresolved_current_sponsor','D','national/multi-market branch',False,False,'Austin service page','Austin metro','S155','S058|S155')
add_brand('Ranger Termite & Pest Control','Pest control','pest control','Private/control unresolved','Ranger Termite & Pest Control, Inc.','Current controller unresolved due conflicting owner/president references','operating company current; equity conflict unresolved','unresolved_control_conflict','D','local operating history only',False,False,'Austin base','Austin metro','S156','S156|S157')
add_brand('EcoShield Pest Solutions','Pest control','pest control','Private/control unresolved','EcoShield Pest Solutions','Current Austin operator/controller unresolved','current brand presence verified; 2015 divisional sale does not establish current brand ownership','unresolved_control_historical_conflict','D','national/multi-market branch',False,False,'Austin branch','Austin metro','S158','S059|S158')
add_brand('Massey Services','Pest control','pest control','Founder/family/local ownership','Massey Services','Massey family / Tony Massey','family control stated by current company','verified_current_chain','A','family owned',False,False,'Austin branch','Austin metro','S159','S159|S160')
add_brand('Natran Green Pest Control','Pest control','pest control','Founder/family/local ownership','', 'Gordon Doran','founder/owner/CEO identified','verified_current_chain','A','locally founded',False,False,'Austin branch','Austin metro','S161','S161')
add_brand('X Out Pest Services','Pest control','pest control','Founder/family/local ownership','X Out Pest Services, LLC','Dewey Petersen','managing member identified','verified_local_owner','B','local operator',False,False,'Austin operation','Austin metro','S162','S162|S163')
add_brand('ClearDefense Pest Control','Pest control','pest control','Founder/family/local ownership','', 'Founders John-Mark Bolton, Chris Cunningham and Jason Brown; current allocation not public','founder-led company; current cap table not public','verified_founder_led_partial','B','founder led',False,False,'Austin office','Austin metro','S164','S164')
add_brand('Roberts Termite & Pest Control','Pest control','pest control','Founder/family/local ownership','', 'Roberts family / local owners','family ownership asserted; exact equity holders not public','self_reported_local_current','C','family owned',False,False,'Greater Austin operator','Austin metro','S165','S165')
add_brand('Absolute Pest Management','Pest control','pest control','Founder/family/local ownership','', 'Tony Ragan / Ragan family','president and family ownership stated','verified_local_owner','B','locally family owned',False,False,'Austin operator','Austin metro','S166','S166')

# Historical / candidate / excluded records retained outside headline denominator
add_brand('Cool Atmosphere','HVAC','HVAC','Historical / absorbed','SAS Service Partners','Storr Group','acquired by SAS and later combined into Austin Air Conditioning','historical_absorbed','A','former retained local brand',False,True,'former Leander brand','North Austin','S043','S039|S040|S043',consumer_status='absorbed/rebranded',inclusion_status='historical_not_denominator')
add_brand('Dayton Services','HVAC / plumbing','HVAC|plumbing','Historical / rebranded','Goettl Air Conditioning & Plumbing','Cortec Group','rebranded into Goettl Austin','historical_rebranded','B','former local brand',False,False,'former Austin brand','Austin metro','S018','S018|S019',consumer_status='rebranded',inclusion_status='historical_not_denominator')
add_brand('Foundation Support Specialists','Foundation repair','foundation repair','Historical / rebranded','Groundworks','KKR; Cortec minority','acquired by Groundworks and no longer treated as separate current public brand in this package','historical_absorbed','A','former regional brand',False,True,'former Austin-facing brand','Austin metro','S051','S049|S050|S051',consumer_status='absorbed/rebranded',inclusion_status='historical_not_denominator')
add_brand('Sierra Air Services','HVAC','HVAC','Candidate / unresolved','','','not established','candidate_current_status_unverified','D','none',False,False,'indexed permit history only','Austin metro','I001','I001',consumer_status='candidate',inclusion_status='candidate_not_published',notes='Current official operating evidence was not strong enough for publication. Last indexed Austin permit evidence identified in the review was historical.')
add_brand('Bastion Pest Control','Pest control','pest control','Candidate / unresolved','','','not established','candidate_launch_unverified','D','none',False,False,'launch/job-posting lead only','Austin metro','I001','I001',consumer_status='candidate',inclusion_status='candidate_not_published')
add_brand('Hydepark Foundation Repair','Foundation repair','foundation repair','Excluded / unverified','','','not established','excluded_unverified_operator','D','none',False,False,'generic web property','Austin','I001','I001',consumer_status='unverified',inclusion_status='excluded')
add_brand('Austin Foundation Repair Team','Foundation repair','foundation repair','Excluded / unverified','','','not established','excluded_unverified_operator','D','none',False,False,'generic web property','Austin','I001','I001',consumer_status='unverified',inclusion_status='excluded')
add_brand('West Lake Hills Foundation Repair','Foundation repair','foundation repair','Excluded / unverified','','','not established','excluded_unverified_operator','D','none',False,False,'generic web property','West Lake Hills','I001','I001',consumer_status='unverified',inclusion_status='excluded')

# ---------------------------
# Entity master and relationship graph
# ---------------------------

entities: list[dict] = []
entity_by_name: dict[str, str] = {}

def add_entity(
    entity_name: str,
    entity_type: str,
    jurisdiction: str = '',
    legal_form: str = '',
    aliases: str = '',
    current_status: str = 'current',
    address: str = '',
    source_ids: str = '',
    notes: str = '',
    forced_id: str = '',
) -> str:
    if entity_name in entity_by_name:
        return entity_by_name[entity_name]
    eid = forced_id or f'N{len([e for e in entities if e["entity_id"].startswith("N")])+1:03d}'
    row = {
        'entity_id': eid,
        'entity_name': entity_name,
        'entity_type': entity_type,
        'jurisdiction': jurisdiction,
        'legal_form': legal_form,
        'aliases': aliases,
        'current_status': current_status,
        'address': address,
        'source_ids': source_join(source_ids),
        'notes': notes,
    }
    entities.append(row)
    entity_by_name[entity_name] = eid
    return eid

# Brand nodes use the brand IDs so graph joins are direct.
for b in brands:
    add_entity(
        b['brand_name'], 'Brand', aliases=b['aliases'], current_status=b['consumer_brand_status'],
        address=b['address_or_base'], source_ids=source_join(b['presence_source_ids'], b['ownership_source_ids']),
        notes=f"{b['primary_category']}; inclusion_status={b['inclusion_status']}", forced_id=b['brand_id']
    )

# Platforms, holding companies, sponsors, public parents, legal entities, local owners, and franchisees.
entity_specs = [
    ('Southern Home Services','Platform','','','','current','', 'S001|S002|S003|S005',''),
    ('North American Essential Home Services','Holding company','','','','current','', 'S006|S007',''),
    ('Gryphon Investors','Sponsor','US','','','current','', 'S006|S007',''),
    ('Radiant Plumbing Service, LLC','Legal entity','Texas','LLC','','current','', 'S008','Does business as Radiant Plumbing & Air Conditioning.'),
    ('T3 Services Group','Platform','','','','current','', 'S009|S010',''),
    ('The Riverside Company','Sponsor','US','','','current','', 'S010',''),
    ('Stan’s Home Services Holdings','Legal entity','Texas','','','current','', 'S011|S012','Holding-company lineage identified in transaction materials.'),
    ('The Master Trades Group','Platform','','','','current','', 'S011|S013|S014','Formerly LTP Home Services Group.'),
    ('L Catterton','Sponsor','US','','','current','', 'S013|S014',''),
    ('Service Experts','Platform','','','','current','', 'S020|S021|S022',''),
    ('Enercare Inc.','Holding company','Canada','Corporation','','current','', 'S020',''),
    ('Brookfield Infrastructure Partners L.P.','Public company','Bermuda','Limited partnership','','current','', 'S020|S022','Publicly traded infrastructure owner.'),
    ('Champions Group Holdings','Platform','','','','current','', 'S023|S024',''),
    ('Odyssey Investment Partners','Sponsor','US','','','last_closed_sponsor_at_snapshot','', 'S023|S024','Last closed sponsor identified; Blackstone agreement announced but closing not proven by snapshot.'),
    ('Blackstone','Sponsor','US','','','pending_acquirer','', 'S024','Pending announced acquirer as of snapshot.'),
    ('Wrench Group, LLC','Platform','US','LLC','','current','', 'S015|S016',''),
    ('Leonard Green & Partners','Sponsor','US','','','current','', 'S016|S017',''),
    ('TSG Consumer Partners','Sponsor','US','','','current_minority','', 'S016',''),
    ('Oak Hill Capital','Sponsor','US','','','current_minority','', 'S016',''),
    ('Cortec Group','Sponsor','US','','','current','', 'S019|S050','Goettl controller; minority Groundworks investor after March 2023.'),
    ('American Residential Services, LLC','Platform','US','LLC','ARS / Rescue Rooter','current','', 'S026|S027|S028',''),
    ('GI Partners','Sponsor','US','','','current_majority','', 'S027|S028',''),
    ('Charlesbank Capital Partners','Sponsor','US','','','current_minority','', 'S027',''),
    ('Neighborly','Franchise system','US','','','current','', 'S030|S036',''),
    ('KKR','Sponsor','US','','','current','', 'S030|S049',''),
    ('Mr. Rooter Austin local franchisee (legal name unresolved)','Local franchisee','Texas','','','current','Austin', 'S029','Local legal entity name remains unresolved.'),
    ('Brett Bidwell','Founder or family owner','Texas','','','current','Austin', 'S029','Local owner of Mr. Rooter Plumbing of Austin.'),
    ('Authority Brands','Franchise system','US','','','current','', 'S031|S032',''),
    ('Apax Partners','Sponsor','UK / US','','','current_majority','', 'S031',''),
    ('British Columbia Investment Management Corporation','Sponsor','Canada','Crown corporation','BCI','current_minority','', 'S032','Significant minority investor in Authority Brands.'),
    ('Benjamin Franklin Austin local franchisee (legal name unresolved)','Local franchisee','Texas','','','current','Austin', 'S033','Local owner name and legal entity not established.'),
    ('Aire Serv Cedar Park local franchisee (legal name unresolved)','Local franchisee','Texas','','','current','Cedar Park', 'S034','Local legal entity not established.'),
    ('Aire Serv Round Rock local franchisee (legal name unresolved)','Local franchisee','Texas','','','current','Round Rock', 'S035','Local legal entity not established.'),
    ('Chris Rattray','Founder or family owner','Texas','','','current','Round Rock', 'S035','Owner/operator of Aire Serv of Round Rock.'),
    ('SAS Service Partners','Platform','Texas','','SAS AirCare','current','Austin', 'S037|S038|S039|S040',''),
    ('Storr Group','Sponsor','Texas','','','current','Austin', 'S037|S038|S039','Operational equity backer of SAS Service Partners.'),
    ('Roofing Services Solutions','Platform','US','','','current','', 'S045|S046',''),
    ('Dunes Point Capital','Sponsor','US','','','current','', 'S045|S046',''),
    ('Groundworks Companies, LLC','Platform','US','LLC','','current','', 'S048|S049|S050',''),
    ('Citation Capital','Sponsor','US','','','current_majority','', 'S052',''),
    ('Alta founders and management','Founder or family owner','Texas','','','current_control','Austin', 'S054','Founders retained operational and financial control after minority investment.'),
    ('Trivest Partners','Sponsor','US','','','current_minority','', 'S054','Non-control minority investor.'),
    ('Rollins, Inc.','Public company','US','Corporation','','current','', 'S055|S056','Public parent of Orkin and HomeTeam.'),
    ('Rentokil Initial plc','Public company','United Kingdom','Public limited company','','current','', 'S057','Public parent of Terminix.'),
    ('PCM Growth / PCM Encore','Sponsor','US','','','last_documented_sponsor','', 'S058','Current continuity with Hawx not independently reconfirmed.'),
    ('Jenkins family / Bobby Jenkins','Founder or family owner','Texas','','','current','Austin', 'S100',''),
    ('McCullough local owners (exact holders unresolved)','Founder or family owner','Texas','','','current_claim','Austin', 'S105','Self-reported local ownership; exact holders unavailable.'),
    ('Albert P. D’Andrea III','Founder or family owner','Texas','','','current_management','Austin', 'S106','President; not treated as proven sole owner.'),
    ('George Drazic and Molly Drazic','Founder or family owner','Texas','','','current','Austin', 'S107',''),
    ('Max Hicks / Hicks family','Founder or family owner','Texas','','','current','Austin', 'S108',''),
    ('Christianson family','Founder or family owner','Texas','','','current_claim','Central Texas', 'S109',''),
    ('Excalibur Plumbing, LLC','Legal entity','Texas','LLC','','current','Leander', 'S110|S111',''),
    ('Blake Smith','Founder or family owner','Texas','','','current','Leander', 'S110|S111',''),
    ('Ben Helton','Founder or family owner','Texas','','','current','Cedar Park', 'S112|S113',''),
    ('Jack Crow','Founder or family owner','Texas','','','current','Round Rock', 'S114|S115',''),
    ('AirFix Mechanical, LLC','Legal entity','Texas','LLC','','current','Round Rock', 'S116',''),
    ('Adoni Enterprises, Inc.','Legal entity','Texas','Corporation','Austin Major Air & Heat','current','Austin', 'S117','Alternate legal identity lead; controller unresolved.'),
    ('D.R. Kidd Company, Inc.','Legal entity','Texas','Corporation','Kidd Roofing','current','Austin', 'S118|S119',''),
    ('Erik Hall','Founder or family owner','Texas','','','current','Round Rock', 'S120',''),
    ('RoofCrafters, Inc.','Legal entity','Texas','Corporation','','current','Leander', 'S121|S122',''),
    ('RoofCrafters family owners (exact holders unresolved)','Founder or family owner','Texas','','','current_claim','Leander', 'S121',''),
    ('Tom Green','Founder or family owner','Texas','','','current','Austin', 'S123',''),
    ('Anderson family / local owners','Founder or family owner','Texas','','','current_claim','Leander', 'S124',''),
    ('Silver Creek local owners (identities unresolved)','Founder or family owner','Texas','','','current_claim','Central Texas', 'S125',''),
    ('Ram Jack Austin local franchisee (legal name unresolved)','Local franchisee','Texas','','','current','Austin', 'S129',''),
    ('Advanced Foundation Repair, LP','Legal entity','Texas','Limited partnership','','current','', 'S132|S133',''),
    ('John Baird and Melanie Baird','Founder or family owner','Texas','','','current','Georgetown', 'S134',''),
    ('Gary Hunt / Hunt family','Founder or family owner','Texas','','','current','Austin', 'S135',''),
    ('Robert J. Knight','Founder or family owner','Texas','','','current','Austin', 'S136|S137',''),
    ('Brent Parks','Founder or family owner','Texas','','','current','Austin', 'S138',''),
    ('Simon Wallace','Founder or family owner','Texas','','','current','Austin', 'S140|S141',''),
    ('Bruecher family / local owners','Founder or family owner','Texas','','','current_claim','Austin', 'S142',''),
    ('A-Tex local owners (exact holders unresolved)','Founder or family owner','Texas','','','current_claim','Austin', 'S143',''),
    ('Jason Napolski','Founder or family owner','Texas','','','current_management','Austin', 'S144','President/CEO lead; not treated as proven controller.'),
    ('Seever family','Founder or family owner','US','','','current','', 'S146',''),
    ('Nathan Berrett / Berrett family','Founder or family owner','Texas','','','current','', 'S147|S148',''),
    ('Greg Romney / Romney family','Founder or family owner','Texas','','','current','', 'S150',''),
    ('Wranglers Service Group, Inc.','Legal entity','Texas','Corporation','Pest Wranglers','current','Round Rock', 'S151',''),
    ('Pest Wranglers local owners (identities unresolved)','Founder or family owner','Texas','','','current_claim','Round Rock', 'S151',''),
    ('Stride Pest Control, LLC','Legal entity','Texas','LLC','','current','Austin', 'S152',''),
    ('Tyson Kearns','Founder or family owner','Texas','','','current','Austin', 'S152',''),
    ('Ranger Termite & Pest Control, Inc.','Legal entity','Texas','Corporation','','current','Austin', 'S156|S157',''),
    ('Massey family / Tony Massey','Founder or family owner','US','','','current','', 'S160',''),
    ('Gordon Doran','Founder or family owner','Texas','','','current','Austin', 'S161',''),
    ('X Out Pest Services, LLC','Legal entity','Texas','LLC','','current','Austin', 'S162|S163',''),
    ('Dewey Petersen','Founder or family owner','Texas','','','current','Austin', 'S163',''),
    ('ClearDefense founders','Founder or family owner','US','','','current_partial','', 'S164','John-Mark Bolton, Chris Cunningham and Jason Brown; current allocation unavailable.'),
    ('Roberts family / local owners','Founder or family owner','Texas','','','current_claim','Austin', 'S165',''),
    ('Tony Ragan / Ragan family','Founder or family owner','Texas','','','current','Austin', 'S166',''),
]
for spec in entity_specs:
    add_entity(*spec)

relationships: list[dict] = []
ALLOWED_EDGES = {
    'DBA of','Operated by','Subsidiary of','Majority owned by','Minority investment from',
    'Portfolio company of','Franchise of','Acquired by','Sold by','Combined with','Rebranded as','Locally managed by'
}

def eid(name: str) -> str:
    if name not in entity_by_name:
        raise KeyError(f'Unknown entity {name}')
    return entity_by_name[name]


def add_relationship(
    from_name: str,
    to_name: str,
    edge_type: str,
    start_date: str,
    current_status: bool,
    evidence_rating: str,
    source_ids: str,
    evidence_note: str,
    end_date: str = '',
    interest_type: str = 'unspecified',
    relationship_status: str = 'current',
) -> str:
    if edge_type not in ALLOWED_EDGES:
        raise ValueError(f'Unsupported edge type {edge_type}')
    sid_list = [s for s in source_join(source_ids).split('|') if s]
    groups = sorted({source_by_id[s]['independence_group'] for s in sid_list if s in source_by_id})
    rid = f'R{len(relationships)+1:03d}'
    relationships.append({
        'relationship_id': rid,
        'from_entity_id': eid(from_name),
        'from_entity_name': from_name,
        'to_entity_id': eid(to_name),
        'to_entity_name': to_name,
        'edge_type': edge_type,
        'start_date': start_date or 'unknown',
        'end_date': end_date,
        'current_status': bool(current_status),
        'relationship_status': relationship_status,
        'interest_type': interest_type,
        'evidence_rating': evidence_rating,
        'supporting_source_count': len(sid_list),
        'independent_source_group_count': len(groups),
        'source_ids': '|'.join(sid_list),
        'access_date': ACCESS_DATE,
        'evidence_note': evidence_note,
    })
    return rid

# Major platform chains
for brand, start, src in [
    ('Fox Service Company','2020-07','S002|S005'),
    ('Precision Heating & Air','2020-06-30','S001|S005'),
    ('Daniel’s Plumbing & Air Conditioning','2022-04-07','S003|S004|S005'),
]:
    add_relationship(brand,'Southern Home Services','Operated by',start,True,'A',src,'Current Southern brand/transaction evidence supports the retained consumer brand relationship.')
add_relationship('Southern Home Services','North American Essential Home Services','Subsidiary of','2021-10',True,'A','S006|S007','Southern sits within the Gryphon-backed NAEHS holding structure.')
add_relationship('North American Essential Home Services','Gryphon Investors','Majority owned by','2021-10',True,'A','S006|S007','Gryphon completed a majority investment; management retained a meaningful stake.',interest_type='majority')

add_relationship('Radiant Plumbing, Air Conditioning & Electrical','Radiant Plumbing Service, LLC','DBA of','unknown',True,'A','S008','Current customer terms identify the operating LLC doing business as Radiant.')
add_relationship('Radiant Plumbing Service, LLC','T3 Services Group','Operated by','2021',True,'A','S009|S010','Radiant is a current T3 operating partner.')
add_relationship('T3 Services Group','The Riverside Company','Portfolio company of','2020-11',True,'A','S010','Riverside lists T3 as a current investment; public materials do not specify the exact ownership percentage.',interest_type='unspecified control')

add_relationship('Stan’s Heating, Air, Plumbing & Electrical','Stan’s Home Services Holdings','DBA of','unknown',True,'B','S011|S012','Transaction materials identify the Stan’s holding-company lineage.')
add_relationship('Stan’s Home Services Holdings','The Master Trades Group','Subsidiary of','2024-03-25',True,'A','S011','Master Trades Group completed the acquisition of Stan’s.')
add_relationship('The Master Trades Group','L Catterton','Portfolio company of','2022-03-22',True,'A','S013|S014','L Catterton acquired LTP, now Master Trades Group.',interest_type='control')

add_relationship('Strand Brothers Service Experts','Service Experts','Operated by','unknown',True,'A','S021','Current Austin page identifies Strand Brothers as a Service Experts center.')
add_relationship('Service Experts','Enercare Inc.','Subsidiary of','unknown',True,'A','S020','Brookfield’s acquisition announcement identifies Service Experts within Enercare.')
add_relationship('Enercare Inc.','Brookfield Infrastructure Partners L.P.','Subsidiary of','2018-10-16',True,'A','S020|S022','Brookfield completed the Enercare acquisition and continues to report Service Experts as an operating business.',interest_type='control')

add_relationship('Service Wizard Heating & Air Conditioning','Champions Group Holdings','Operated by','2022-11-22',True,'A','S023|S025','Champions acquired Service Wizard; the Austin brand remains active.')
add_relationship('Champions Group Holdings','Odyssey Investment Partners','Portfolio company of','unknown',True,'C','S023|S024','Odyssey is the last closed sponsor established before the snapshot. This current flag is provisional pending proof of the announced Blackstone closing.',interest_type='last verified closed sponsor',relationship_status='provisional_current')
add_relationship('Champions Group Holdings','Blackstone','Acquired by','2026-02-17',False,'A','S024','Agreement announced; no closing confirmation located by the snapshot.',interest_type='pending acquisition',relationship_status='pending')

add_relationship('Abacus Plumbing, Air Conditioning & Electrical','Wrench Group, LLC','Subsidiary of','unknown',True,'A','S015','Current privacy policy states that Abacus is a wholly owned subsidiary of Wrench Group.')
add_relationship('Wrench Group, LLC','Leonard Green & Partners','Majority owned by','2022-11-09',True,'A','S016|S017','Leonard Green and management retained a majority interest.',interest_type='majority with management')
add_relationship('Wrench Group, LLC','TSG Consumer Partners','Minority investment from','2022-11-09',True,'A','S016','Significant minority investment.',interest_type='significant minority')
add_relationship('Wrench Group, LLC','Oak Hill Capital','Minority investment from','2022-11-09',True,'A','S016','Significant minority investment.',interest_type='significant minority')

add_relationship('Goettl Air Conditioning & Plumbing','Cortec Group','Portfolio company of','2021-12',True,'B','S019','Cortec investment is current; exact percentage is not stated publicly.',interest_type='unspecified control')
add_relationship('Dayton Services','Goettl Air Conditioning & Plumbing','Rebranded as','2021',False,'B','S018','Austin operations formerly marketed as Dayton Services were rebranded under Goettl.',relationship_status='historical')

add_relationship('ARS/Rescue Rooter Austin','American Residential Services, LLC','Operated by','unknown',True,'A','S026','Current Austin branch of American Residential Services.')
add_relationship('American Residential Services, LLC','GI Partners','Majority owned by','2020-09-15',True,'A','S027|S028','GI acquired a majority interest.',interest_type='majority')
add_relationship('American Residential Services, LLC','Charlesbank Capital Partners','Minority investment from','2020-09-15',True,'B','S027','Charlesbank retained a significant interest.',interest_type='significant minority')

# Franchises
add_relationship('Mr. Rooter Plumbing of Austin','Mr. Rooter Austin local franchisee (legal name unresolved)','Operated by','2012',True,'A','S029','Current local franchise operator; legal entity name unresolved.')
add_relationship('Mr. Rooter Plumbing of Austin','Neighborly','Franchise of','unknown',True,'A','S029|S030','Mr. Rooter is a Neighborly franchise; this does not make Neighborly the direct owner of the Austin operating company.')
add_relationship('Mr. Rooter Austin local franchisee (legal name unresolved)','Brett Bidwell','Majority owned by','2012',True,'A','S029','Current page identifies Brett Bidwell as local owner.',interest_type='local owner')
add_relationship('Neighborly','KKR','Portfolio company of','2021',True,'A','S030','KKR completed its acquisition of Neighborly.',interest_type='control')

add_relationship('Benjamin Franklin Plumbing of Austin','Benjamin Franklin Austin local franchisee (legal name unresolved)','Operated by','unknown',True,'B','S033','Current Austin local franchise; operator identity remains unresolved.')
add_relationship('Benjamin Franklin Plumbing of Austin','Authority Brands','Franchise of','unknown',True,'A','S031|S033','Benjamin Franklin Plumbing is an Authority Brands franchise system.')
add_relationship('Authority Brands','Apax Partners','Majority owned by','unknown',True,'A','S031|S032','Apax retained majority ownership after BCI investment.',interest_type='majority')
add_relationship('Authority Brands','British Columbia Investment Management Corporation','Minority investment from','2022',True,'A','S032','BCI reports a significant minority stake.',interest_type='significant minority')

add_relationship('Aire Serv of Cedar Park','Aire Serv Cedar Park local franchisee (legal name unresolved)','Operated by','unknown',True,'B','S034','Current independently owned franchise; legal entity and owner allocation unresolved.')
add_relationship('Aire Serv of Cedar Park','Neighborly','Franchise of','unknown',True,'A','S034|S036','Aire Serv is a Neighborly franchise system.')
add_relationship('Aire Serv of Round Rock','Aire Serv Round Rock local franchisee (legal name unresolved)','Operated by','unknown',True,'A','S035','Current local franchise.')
add_relationship('Aire Serv of Round Rock','Neighborly','Franchise of','unknown',True,'A','S035|S036','Aire Serv is a Neighborly franchise system.')
add_relationship('Aire Serv Round Rock local franchisee (legal name unresolved)','Chris Rattray','Majority owned by','unknown',True,'A','S035','Current site identifies Chris Rattray as owner/operator.',interest_type='local owner')

# SAS / Storr
for brand, start, src in [
    ('Austin Air Conditioning','2023-10-03','S037|S040|S044'),
    ('Roger’s Plumbing','2024-07-20','S038|S040'),
    ('Cool Atmosphere','2024-06-07','S039|S040'),
]:
    add_relationship(brand,'SAS Service Partners','Operated by',start,brand != 'Cool Atmosphere','A',src,'SAS acquisition/partnership announcement supports the operating relationship.',relationship_status='current' if brand != 'Cool Atmosphere' else 'historical_absorbed')
add_relationship('SAS Service Partners','Storr Group','Portfolio company of','2023',True,'A','S037|S038|S039','SAS repeatedly identifies itself as backed by Storr Group.',interest_type='backed; percentage unspecified')
add_relationship('Cool Atmosphere','Austin Air Conditioning','Combined with','2025',False,'B','S043','Cool Atmosphere is now presented within Austin Air Conditioning rather than as a separate current consumer brand.',relationship_status='historical')

# Roofing / foundation platform chains
add_relationship('Ja-Mar Roofing & Sheet Metal','Roofing Services Solutions','Operated by','2025-04-08',True,'A','S045|S047','RSS acquired Ja-Mar; current Ja-Mar brand remains active.')
add_relationship('Roofing Services Solutions','Dunes Point Capital','Portfolio company of','2025-04-08',True,'A','S045|S046','Dunes Point Capital controls the RSS platform.',interest_type='control')

add_relationship('Ram Jack Austin','Ram Jack Austin local franchisee (legal name unresolved)','Operated by','unknown',True,'B','S129','Current independently owned franchise; local legal entity unresolved.')
add_relationship('Ram Jack Austin','Ram Jack Austin local franchisee (legal name unresolved)','Franchise of','unknown',True,'B','S129','The public page confirms franchise status but does not expose a separate franchisor node in the evidence captured.',relationship_status='current')

add_relationship('Groundworks','Groundworks Companies, LLC','Operated by','unknown',True,'A','S048|S049','Austin service is delivered by the Groundworks platform.')
add_relationship('Groundworks Companies, LLC','KKR','Majority owned by','2023-03',True,'A','S049|S050','KKR became controlling/majority investor in March 2023.',interest_type='majority/control')
add_relationship('Groundworks Companies, LLC','Cortec Group','Minority investment from','2023-03',True,'A','S049|S050','Cortec retained minority positions after exiting majority control.',interest_type='minority')
add_relationship('Foundation Support Specialists','Groundworks Companies, LLC','Acquired by','2022-07-18',False,'A','S051','Groundworks acquired Foundation Support Specialists.',relationship_status='historical_absorbed')

# Pest platform chains
add_relationship('Aptive Environmental','Citation Capital','Majority owned by','2024-08-27',True,'A','S052|S053','Citation acquired a majority stake; management retained significant interest.',interest_type='majority')
add_relationship('Alta Pest Control','Alta founders and management','Majority owned by','2024-04',True,'A','S054','Founders retained operational and financial control after the investment.',interest_type='founder control')
add_relationship('Alta Pest Control','Trivest Partners','Minority investment from','2024-04',True,'A','S054','Trivest’s investment was explicitly non-control.',interest_type='non-control minority')
add_relationship('HomeTeam Pest Defense','Rollins, Inc.','Subsidiary of','2008-04-03',True,'A','S055|S056','Rollins completed the acquisition and still lists HomeTeam as a brand.')
add_relationship('Orkin','Rollins, Inc.','Subsidiary of','unknown',True,'A','S056|S153','Current Rollins brand relationship and Austin branch evidence.')
add_relationship('Terminix','Rentokil Initial plc','Subsidiary of','2022-10-12',True,'A','S057|S154','Rentokil completed the Terminix acquisition; Austin branch remains active.')
add_relationship('Hawx Pest Control','PCM Growth / PCM Encore','Portfolio company of','2021-03-12',True,'C','S058|S155','Last documented sponsor relationship. Current continuity was not independently reconfirmed, so this edge is provisional.',interest_type='last documented control',relationship_status='provisional_current')

# Local / family / legal-identity relationships
local_rels = [
    ('ABC Home & Commercial Services','Jenkins family / Bobby Jenkins','Majority owned by','unknown','B','S100','Current company identifies Bobby Jenkins as owner and the company as family owned.','family control'),
    ('McCullough Heating & Air Conditioning','McCullough local owners (exact holders unresolved)','Majority owned by','unknown','C','S105','Current company asserts local ownership; exact equity holders are not public.','self-reported local control'),
    ('McCullough Heating & Air Conditioning','Albert P. D’Andrea III','Locally managed by','unknown','B','S106','BBB identifies Albert P. D’Andrea III as president; this is management evidence, not sole ownership proof.','management'),
    ('Efficient AC, Electric & Plumbing','George Drazic and Molly Drazic','Majority owned by','2008','A','S107','Current company identifies George and Molly Drazic as owners.','owner control'),
    ('Reliant Plumbing','Max Hicks / Hicks family','Majority owned by','2014','B','S108','Current company history identifies Max Hicks/family ownership.','family control'),
    ('Christianson Air Conditioning & Plumbing','Christianson family','Majority owned by','unknown','C','S109','Current family-ownership claim; exact cap table unavailable.','family control claim'),
    ('Excalibur Plumbing','Excalibur Plumbing, LLC','DBA of','unknown','A','S110|S111','Current operating legal entity.' ,'legal identity'),
    ('Excalibur Plumbing, LLC','Blake Smith','Majority owned by','unknown','A','S110|S111','Managing member/owner evidence.','owner control'),
    ('Whitestone Plumbing','Ben Helton','Majority owned by','unknown','B','S112|S113','Current owner identified.','owner control'),
    ('Crow’s Plumbing Service','Jack Crow','Majority owned by','unknown','B','S114|S115','Managing member identified.','owner control'),
    ('AirFix Mechanical','AirFix Mechanical, LLC','DBA of','unknown','A','S116','Current legal operating identity.','legal identity'),
    ('Austin Major Air & Heat','Adoni Enterprises, Inc.','DBA of','unknown','B','S117','BBB alternate legal identity lead; controller remains unresolved.','legal identity lead'),
    ('Kidd Roofing','D.R. Kidd Company, Inc.','DBA of','unknown','B','S118|S119','Current operating identity lead.','legal identity'),
    ('Hall Roofing & Construction','Erik Hall','Majority owned by','unknown','B','S120','Current company materials identify Erik Hall as owner/leader.','owner control'),
    ('RoofCrafters','RoofCrafters, Inc.','DBA of','unknown','B','S121|S122','Current corporate identity and address.','legal identity'),
    ('RoofCrafters, Inc.','RoofCrafters family owners (exact holders unresolved)','Majority owned by','unknown','C','S121','Current family/local ownership claim; exact holders unavailable.','family control claim'),
    ('Longhorn Roofing','Tom Green','Majority owned by','2008','B','S123','Current company history identifies Tom Green as owner/leader.','owner control'),
    ('Anderson Roofing & Construction','Anderson family / local owners','Majority owned by','unknown','C','S124','Current family-owned claim; exact holders unavailable.','family control claim'),
    ('Silver Creek Exterior & Construction','Silver Creek local owners (identities unresolved)','Majority owned by','unknown','C','S125','Current local-ownership claim; identities unavailable.','local control claim'),
    ('Advanced Foundation Repair','Advanced Foundation Repair, LP','DBA of','unknown','B','S132|S133','Current legal identity.','legal identity'),
    ('Baird Foundation Repair','John Baird and Melanie Baird','Majority owned by','1987','A','S134','Current company states John and Melanie Baird are sole owners.','sole ownership'),
    ('G.L. Hunt Foundation Repair','Gary Hunt / Hunt family','Majority owned by','1987','B','S135','Current family-ownership evidence.','family control'),
    ('All in One Foundation Repair','Robert J. Knight','Majority owned by','unknown','B','S136|S137','Current owner identified by business profile.','owner control'),
    ('Bats Foundation Repair','Brent Parks','Majority owned by','unknown','A','S138','Principal owner/managing member identified.','owner control'),
    ('Quality Foundation Repair','Simon Wallace','Majority owned by','unknown','B','S140|S141','Named founder/owner and current Austin operating identity.','owner control'),
    ('Bruecher Foundation','Bruecher family / local owners','Majority owned by','unknown','C','S142','Current family-business claim; exact holders unavailable.','family control claim'),
    ('A-Tex Pest Management','A-Tex local owners (exact holders unresolved)','Majority owned by','unknown','C','S143','Current local-ownership claim; exact holders unavailable.','local control claim'),
    ('A-Tex Pest Management','Jason Napolski','Locally managed by','unknown','C','S144','President/CEO lead; not treated as sole ownership proof.','management'),
    ('Bulwark Exterminating','Seever family','Majority owned by','unknown','B','S146','Current company materials describe family ownership.','family control'),
    ('Berrett Home Services / Berrett Pest Control','Nathan Berrett / Berrett family','Majority owned by','unknown','A','S147|S148','Founder/president and family operation identified.','family control'),
    ('Romney Pest Control','Greg Romney / Romney family','Majority owned by','unknown','B','S150','Current company identifies Greg Romney and family ownership.','family control'),
    ('Pest Wranglers','Wranglers Service Group, Inc.','DBA of','unknown','B','S151','Current legal operating identity lead.','legal identity'),
    ('Wranglers Service Group, Inc.','Pest Wranglers local owners (identities unresolved)','Majority owned by','unknown','C','S151','Current local-ownership claim; exact holders unavailable.','local control claim'),
    ('Stride Pest Control','Stride Pest Control, LLC','DBA of','unknown','A','S152','Current legal identity.','legal identity'),
    ('Stride Pest Control, LLC','Tyson Kearns','Majority owned by','unknown','A','S152','Current owner identified.','owner control'),
    ('Ranger Termite & Pest Control','Ranger Termite & Pest Control, Inc.','DBA of','unknown','B','S156|S157','Current corporate identity; owner references conflict.','legal identity'),
    ('Massey Services','Massey family / Tony Massey','Majority owned by','unknown','A','S160','Current company describes family ownership.','family control'),
    ('Natran Green Pest Control','Gordon Doran','Majority owned by','2006','A','S161','Founder/owner/CEO identified.','owner control'),
    ('X Out Pest Services','X Out Pest Services, LLC','DBA of','unknown','B','S162|S163','Current legal identity.','legal identity'),
    ('X Out Pest Services, LLC','Dewey Petersen','Majority owned by','unknown','B','S163','Managing member identified.','owner control'),
    ('ClearDefense Pest Control','ClearDefense founders','Majority owned by','unknown','B','S164','Founder-led structure established; exact current allocation unavailable.','founder control partial'),
    ('Roberts Termite & Pest Control','Roberts family / local owners','Majority owned by','unknown','C','S165','Current family-owned claim; exact holders unavailable.','family control claim'),
    ('Absolute Pest Management','Tony Ragan / Ragan family','Majority owned by','unknown','B','S166','Current president and family-ownership evidence.','family control'),
]
for fr, to, edge, start, rating, src, note, interest in local_rels:
    add_relationship(fr,to,edge,start,True,rating,src,note,interest_type=interest)

# Historical transaction edges that should never be read as current ownership.
add_relationship('Stan’s Heating, Air, Plumbing & Electrical','Treaty Oak Equity','Sold by','2024-03-25',False,'A','S011|S012','Treaty Oak was the seller/former sponsor.',end_date='2024-03-25',relationship_status='historical') if False else None
# Treaty Oak is intentionally not added as a public graph node because it is historical-only; the sale is captured in transactions.

# ---------------------------
# Transactions, conflicts, unresolved items
# ---------------------------

# Additional top-down warning entities and source.
add_source('S061', 'Apex Service Partners and Alpine Investors Announce Strategic Minority Investment from Apollo', 'https://www.apollo.com/insights-news/pressreleases/2026/05/apex-service-partners-and-alpine-investors-announce-strategic-mi', 'Apollo', 'pending transaction announcement', 'primary', 'apollo', 'A', '2026-05', 'Minority investment announced; expected close Q4 2026')
add_entity('Apex Service Partners','Platform','US','','','current','', 'S061','No specific Austin-facing house brand was verified in this package.')
add_entity('Alpine Investors','Sponsor','US','','','current','', 'S061','Existing Apex sponsor/investor.')
add_entity('Apollo','Sponsor','US','','','pending_minority_investor','', 'S061','Announced minority investor; expected Q4 2026 close.')
add_entity('Treaty Oak Equity','Sponsor','Texas','','','historical','', 'S012','Former sponsor of Stan’s.')
add_entity('Massey Services operating company','Legal entity','US','Corporation','','current','', 'S059|S160','Used to distinguish the company from the consumer brand node.')
add_entity('EcoShield Austin division (2015 assets)','Legal entity','Texas','','','historical','Austin', 'S059','Historical divisional assets acquired by Massey; not assumed identical to the current EcoShield Austin brand.')

transactions: list[dict] = []

def add_transaction(
    target: str,
    buyer: str,
    seller: str,
    announcement_date: str,
    close_date: str,
    status: str,
    transaction_type: str,
    interest_acquired: str,
    source_ids: str,
    current_effect: str,
    notes: str = '',
    date_precision: str = 'day',
) -> str:
    tid = f'T{len(transactions)+1:03d}'
    transactions.append({
        'transaction_id': tid,
        'target': target,
        'buyer': buyer,
        'seller': seller,
        'announcement_date': announcement_date,
        'close_date': close_date,
        'date_precision': date_precision,
        'status_as_of_snapshot': status,
        'transaction_type': transaction_type,
        'interest_acquired': interest_acquired,
        'current_effect': current_effect,
        'source_ids': source_join(source_ids),
        'access_date': ACCESS_DATE,
        'notes': notes,
    })
    return tid

add_transaction('Precision Heating & Air','Southern Home Services','','2020-07','2020-06-30','closed','acquisition','control / complete operating-company acquisition not further specified','S001','Precision remains a Southern consumer brand.','The source states the transaction was completed June 30, 2020.','month')
add_transaction('Fox Service Company','Southern Home Services','','2020-07-18','','closed','acquisition','control / complete operating-company acquisition not further specified','S002','Fox remains a Southern consumer brand.','Close date not separately stated in the source captured.')
add_transaction('Southern Home Services / NAEHS','Gryphon Investors','MSouth Equity Partners','2021-10','2021-10','closed','majority investment','majority; management retained meaningful stake','S006|S007','Gryphon is current controlling sponsor through NAEHS.','', 'month')
add_transaction('Daniel’s Plumbing & Air Conditioning','Southern Home Services','','2022-04-07','','closed','acquisition','control / complete operating-company acquisition not further specified','S003|S004','Daniel’s remains listed as a Southern Austin brand; consumer-brand activity is flagged.','')
add_transaction('Radiant / T3 Services Group','The Riverside Company','','2020-11','','closed','platform investment','interest percentage unspecified','S009|S010','Radiant sits within the Riverside-backed T3 platform.','Riverside dates the T3 investment to November 2020; some secondary accounts describe a 2021 Radiant investment.', 'month')
add_transaction('Stan’s Home Services','Treaty Oak Equity','','2018','','historical_closed','platform investment','control unspecified','S012','Treaty Oak was a former sponsor and exited in 2024.','', 'year')
add_transaction('LTP Home Services Group / Master Trades Group','L Catterton','','2022-03-22','','closed','acquisition','control','S013|S014','L Catterton is current sponsor of Master Trades Group.','')
add_transaction('Stan’s Home Services Holdings','The Master Trades Group','Treaty Oak Equity','2024-03-25','2024-03-25','closed','acquisition','control','S011|S012','Stan’s now sits within Master Trades Group.','')
add_transaction('Enercare Inc. (including Service Experts)','Brookfield Infrastructure','','2018-08-01','2018-10-16','closed','strategic acquisition','control','S020','Service Experts remains within Brookfield-controlled Enercare.','')
add_transaction('Wrench Group','TSG Consumer Partners and Oak Hill Capital','Existing Leonard Green and management holders','2022-11-09','2022-11-09','closed','recapitalization / minority investment','significant minority; Leonard Green and management retained majority','S016','Abacus remains a Wrench subsidiary.','')
add_transaction('Goettl Air Conditioning & Plumbing','Cortec Group','','2021-12','','closed','platform investment','control percentage unspecified','S019','Goettl is treated as Cortec-backed.','', 'month')
add_transaction('Service Wizard Heating & Air Conditioning','Champions Group Holdings','','2022-11-22','','closed','acquisition','control','S023','Service Wizard remains a Champions brand.','')
add_transaction('Champions Group Holdings','Blackstone','Odyssey Investment Partners','2026-02-17','','pending_at_snapshot','acquisition agreement','control if/when closed','S024','No current-owner change recorded without closing evidence.','Expected to close in the first half of 2026; no closing confirmation located by July 26, 2026.')
add_transaction('American Residential Services','GI Partners','Charlesbank Capital Partners / prior holders','2020-09-15','','closed','majority investment','majority; Charlesbank and management significant minority','S027|S028','GI remains majority sponsor.','')
add_transaction('Neighborly','KKR','','2021','','closed','acquisition','control','S030','KKR owns the franchisor, not Austin franchisee operating companies.','', 'year')
add_transaction('Authority Brands','British Columbia Investment Management Corporation','Apax and existing holders','2022','','closed','minority investment','significant minority; Apax retained majority','S031|S032','Franchisor capital structure only.','', 'year')
add_transaction('Austin Air Conditioning','SAS Service Partners','','2023-10-03','2023-10-03','closed','acquisition','control with seller rollover equity','S037|S040|S044','Austin Air remains an active SAS brand.','SAS article and index dates conflict; the chronological index date is used.')
add_transaction('Cool Atmosphere','SAS Service Partners','','2024-06-07','2024-06-07','closed','acquisition','control; founders joined platform','S039|S040','Brand later combined into Austin Air Conditioning.','SAS article and index years conflict; the chronological index date is used.')
add_transaction('Roger’s Plumbing','SAS Service Partners','','2024-07-20','2024-07-20','closed','acquisition','control; founder joined platform','S038|S040','Roger’s remains an active SAS brand.','SAS article and index years conflict; the chronological index date is used.')
add_transaction('Ja-Mar Roofing & Sheet Metal','Roofing Services Solutions','','2025-04-08','2025-04-08','closed','acquisition','control','S045|S046','Ja-Mar remains an active retained brand inside the Dunes Point-backed platform.','')
add_transaction('Foundation Support Specialists','Groundworks','','2022-07-18','2022-07-18','closed','acquisition','control','S051','Former brand treated as absorbed/rebranded rather than a separate current record.','')
add_transaction('Groundworks','KKR','Cortec Group / existing holders','2023-03','2023-03','closed','majority investment / recapitalization','KKR control; Cortec retained minority','S049|S050','KKR is current controller; Cortec remains a minority investor.','', 'month')
add_transaction('Aptive Environmental','Citation Capital','Existing holders','2024-08-27','2024-08-27','closed','majority investment','majority; management significant minority','S052','Citation is current majority investor.','')
add_transaction('Alta Pest Control','Trivest Partners','Founders / existing holders','2024-04','2024-04','closed','growth investment','non-control minority; founders retained control','S054','Alta is not coded as Trivest-controlled.','', 'month')
add_transaction('HomeTeam Pest Defense','Rollins, Inc.','','2008-04-03','2008-04-03','closed','strategic acquisition','control','S055|S056','HomeTeam remains a Rollins brand.','')
add_transaction('Terminix','Rentokil Initial plc','','2021-12-14','2022-10-12','closed','strategic acquisition','control','S057','Terminix is current Rentokil-owned brand.','')
add_transaction('Hawx Services','PCM Growth','','2021-03-12','2021-03-12','closed_then_current_unverified','acquisition','control at transaction date','S058','The 2021 sponsor relationship is documented; current continuity remains unresolved.','')
add_transaction('EcoShield Austin division (2015 assets)','Massey Services','','2015','2015','historical_closed','asset/division acquisition','Austin division assets','S059','Does not establish that the present EcoShield Austin brand is owned by Massey.','', 'year')
add_transaction('Apex Service Partners','Apollo','Alpine Investors / existing holders','2026-05','','pending_at_snapshot','minority investment','minority; Alpine remains involved','S061','No Austin-facing Apex house brand was added to the published universe.','Expected close in Q4 2026; included as a warning against premature Apollo ownership labels.', 'month')

conflicts: list[dict] = []

def add_conflict(record: str, field: str, claim_a: str, source_a: str, claim_b: str, source_b: str, resolution: str, status: str = 'resolved_for_publication') -> str:
    cid = f'C{len(conflicts)+1:03d}'
    conflicts.append({
        'conflict_id': cid,
        'record_or_scope': record,
        'field': field,
        'claim_a': claim_a,
        'source_ids_a': source_join(source_a),
        'claim_b': claim_b,
        'source_ids_b': source_join(source_b),
        'resolution': resolution,
        'status': status,
        'snapshot_date': SNAPSHOT_DATE,
    })
    return cid

add_conflict('Research package','input completeness','Model A states eight structured deliverables were attached.','I001','The uploaded DOCX contains only broken links; no structured files were separately supplied.','I001','Reconstructed a new dataset from report text and underlying sources. The original CSV provenance cannot be audited.', 'open_provenance_gap')
add_conflict('Research package','cross-model reconciliation','Model B presents a top-down ownership map.','I002','Model B explicitly states that Model A’s input files were unavailable.','I002','Treat Model B as an independent lead set, not a merged or reconciled dataset.', 'resolved_for_publication')
add_conflict('Precision Heating & Air','citation support','Model B cites a Fox careers page for Precision’s Southern relationship.','I002','Southern’s Precision acquisition and current brand evidence directly support the relationship.','S001|S005|S006','Rejected the mismatched citation and replaced it with direct primary evidence.')
add_conflict('Daniel’s Plumbing & Air Conditioning','citation support','Model B cites FoxNews.com for Daniel’s ownership.','I002','Southern’s acquisition archive and current Daniel’s brand page support the relationship.','S003|S004|S005','Rejected the unrelated citation and replaced it with direct primary evidence.')
add_conflict('Daniel’s Plumbing & Air Conditioning','consumer-brand status','Southern currently lists Daniel’s as an Austin brand.','S004|S005','Consumer-facing routing and consolidation signals suggest the standalone brand may be partially merged.','I001','Counted as current-facing with a visible activity-status conflict; no separate active-location count is inferred.', 'open')
add_conflict('Service Wizard / Champions','ultimate sponsor','Blackstone announced an agreement expected to close in first-half 2026.','S024','No closing announcement was located by July 26, 2026; Odyssey is the last closed sponsor in the record.','S023|S024','Current platform is Champions. Ultimate sponsor is marked pending/unresolved, not Blackstone-owned.', 'open')
add_conflict('Austin Air Conditioning','transaction date','SAS article page renders a later year.','S037','SAS chronological news index places the transaction on October 3, 2023.','S040','Used 2023-10-03 and preserved the CMS date conflict.')
add_conflict('Cool Atmosphere','transaction date','SAS article page renders a later year.','S039','SAS chronological news index places the transaction on June 7, 2024.','S040','Used 2024-06-07 and preserved the CMS date conflict.')
add_conflict('Roger’s Plumbing','transaction date','SAS article page renders a later year.','S038','SAS chronological news index places the transaction on July 20, 2024.','S040','Used 2024-07-20 and preserved the CMS date conflict.')
add_conflict('Cool Atmosphere','current brand count','Model A-style census logic could count Cool Atmosphere as a separate active Austin brand.','I001|S039','Current brand routing presents it within Austin Air Conditioning.','S043','Removed it from the active-brand denominator and retained it as a historical absorbed brand.')
add_conflict('Ja-Mar Roofing & Sheet Metal','local ownership language','Current Ja-Mar site uses local-owner/local-company language.','S047','Dunes Point Capital states that its platform acquired Ja-Mar in April 2025.','S045|S046','Classified as sponsor-backed. “Local” wording is treated as operating/management language unless equity documentation says otherwise.')
add_conflict('Groundworks','control allocation','Model B treated KKR/Cortec control allocation as unresolved.','I002','Groundworks and Cortec materials establish KKR control/majority and Cortec minority retention.','S049|S050','Updated to KKR majority/control, Cortec minority.')
add_conflict('Alta Pest Control','investment classification','A generic PE-backed label could imply Trivest control.','I002','Trivest explicitly calls the investment minority and non-control, with founders retaining control.','S054','Classified separately as minority-invested, founder-controlled.')
add_conflict('Quality Foundation Repair','inclusion status','Model A excluded the company as too generic/directory-dependent.','I001','Current official, BBB, and founder evidence supports a real Austin operator.','S139|S140|S141','Reversed the exclusion and added the brand with named-owner evidence.')
add_conflict('EcoShield Pest Solutions','current owner','Massey acquired EcoShield’s Austin division in 2015.','S059','A current EcoShield-branded Austin branch is active, but the present legal/operator chain is not disclosed.','S158','Recorded the 2015 transaction as historical only; current EcoShield ownership remains unresolved.', 'open')
add_conflict('Ranger Termite & Pest Control','controller identity','One current business profile identifies Mark Lipscomb as president/director.','S157','Other public professional references identify a different person as owner.','I001','Do not publish an individual controller until state/entity records resolve the conflict.', 'open')
add_conflict('Hawx Pest Control','current sponsor','PCM Growth acquired Hawx in 2021.','S058','No sufficiently current direct portfolio or closing-chain source was found for July 2026.','S155','Retain PCM as the last documented sponsor, but classify current control as unresolved.', 'open')
add_conflict('Benjamin Franklin Plumbing of Austin','franchisee ownership','Franchisor ownership by Apax/BCI is clear.','S031|S032','Local Austin franchisee legal entity and owner are not established by strong current sources.','S033','Separate franchisor ownership from local operator; leave franchisee unresolved.', 'open')
add_conflict('Radiant','source quality','Model B relied on a transaction database for Riverside’s investment.','I002','Current Radiant terms, T3, and Riverside pages provide direct evidence.','S008|S009|S010','Replaced the secondary database with primary sources.')
add_conflict('Market conclusions','market share','Review counts, permits, branch pages, and search visibility can look like size measures.','I001|I002','No comparable revenue, jobs, or customer denominator exists across all brands.','I001|I002','All reported percentages are brand-record shares within the reconstructed publication universe, never market share.')

unresolved: list[dict] = []

def add_unresolved(subject: str, question: str, current_treatment: str, needed_evidence: str, priority: str, source_ids: str = '') -> str:
    uid = f'U{len(unresolved)+1:03d}'
    unresolved.append({
        'unresolved_id': uid,
        'subject': subject,
        'question': question,
        'current_treatment': current_treatment,
        'needed_evidence': needed_evidence,
        'priority': priority,
        'source_ids': source_join(source_ids),
        'snapshot_date': SNAPSHOT_DATE,
    })
    return uid

unresolved_items = [
    ('Service Wizard / Champions','Did the announced Blackstone acquisition close before July 26, 2026?','Champions platform verified; ultimate sponsor marked pending/unresolved.','Closing announcement, regulatory filing, fund portfolio update, or corporate registry evidence.','high','S023|S024'),
    ('Daniel’s Plumbing & Air Conditioning','Is Daniel’s still a fully standalone consumer brand and operating location?','Counted as current-facing because Southern maintains a current brand page; activity conflict disclosed.','Current phone routing, Texas licenses, assumed-name records, current location pages, or Southern confirmation.','high','S004|S005'),
    ('Benjamin Franklin Plumbing of Austin','What legal entity and person own the Austin franchisee?','Franchise structure verified; local operator unresolved.','Texas SOS entity file, assumed-name filing, plumbing license, franchise disclosure/local terms.','high','S031|S032|S033'),
    ('Aire Serv of Cedar Park','What legal entity and current owners hold the local franchise?','Current independently operated franchise; legal identity unresolved.','Texas entity/assumed-name filing and current franchise/license record.','medium','S034|S036'),
    ('Ram Jack Austin','What legal entity and current owners hold the Austin franchise?','Current independently operated franchise; legal identity unresolved.','Texas entity/assumed-name filing, local contract terms, franchisee disclosure.','high','S129'),
    ('Austin Major Air & Heat','Who currently controls Adoni Enterprises, Inc. and the brand?','Current operator included; ownership unresolved.','Texas SOS records, HVAC license holder, assumed-name filing, shareholder/owner statement.','medium','S117'),
    ('AirFix Mechanical','Who owns AirFix Mechanical, LLC?','Legal entity and operation verified; controller unresolved.','Texas SOS records, license holder, signed terms/privacy page, owner confirmation.','medium','S116'),
    ('Kidd Roofing','Who currently owns D.R. Kidd Company, Inc.?','Current company and legal identity verified; equity control unresolved.','Texas corporate records, shareholder/owner statement, financing documents.','medium','S118|S119'),
    ('RoofCrafters','Who are the current equity owners of RoofCrafters, Inc.?','Family/local ownership claim recorded; exact holders unresolved.','Texas corporate records or signed owner disclosure.','medium','S121|S122'),
    ('Wilson Roofing','Who currently controls the Austin operating company?','Current operator included; ownership unresolved.','Texas entity records, terms/privacy page, license/permit identity, owner confirmation.','medium','S126'),
    ('Austin Roofing and Construction','Who are the current controlling partners and legal entity?','Current partnership included; control unresolved.','Texas partnership/entity records and current terms.','medium','S127'),
    ('Olshan Foundation Repair','Who is the current ultimate controlling owner?','Current Austin operation verified; controller unresolved.','Corporate registry, ownership disclosure, lender/transaction materials, authoritative company statement.','high','S128'),
    ('CenTex Foundation Repair','Who controls the company today?','Founder history known; present ownership unresolved.','Texas entity records, current owner statement, succession documentation.','medium','S130'),
    ('Douglas Foundation Repair','What is the operating legal entity and current controller?','Current Austin operator included; ownership unresolved.','Texas entity and assumed-name filings, permit/license records, owner confirmation.','medium','S131'),
    ('Advanced Foundation Repair','Who controls Advanced Foundation Repair, LP?','Legal entity and current operation verified; controller unresolved.','Texas LP general-partner filing and current ownership disclosure.','high','S132|S133'),
    ('Hawx Pest Control','Is PCM Growth/PCM Encore still the current controller?','2021 sponsor relationship retained as last documented; current control unresolved.','Current sponsor portfolio page, company ownership statement, financing or sale record.','high','S058|S155'),
    ('Ranger Termite & Pest Control','Who is the current equity owner?','Operating corporation verified; conflicting individual references preserved.','Texas corporate records, TDA business-license file, direct owner confirmation.','high','S156|S157'),
    ('EcoShield Pest Solutions Austin','Who owns and operates the current Austin branch after the 2015 divisional sale?','Current branch verified; 2015 Massey transaction treated as historical only.','Current TDA business-license record, legal terms, entity/branch filing, parent-company confirmation.','high','S059|S158'),
    ('A-Tex Pest Management','Who are the current equity owners?','Local ownership claim and president lead recorded; exact holders unresolved.','TDA business-license record, Texas entity filing, direct owner statement.','medium','S143|S144'),
    ('Pest Wranglers','Who owns Wranglers Service Group, Inc.?','Legal entity/local claim recorded; individual owners unresolved.','Texas corporate records and TDA license ownership records.','medium','S151'),
    ('Christianson Air Conditioning & Plumbing','What is the current cap-table/owner allocation?','Family-owned claim accepted as a claim, not a verified cap table.','Texas entity/shareholder evidence or current signed owner statement.','low','S109'),
    ('McCullough Heating & Air Conditioning','Who are the exact current equity holders?','Local ownership claim recorded; president separately identified.','Texas corporate/shareholder records or direct current owner disclosure.','low','S105|S106'),
    ('SAS Service Partners transactions','What are the legally effective close dates for all Austin acquisitions?','Chronological news-index dates used; CMS conflicts preserved.','Executed closing releases, filings, or company confirmation.','medium','S037|S038|S039|S040'),
    ('Austin metro long tail','Which small operators remain missing in Hutto, Manor, Bee Cave, Dripping Springs, Buda, Kyle, Georgetown and Leander?','The 67-brand denominator is a reconstructed publication universe, not a complete licensed-business census.','Systematic license exports, local permits, chambers, maps, and county assumed-name records.','high','I001'),
    ('Legal identities for acquired brands','What are the exact Texas operating entities behind Fox, Precision, Daniel’s, Strand Brothers, Service Wizard, Abacus, Austin Air, Roger’s and Ja-Mar?','Consumer-brand and parent chains are published; some intermediate legal entities remain omitted.','Texas SOS, assumed-name, trade-license, contract terms, and transaction schedule records.','high','S001|S002|S003|S015|S021|S023|S037|S038|S045'),
]
for item in unresolved_items:
    add_unresolved(*item)

# ---------------------------
# Calculations and validation
# ---------------------------

published = [b for b in brands if b['inclusion_status'] == 'published_active']
historical = [b for b in brands if b['inclusion_status'] == 'historical_not_denominator']
headline_denominator = len(published)
owner_type_counts = Counter(b['current_owner_type'] for b in published)
category_counts = Counter(b['primary_category'] for b in published)
verification_counts = Counter(b['ownership_verification_status'] for b in published)
evidence_counts = Counter(b['evidence_rating'] for b in published)
retained_count = sum(1 for b in published if b['retained_consumer_brand_after_transaction'])
franchise_count = sum(1 for b in published if b['franchise_flag'])
unresolved_owner_count = owner_type_counts['Private/control unresolved']
current_chain_high_conf = sum(1 for b in published if b['evidence_rating'] in {'A','B'} and not b['ownership_verification_status'].startswith('unresolved'))

# Major multi-brand platform counts based on current brand rows.
platform_counts = Counter(b['current_platform_or_franchise_system'] for b in published if b['current_platform_or_franchise_system'])
platform_counts = Counter({k:v for k,v in platform_counts.items() if v >= 2})

metrics = {
    'snapshot_date': SNAPSHOT_DATE,
    'headline_denominator_active_austin_facing_brands': headline_denominator,
    'historical_absorbed_or_rebranded_records': len(historical),
    'owner_type_counts': dict(owner_type_counts),
    'owner_type_percentages': {k: round(v / headline_denominator * 100, 1) for k,v in owner_type_counts.items()},
    'franchise_brand_count': franchise_count,
    'retained_brand_after_transaction_count': retained_count,
    'private_control_unresolved_count': unresolved_owner_count,
    'high_or_medium_confidence_non_unresolved_ownership_structure_count': current_chain_high_conf,
    'high_or_medium_confidence_non_unresolved_ownership_structure_pct': round(current_chain_high_conf / headline_denominator * 100, 1),
    'evidence_rating_counts': dict(evidence_counts),
    'verification_status_counts': dict(verification_counts),
    'category_counts': dict(category_counts),
    'multi_brand_platform_counts': dict(platform_counts),
    'relationship_count': len(relationships),
    'transaction_count': len(transactions),
    'source_count': len(sources),
    'unresolved_question_count': len(unresolved),
    'conflict_count': len(conflicts),
    'denominator_note': 'Percentages are shares of the 67 active Austin-facing consumer-brand records in the reconstructed publication universe. They are not revenue, customer, job, permit, review, search, or market share.',
}

# Source and structural validation.
for b in brands:
    for field in ('presence_source_ids','ownership_source_ids'):
        for sid in [x for x in b[field].split('|') if x]:
            if sid not in source_by_id:
                raise ValueError(f"Brand {b['brand_name']} references missing source {sid}")
for r in relationships:
    if not r['source_ids']:
        raise ValueError(f"Relationship {r['relationship_id']} has no source")
    if not r['start_date']:
        raise ValueError(f"Relationship {r['relationship_id']} has no effective start date marker")
    for sid in r['source_ids'].split('|'):
        if sid not in source_by_id:
            raise ValueError(f"Relationship {r['relationship_id']} references missing source {sid}")
    if r['from_entity_id'] not in {e['entity_id'] for e in entities} or r['to_entity_id'] not in {e['entity_id'] for e in entities}:
        raise ValueError(f"Relationship {r['relationship_id']} has missing node")
for t in transactions:
    for sid in [x for x in t['source_ids'].split('|') if x]:
        if sid not in source_by_id:
            raise ValueError(f"Transaction {t['transaction_id']} references missing source {sid}")
if headline_denominator != 67:
    raise ValueError(f'Headline denominator drifted to {headline_denominator}; expected 67')
if sum(owner_type_counts.values()) != headline_denominator:
    raise ValueError('Owner type counts do not reconcile')

# CSV writers

def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text('', encoding='utf-8')
        return
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()), extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)

write_csv(OUT / 'master_brands.csv', brands)
write_csv(OUT / 'master_entities.csv', entities)
write_csv(OUT / 'master_relationships.csv', relationships)
write_csv(OUT / 'master_transactions.csv', transactions)
write_csv(OUT / 'master_evidence.csv', sources)
write_csv(OUT / 'master_footprint.csv', footprints)
write_csv(OUT / 'master_conflicts.csv', conflicts)
write_csv(OUT / 'master_unresolved.csv', unresolved)
(OUT / 'verified_findings.json').write_text(json.dumps(metrics, indent=2, ensure_ascii=False), encoding='utf-8')

# ---------------------------
# Narrative deliverables
# ---------------------------

def pct(n: int, d: int = headline_denominator) -> str:
    return f'{(n/d*100):.1f}%'

sector_counts = {
    'HVAC, plumbing and electrical': sum(1 for b in published if b['primary_category'] in {'HVAC / plumbing / electrical','HVAC','HVAC / plumbing','Plumbing','HVAC / electrical / plumbing'}),
    'Roofing and exterior': sum(1 for b in published if b['primary_category'] in {'Roofing / exterior','Roofing'}),
    'Foundation repair': sum(1 for b in published if b['primary_category'] == 'Foundation repair'),
    'Pest control': sum(1 for b in published if b['primary_category'] == 'Pest control'),
}
metrics['sector_counts'] = sector_counts
metrics['sector_percentages'] = {k: round(v/headline_denominator*100,1) for k,v in sector_counts.items()}
(OUT / 'verified_findings.json').write_text(json.dumps(metrics, indent=2, ensure_ascii=False), encoding='utf-8')

article = f"""# Who Owns Austin’s Home-Service Companies? A Verified Map of Private Equity, Roll-Ups, and Local Brands

*A documented map of the parent companies, private-equity sponsors, public corporations, franchises and independent operators behind the home-service brands advertising across Austin.*

**Snapshot date:** July 26, 2026  
**Publication universe:** {headline_denominator} active Austin-facing consumer brands  
**Coverage:** HVAC, plumbing, bundled residential electrical, roofing and exterior services, foundation repair, and pest control

## Executive findings

- The reconstructed publication universe contains **{headline_denominator} active Austin-facing consumer brands**: {sector_counts['HVAC, plumbing and electrical']} in HVAC, plumbing or bundled electrical; {sector_counts['Roofing and exterior']} in roofing and exterior services; {sector_counts['Foundation repair']} in foundation repair; and {sector_counts['Pest control']} in pest control.
- **{owner_type_counts['Sponsor-backed platform']} brands ({pct(owner_type_counts['Sponsor-backed platform'])})** sit inside sponsor-backed operating platforms. **{owner_type_counts['Public-company owned']} ({pct(owner_type_counts['Public-company owned'])})** have public-company parents. **{owner_type_counts['Local franchise operator']} ({pct(owner_type_counts['Local franchise operator'])})** are local franchises whose operator must be separated from the franchisor’s owner.
- **{owner_type_counts['Founder/family/local ownership']} brands ({pct(owner_type_counts['Founder/family/local ownership'])})** are coded to founder, family or local ownership based on a named-owner trail or a current ownership claim. That bucket is not a cap-table audit. Nine of the 67 records rely on current self-reporting rather than a complete legal chain.
- **{owner_type_counts['Private/control unresolved']} brands ({pct(owner_type_counts['Private/control unresolved'])})** remain private but have no publication-grade current controller. Alta Pest Control is classified separately because Trivest’s investment was explicitly minority and non-control, with founders retaining control. [S054]
- For **{current_chain_high_conf} of {headline_denominator} brands ({pct(current_chain_high_conf)})**, the current ownership structure is rated A or B and is not coded unresolved. This includes some franchise or platform rows where the ownership structure is clear but an intermediate local legal entity remains unknown.
- **{retained_count} brands** continue under an established consumer name after an acquisition or platform transaction. A retained name says little by itself about current ownership.

## One group, several Austin names

An Austin homeowner can encounter Fox Service Company, Precision Heating & Air, and Daniel’s Plumbing & Air Conditioning as separate names. At the ownership level, the paths converge. Southern Home Services acquired Precision in 2020, announced the Fox acquisition the same year, and added Daniel’s in 2022. Southern still lists all three in its current brand materials. Southern itself sits within North American Essential Home Services, the holding structure in which Gryphon Investors completed a majority investment in 2021. Management retained a meaningful stake. [S001][S002][S003][S004][S005][S006][S007]

That does not mean the three brands are interchangeable. They may have different phone numbers, trade licenses, service histories, crews and customer relationships. It does mean that a list of consumer-facing names can materially overstate the number of unrelated owners in the market.

A second cluster was largely absent from the original census. Austin Air Conditioning and Roger’s Plumbing are current brands inside SAS Service Partners, an Austin-based platform backed by Storr Group. SAS also acquired Cool Atmosphere. That name is now presented within Austin Air Conditioning, so this database treats Cool Atmosphere as an absorbed historical record rather than a separate current brand. The transaction pages contain conflicting rendered years; the chronology in SAS’s own news index is used and the discrepancy is preserved in the conflict table. [S037][S038][S039][S040][S041][S042][S043][S044]

These examples explain the unit of analysis used here. The database counts a consumer-facing brand when it currently serves Austin, but it separately records legal entities, platforms, holding companies, sponsors, public parents, franchise systems and local franchisees. One brand can create several graph nodes. Several brands can lead to one owner.

## The ownership map

The public map defaults to a narrow chain: **consumer brand → current platform or local operator → ultimate owner or sponsor**. That is the useful view for most readers. The deeper view adds legal entities, minority investors, former sponsors and transaction edges.

The default cannot be a force-directed web of every relationship. With 67 active brands, 170 entity nodes and 102 relationship edges, an all-at-once diagram becomes a hairball. The interactive version therefore opens to sponsor-backed brands, lets the reader filter by service category and owner type, and reveals intermediate entities on demand. Franchise edges use a different label from subsidiary edges. Pending transactions do not replace current-owner edges.

Each brand also has a mobile chain card. A card can say, for example:

> **Mr. Rooter Plumbing of Austin**  
> Local operator: Brett Bidwell’s Austin franchisee, legal entity unresolved  
> Franchise system: Neighborly  
> Franchisor owner: KKR  
> Meaning: KKR owns Neighborly, not the Austin franchisee operating company. [S029][S030]

That last sentence matters. Treating a franchisor’s sponsor as the direct owner of every local franchisee is a category error.

## What the 67-brand denominator shows

The owner-type distribution is a count of brands in this dataset, not a count of legal entities and not a measure of revenue. The 14 sponsor-backed brands are Fox, Precision, Daniel’s, Radiant, Stan’s, Service Wizard, Abacus, Goettl, ARS/Rescue Rooter, Austin Air Conditioning, Roger’s Plumbing, Ja-Mar, Groundworks and Aptive. The four public-company-owned brands are Strand Brothers Service Experts, HomeTeam Pest Defense, Orkin and Terminix.

The five franchise records are Mr. Rooter Plumbing of Austin, Benjamin Franklin Plumbing of Austin, Aire Serv of Cedar Park, Aire Serv of Round Rock and Ram Jack Austin. Their local operators are not collapsed into Neighborly, Authority Brands or Ram Jack’s franchise system. For Mr. Rooter and Aire Serv of Round Rock, the public record identifies local owners. For Benjamin Franklin, Aire Serv of Cedar Park and Ram Jack Austin, the local legal entity or owner still needs stronger documentation. [S029][S033][S034][S035][S129]

The largest owner-type bucket is the 32 brands coded to founder, family or local ownership. Some have unusually strong evidence. Efficient names George and Molly Drazic as owners. Baird says John and Melanie Baird have been sole owners since 1987. Bats identifies Brent Parks. Stride exposes both Stride Pest Control, LLC and owner Tyson Kearns. [S107][S134][S138][S152]

Other records are weaker. RoofCrafters, Anderson, Silver Creek, Bruecher, A-Tex, Pest Wranglers and Roberts currently describe themselves as family- or locally owned, but the public record captured here does not establish the exact current holders. They remain in the local bucket because the claim is current and directly made, but their evidence rating is C and the exact owner question remains open.

Eleven companies remain in the private/control-unresolved bucket. This is not a euphemism for independent. It means the operating brand is current, while the controlling owner was not established to publication standard. The unresolved group includes Austin Major Air & Heat, Kidd Roofing, Wilson Roofing, Austin Roofing and Construction, Olshan, CenTex, Douglas, Advanced Foundation Repair, Hawx, Ranger and EcoShield.

The distinction prevents a common research error: treating silence as evidence. A company is not independent simply because no acquisition release appears in search results. Small-business sales can be private, old transaction pages can disappear, and the brand site may never disclose a parent.

## HVAC, plumbing and bundled electrical

This is the most visibly consolidated portion of the dataset. It contains 26 active brands, including broad multi-trade operators, plumbing specialists, HVAC specialists, national branches and local franchises.

### Southern Home Services and Gryphon

Fox, Precision and Daniel’s are the clearest retained-brand cluster. Southern’s own transaction and current brand pages establish the immediate parent. Gryphon’s current portfolio material and the 2021 majority-investment announcement establish the sponsor chain. The evidence is stronger than a shared address, common website software or similar phone routing because it directly states the acquisitions and current holding relationship. [S001][S002][S003][S004][S005][S006][S007]

Daniel’s carries an extra flag. Southern maintains a current Daniel’s page and site-map listing, but consumer routing suggests some operational consolidation. The ownership chain is not in doubt. The question is whether Daniel’s should remain a fully separate active consumer brand. It stays in the 67-brand denominator because the parent currently publishes it as an Austin brand, with the conflict exposed rather than silently resolved.

### Radiant, Stan’s, Abacus and Goettl

Radiant’s current customer terms name **Radiant Plumbing Service, LLC** as the entity doing business as Radiant Plumbing & Air Conditioning. Current T3 and Riverside materials place the operation within T3 Services Group and Riverside’s portfolio. The public materials do not state an exact ownership percentage, so the database uses “portfolio company of” rather than “majority owned by.” [S008][S009][S010]

Stan’s changed sponsors. Treaty Oak was a former owner. The Master Trades Group completed its acquisition of Stan’s Home Services in March 2024. L Catterton acquired LTP Home Services Group, now Master Trades Group, in 2022 and still lists the platform as a current investment. The current chain is therefore Stan’s → Master Trades Group → L Catterton. Treaty Oak belongs in the transaction history, not on the current-owner card. [S011][S012][S013][S014]

Abacus provides one of the cleanest direct parent disclosures in the market. Its current privacy policy says the company is a wholly owned subsidiary of Wrench Group, LLC. Wrench’s 2022 recapitalization states that Leonard Green and management retained a majority interest while TSG Consumer Partners and Oak Hill made significant minority investments. The database keeps all three capital relationships instead of flattening Wrench into a generic “PE-owned” label. [S015][S016][S017]

Goettl serves Austin under the Goettl name after the Dayton Services rebrand. Cortec invested in the platform in 2021. Dayton appears in the historical table, not as a second current operator. [S018][S019]

### Service Experts, Service Wizard and ARS

Strand Brothers is an Austin Service Experts center. Brookfield Infrastructure completed its acquisition of Enercare, including Service Experts, in 2018 and continues to report the business. Because Brookfield Infrastructure is a public infrastructure owner, this database codes Strand as public-company owned rather than placing it in the private-equity bucket. [S020][S021][S022]

Champions Group acquired Service Wizard in 2022. Blackstone announced an agreement to acquire Champions on February 17, 2026 and said closing was expected in the first half of 2026. A closing announcement was not found before the July 26 snapshot. The correct current card is therefore Service Wizard → Champions Group; ultimate sponsor pending/unresolved. It is not published as a completed Blackstone ownership chain. [S023][S024][S025]

ARS/Rescue Rooter’s Austin branch belongs to American Residential Services. GI Partners acquired a majority interest in 2020, with Charlesbank and management retaining significant stakes. Sale exploration or auction reporting does not change that chain without a closed transaction. [S026][S027][S028]

### The SAS/Storr cluster

SAS Service Partners is the most consequential gap found during the audit. It launched around Austin Air Conditioning, added Cool Atmosphere and acquired Roger’s Plumbing. The platform says it is backed by Storr Group. Austin Air and Roger’s remain current consumer brands. Cool Atmosphere does not remain a separate active count because the present public path combines it into Austin Air Conditioning. [S037][S038][S039][S040][S041][S042][S043][S044]

This cluster also shows why “locally operated” is not the same as “locally owned.” Austin Air can retain local leadership, an Austin office and a familiar name while the equity chain runs through SAS and Storr. Those statements can all be true at once.

### Current local operators and unresolved companies

The same category still contains substantial local ownership. ABC remains tied to Bobby Jenkins and the Jenkins family. Efficient identifies George and Molly Drazic. Reliant traces its ownership to Max Hicks and family. Excalibur’s public trail links the brand to Excalibur Plumbing, LLC and Blake Smith. Whitestone and Crow’s have named-owner records. [S100][S107][S108][S110][S111][S112][S113][S114][S115]

McCullough and Christianson make current local/family claims, but the exact equity holders are not public in the sources reviewed. AirFix’s legal entity is visible, while its controller is not. Austin Major Air & Heat appears tied to Adoni Enterprises, Inc., but the current owner remains unresolved. These differences are preserved in the data rather than compressed into an “independent” category.

## Roofing and exterior services

The roofing universe contains nine active brands. The original census identified Kidd, Hall, RoofCrafters and Longhorn. The audit added Ja-Mar, Anderson, Silver Creek, Wilson, and Austin Roofing and Construction after finding current Austin-area operating evidence.

Ja-Mar is the clearest platform-owned roofing case. Dunes Point Capital states that Roofing Services Solutions acquired Ja-Mar on April 8, 2025, and Dunes Point still lists the platform. Ja-Mar’s current site remains active and uses local-company or local-owner wording. The transaction evidence controls the equity classification. The local wording is coded as operating or management language unless Ja-Mar documents a different post-transaction ownership arrangement. [S045][S046][S047]

Hall and Longhorn have named local-owner trails. RoofCrafters has a current corporate identity and family/local language, but exact shareholders are unresolved. Anderson and Silver Creek make current family/local claims without exposing the holders. Kidd’s D.R. Kidd Company, Inc. identity is supported, but the current controller is not. Wilson and Austin Roofing and Construction are active operators with insufficient public control evidence. [S118][S119][S120][S121][S122][S123][S124][S125][S126][S127]

No roofing brand is ranked by size. Office presence, years in business, reviews and website visibility are not comparable revenue measures. A company with more reviews may have stronger review acquisition, older listings, broader consumer volume or simply a different request strategy. None of those establishes market share.

## Foundation repair

Foundation repair has 12 active brands and the highest share of unresolved control questions in the dataset. The category mixes national platforms, franchises, long-running local operators and companies whose current legal owners are hard to see.

Groundworks is the clearest sponsor-backed chain. It serves Austin from its San Antonio-area operation. KKR made the controlling investment in March 2023. Cortec’s current investment history says it exited majority control and retained minority positions. Foundation Support Specialists, acquired by Groundworks in July 2022, is retained as a historical record rather than counted as a second current brand. [S048][S049][S050][S051]

Ram Jack Austin is a franchise. Its public page says franchises are independently owned and operated, but the Austin franchisee’s legal identity is unresolved. The database therefore does not say that the franchisor owns the local operating company. [S129]

Baird, G.L. Hunt, All in One, Bats and Quality have stronger local-owner evidence. Baird currently names John and Melanie Baird as sole owners. G.L. Hunt identifies the Hunt family. All in One has an owner trail to Robert J. Knight. Bats identifies Brent Parks. Quality Foundation Repair, which Model A excluded as a generic-looking site, has a current Austin operating trail and named founder Simon Wallace. The exclusion was reversed. [S134][S135][S136][S137][S138][S139][S140][S141]

Olshan, CenTex, Douglas and Advanced remain unresolved at the controller level. Advanced’s legal identity as Advanced Foundation Repair, LP is supportable, but the general partner and ultimate owner are not. Olshan’s current Austin service is clear; its ultimate control is not. No family or PE label is assigned to either company without better records. [S128][S130][S131][S132][S133]

## Pest control

Pest control contains 20 active brands in addition to ABC’s cross-category record. The ownership structures range from public-company branches to sponsor-backed operators, a minority-invested founder-controlled company, and local family businesses.

Orkin and HomeTeam lead to Rollins, Inc. Rollins completed the HomeTeam acquisition in 2008 and still lists both brands. Terminix leads to Rentokil Initial, which completed the acquisition in October 2022. These public-company chains are more straightforward than many private-platform chains because the parent relationship remains visible in current corporate materials. [S055][S056][S057][S145][S153][S154]

Aptive is sponsor-backed. Citation Capital acquired a majority stake in August 2024, while management retained a significant interest. Alta requires different language. Trivest’s announcement says its investment was minority and non-control and that Alta’s founders retained operational and financial control. Alta is therefore not counted among the 14 sponsor-controlled brands. [S052][S053][S054][S149]

Bulwark, Berrett, Romney, Stride, Massey, Natran, X Out and Absolute have current named-family or named-owner evidence. Pest Wranglers and A-Tex make current local claims but do not expose the exact holders. ClearDefense is founder-led, though the current allocation among founders is not public. Roberts makes a current family-owned claim. [S143][S146][S147][S148][S150][S151][S152][S159][S160][S161][S162][S163][S164][S165][S166]

Three pest records remain materially unresolved. Hawx was acquired by PCM Growth in 2021, but a sufficiently current direct source confirming sponsor continuity was not found. Ranger’s operating company is current, while public references conflict on the individual controller. EcoShield has a current Austin branch, but Massey’s 2015 acquisition of an EcoShield Austin division cannot be assumed to describe the current EcoShield-branded operation. Those cases are published as unresolved, not guessed. [S058][S059][S155][S156][S157][S158]

Texas pest-control licensing should make this category more resolvable than the current dataset suggests. The Texas Department of Agriculture regulates structural pest-control businesses. A systematic business-license export should be the next evidence pull for A-Tex, Pest Wranglers, Ranger, EcoShield and other branches. [S060]

## What “local” actually means

“Local” is not one ownership status. The database separates six common meanings.

**Locally owned** means the current equity owner is local or the company makes a current local-ownership claim. Efficient, Baird and Stride have named-owner support. Silver Creek and Pest Wranglers have current local claims but unresolved holders. Those records do not receive the same evidence rating.

**Locally managed** means local leadership runs the operation, regardless of who owns the equity. An acquired brand can remain locally managed. A local president or branch manager is not proof of ownership.

**Locally operated** describes where the staff, office or service territory sit. Austin Air’s local operation can coexist with SAS/Storr ownership. A national branch can also be locally operated without being locally owned.

**Family founded** is historical. A founder can remain in the business after a sale, roll equity, or leave. Austin Air’s Henderson-family history and Cool Atmosphere’s founder participation do not erase the SAS transaction. [S037][S039][S044]

**Founder led** concerns management. ClearDefense’s founders are identifiable, but the current equity allocation is not. The database therefore uses “founder led” rather than inventing a percentage.

**Franchise owned** means a local business owns or operates a territory under a franchised brand. Mr. Rooter Austin is locally owned by Brett Bidwell while the Mr. Rooter system belongs to Neighborly and Neighborly belongs to KKR. Benjamin Franklin’s franchisor belongs to an Apax-majority, BCI-minority structure, while the Austin franchisee remains unresolved. [S029][S030][S031][S032][S033]

**Private-equity backed** is also too broad unless the interest is stated. Gryphon’s Southern investment is majority. Leonard Green and management retain majority ownership of Wrench while TSG and Oak Hill hold significant minority interests. Trivest is a non-control minority investor in Alta. KKR owns Neighborly, but not the local Mr. Rooter operating company. The graph keeps those distinctions visible.

A company can reasonably use historical or operational local language after a transaction. The publication does not accuse any brand of deception. It asks a narrower factual question: what exactly does the wording describe—history, management, location, franchise ownership, or current equity?

## Selected ownership cards

The database includes a mobile card for every active brand. These are representative examples of the wording used when the chain is clear, partial or unresolved.

### Fox Service Company

**Current chain:** Fox Service Company → Southern Home Services → North American Essential Home Services → Gryphon Investors. **Interest:** Gryphon majority; management retained a meaningful stake at the holding-company level. **Status:** current. [S002][S005][S006][S007]

### Radiant Plumbing, Air Conditioning & Electrical

**Current chain:** Radiant brand → Radiant Plumbing Service, LLC → T3 Services Group → The Riverside Company. **Interest:** public materials establish the portfolio relationship but do not state the percentage. **Status:** current. [S008][S009][S010]

### Stan’s Heating, Air, Plumbing & Electrical

**Current chain:** Stan’s → Stan’s Home Services Holdings lineage → The Master Trades Group → L Catterton. **Former sponsor:** Treaty Oak Equity, which exited in March 2024. **Status:** current under Master Trades Group. [S011][S012][S013][S014]

### Abacus Plumbing, Air Conditioning & Electrical

**Current chain:** Abacus → Wrench Group. **Capital structure:** Leonard Green and management retain majority ownership; TSG Consumer Partners and Oak Hill hold significant minority interests. **Status:** current. [S015][S016][S017]

### Service Wizard Heating & Air Conditioning

**Current chain:** Service Wizard → Champions Group Holdings. **Ultimate sponsor:** unresolved at the snapshot. Odyssey is the last closed sponsor in the record; Blackstone announced an acquisition agreement, but closing was not established. [S023][S024][S025]

### Austin Air Conditioning

**Current chain:** Austin Air Conditioning → SAS Service Partners → Storr Group. **Seller participation:** SAS states that the seller rolled substantial equity. **Local wording:** the brand may be locally operated without being independently locally owned. [S037][S040][S041][S044]

### Ja-Mar Roofing & Sheet Metal

**Current chain:** Ja-Mar → Roofing Services Solutions → Dunes Point Capital. **Transaction date:** April 8, 2025. **Local wording:** current local-company language is not treated as proof that local holders retained control. [S045][S046][S047]

### Groundworks

**Current chain:** Groundworks → KKR. **Minority investor:** Cortec retained minority positions after exiting majority control in March 2023. **Austin footprint:** service-area presence from the San Antonio-area operation. [S048][S049][S050]

### Aptive Environmental

**Current chain:** Aptive → Citation Capital. **Interest:** Citation acquired a majority stake in August 2024; management retained a significant interest. **Austin footprint:** current North Lamar branch page. [S052][S053]

### Alta Pest Control

**Current chain:** founders and management retain control. **Outside capital:** Trivest holds a non-control minority investment. **Classification:** minority-invested, founder-controlled, not sponsor-controlled. [S054][S149]

### Mr. Rooter Plumbing of Austin

**Current chain:** Austin franchisee owned by Brett Bidwell → franchise of Neighborly. **Franchisor owner:** KKR. **Boundary:** KKR’s ownership stops at Neighborly unless separate evidence shows direct ownership of the Austin franchisee. [S029][S030]

### Terminix

**Current chain:** Terminix → Rentokil Initial plc through Rentokil North America. **Transaction:** Rentokil completed the acquisition on October 12, 2022. **Austin footprint:** current branch page. [S057][S154]

### Baird Foundation Repair

**Current chain:** Baird → John and Melanie Baird. **Interest:** the current company says they have been sole owners since 1987. **Status:** current family ownership with A-rated evidence. [S134]

## How ownership was verified

The research used a current-owner test. A transaction announcement establishes that a deal was announced or closed at a point in time. It does not, by itself, establish the owner on July 26, 2026. A current chain normally required both a transaction or legal source and a current portfolio, parent, brand, terms or corporate source.

Evidence priority ran in this order: current legal terms and regulatory records; current parent or sponsor portfolio pages; completed transaction announcements; current official brand and location pages; state or trade-license records; BBB and trade-association identity records; reputable secondary reporting; and lead-only sources. Syndicated copies of the same press release count as one independence group.

Evidence ratings are simple:

- **A:** current direct primary evidence, usually with a second current or transaction source.
- **B:** strong current evidence with a missing intermediate entity, percentage or second independent source.
- **C:** current self-report, credible identity lead or stale relationship that needs another record.
- **D:** unresolved, conflicting or lead-only evidence. The brand may still be included as a real operator, but its controller is not published as settled.

Austin presence required a current official branch, office, franchise territory or service-area page. A dispatch-based company can qualify, but the presence type is labeled. A city landing page alone was not enough when the site looked generic or could not be tied to an operating identity.

The original Model A report was useful for discovery but its eight named structured files were not present in the uploaded DOCX. Model B stated that it had not received those files. The master data therefore had to be rebuilt rather than merged. Several Model B citations were rejected, including a Fox careers page used for Precision and a Fox News URL used for Daniel’s. The corrected dataset links those relationships to Southern and Gryphon primary evidence.

## What the data cannot establish

This is an ownership and observable-footprint database. It is not a revenue census.

The 20.9% sponsor-backed figure means 14 of 67 consumer-brand records in this reconstructed universe sit in sponsor-backed operating platforms. It does not mean private equity has 20.9% of Austin home-service revenue, jobs, customers, permits, trucks, calls or search demand. A platform can own several brands; one brand can operate several locations; a small specialist and a large multi-trade company each count once.

Permit counts would have their own limits. The permit applicant may be a builder, subcontractor, employee, affiliate or old entity name. License files identify regulated businesses but do not measure sales. Review totals are platform-dependent and vulnerable to listing age, mergers and solicitation practices. Search visibility measures demand capture, not completed work. Locations can be offices, warehouses, call centers, franchise territories or dispatch points.

The census is also incomplete at the small-operator tail. Hutto, Manor, Bee Cave, Dripping Springs, Buda, Kyle, Georgetown and Leander likely contain additional licensed or low-visibility operators. The dataset is described as a reconstructed publication universe, not a complete count of every eligible contractor.

The data cannot show that ownership caused a change in pricing, service quality, employment or customer outcomes. That would require before-and-after operating data, a valid comparison group and controls for inflation, labor, materials, weather, demand and business mix. No such causal claim is made here.

## Corrections and updates

Companies, owners, investors, reporters and readers can submit a correction with the affected brand, the disputed field, the proposed replacement, the effective date and direct supporting evidence. Useful evidence includes current legal terms, state filings, license records, closing announcements, sponsor portfolio pages, signed company statements and current franchisee documents.

A submission will not overwrite the public record silently. Accepted changes will update the relevant CSV and JSON rows, preserve the prior value, cite the new evidence and appear in the changelog with an effective date. Disputed records remain visibly unresolved until the evidence supports a conclusion.

The full data package includes the brand, entity, relationship, transaction, evidence, footprint, conflict and unresolved tables; a JSON graph; the methodology; and a reproducible changelog. The point is not to make the map look complete. It is to make every published chain inspectable.
"""

article_word_count = len(re.findall(r"\b[\w’'-]+\b", article))
if not 4000 <= article_word_count <= 6000:
    raise ValueError(f'Article word count {article_word_count} outside 4,000-6,000 target')
article_linked = re.sub(r'\[(S\d{3})\]', lambda m: f"[{m.group(1)}]({source_by_id[m.group(1)]['url']})" if m.group(1) in source_by_id else m.group(0), article)
(OUT / 'article.md').write_text(article_linked + f"\n\n<!-- Article word count: {article_word_count} -->\n", encoding='utf-8')

methodology = f"""# Methodology

## Purpose and snapshot

This database maps ownership relationships behind consumer-facing residential home-service brands that advertised or documented current service in the Austin area on **{SNAPSHOT_DATE}**. It covers HVAC, plumbing, residential electrical when bundled with HVAC or plumbing, roofing and exterior services, foundation repair, and structural pest control.

The published denominator is **{headline_denominator} active Austin-facing brands**. It is a reconstructed publication universe, not a claim that every eligible contractor in the Austin metropolitan area has been found.

## Unit of analysis

The primary counting unit is the **consumer-facing brand**, not the legal entity, office, license, location, sponsor or website. Separate tables represent:

- Brand
- Legal entity
- DBA
- Location or service footprint
- Local franchisee
- Franchise system
- Platform
- Holding company
- Sponsor
- Public parent
- Founder or family owner

A brand can map to several entities. Several brands can map to one platform. A franchise system is not treated as the direct owner of a local franchisee unless direct ownership is independently documented.

## Geographic inclusion

A brand qualifies when a current official source documents an Austin-area office, branch, franchise territory or service area. The working geography includes Austin, Round Rock, Pflugerville, Cedar Park, Leander, Georgetown, Hutto, Manor, Lakeway, Bee Cave, Dripping Springs, Buda, Kyle and other localities a company expressly includes in its Austin or Greater Austin territory.

Presence types are labeled:

- Office or branch
- Headquarters or local base
- Franchise territory
- Service-area / dispatch presence
- Current brand page without a separately verified location

A generic city page was not sufficient when it could not be tied to a real operating identity.

## Census reconstruction

Model A named eight structured deliverables, but those files were not embedded in its DOCX or separately uploaded. Model B stated that it did not receive Model A’s files. The final database was therefore reconstructed from the two narrative reports, their cited leads, direct source review and additional gap searches. [I001][I002]

The reconstruction added or restored multiple current operators, including the SAS Service Partners/Storr cluster, Ja-Mar, Quality Foundation Repair and several local plumbing, roofing, foundation and pest companies. Historical or absorbed brands remain in `master_brands.csv` with a non-denominator status.

## Current-owner test

An old acquisition announcement does not automatically establish current ownership. A current relationship normally requires:

1. Direct evidence that the transaction closed or the relationship existed; and
2. Current evidence that the parent, sponsor, platform or brand relationship remained in force at the snapshot.

Current evidence can include a sponsor portfolio page, parent brand list, privacy policy, terms, annual report, current company page or regulatory record.

Pending agreements are not promoted to current ownership. The Blackstone-Champions agreement is recorded as pending because no closing confirmation was located before the snapshot. Former sponsors are kept in the transaction table and removed from current chains.

## Source hierarchy

1. Current legal terms, privacy policies, state filings and regulatory/license records
2. Current parent, sponsor, platform and public-company disclosures
3. Completed transaction announcements from buyer, seller, target or adviser
4. Current official brand, branch and service-area pages
5. BBB, trade-association and certification identity records
6. Reputable secondary reporting
7. Social, job, directory and search-result leads

Lead-only sources can generate an unresolved question. They do not establish ownership.

## Source independence

Two URLs do not equal two independent sources when both reproduce the same release. Each source has an `independence_group`. Syndicated press releases, portfolio excerpts copied from the target, and search snippets from the same underlying page are treated as one evidence family.

For major platform chains, the preferred pattern is one transaction or legal source plus one current parent/portfolio source. Some local owner records have only a current first-party statement plus a BBB or trade record. Those receive a lower rating when exact equity remains unavailable.

## Evidence ratings

**A — publication grade.** Direct current primary evidence, generally corroborated by a transaction, legal, parent or independent identity source.

**B — strongly supported.** The current structure is persuasive, but an intermediate legal entity, exact percentage, exact date or second independent record is missing.

**C — qualified.** Current self-report, credible identity lead, founder history or provisional relationship. The claim is published with explicit qualification.

**D — unresolved.** Evidence conflicts, is stale, or establishes only the operating brand. No controller conclusion is forced.

## Ownership-interest coding

The database distinguishes:

- Majority ownership
- Minority investment
- Non-control minority investment
- Significant minority investment
- Control percentage unspecified
- Franchise relationship
- Local owner / family control claim
- Current controller unresolved

A company is not labeled “owned by” an investor when the source says only that the investor made a minority investment. Alta is the main example: Trivest is a non-control minority investor and founders retained control. [S054]

## Franchise treatment

Three separate relationships may exist:

1. Brand to local franchisee: `Operated by`
2. Brand to franchise system: `Franchise of`
3. Franchise system to sponsor/public parent: ownership relationship

The third relationship is not applied to the local franchisee. This prevents KKR’s ownership of Neighborly from being misreported as direct ownership of Mr. Rooter Austin or Aire Serv local operators.

## “Local” coding

The following terms are not interchangeable:

- Locally owned: current equity claim
- Locally managed: local leadership
- Locally operated: local staff, office or territory
- Family founded: historical origin
- Founder led: current management role
- Retained local brand: consumer name survives a transaction
- Franchise owned: local operator owns a franchised business

Local/family claims are stored as claims with ratings. A transaction source can override an equity implication while leaving local management or history intact.

## Calculations

Every percentage uses the {headline_denominator}-brand active publication denominator unless otherwise stated. Unresolved records remain in the denominator and are reported separately. Historical, candidate and excluded records are not included.

The metrics are brand-record shares. They are never called market share. No revenue or size ranking is produced without a comparable measure across the universe.

## Graph construction

The default graph includes current brand-to-parent chains. Historical edges, minority investors and intermediate legal entities are optional layers. Every edge contains:

- Start date or explicit `unknown`
- End date when applicable
- Current-status flag
- Relationship status
- Interest type
- Evidence rating
- Source IDs
- Access date
- Evidence note

## Known limitations

- The small suburban and low-web-visibility tail is incomplete.
- Texas legal-entity and assumed-name records were not systematically exported for every brand.
- Pest and plumbing licenses can materially improve identity resolution; roofing lacks the same statewide licensing hook.
- Current owner pages may omit minority investors or intermediate entities.
- Private transactions may not be announced.
- A current service page does not prove a physical local office.
- Ownership does not establish revenue, service quality, pricing or market share.

## Reproduction

A reader can reproduce the central findings by:

1. Filtering `master_brands.csv` to `inclusion_status=published_active`.
2. Counting `current_owner_type` for the denominator and owner buckets.
3. Joining `master_relationships.csv` to `master_entities.csv` on entity IDs.
4. Opening the source IDs in `master_evidence.csv`.
5. Checking `master_conflicts.csv` and `master_unresolved.csv` before treating a chain as settled.
6. Rebuilding the public graph from `graph.json`.
"""
(OUT / 'methodology.md').write_text(methodology, encoding='utf-8')

research_audit = f"""# Research Audit Memo

## Decision

The two research reports were not merged as delivered. They were treated as discovery and ownership-lead documents. The final dataset was rebuilt because the evidence package failed basic reconciliation and provenance tests.

## Input audit

### Model A

Model A identified a useful initial brand universe and openly described weaknesses in suburban roofing, foundation repair and the small-operator tail. It also separated included brands, aliases, legal-identity leads, candidate relationships and exclusions in principle.

The central provenance failure is that the eight named structured deliverables were not present. The DOCX contains hyperlinks to paths that do not exist in the uploaded environment. There was no `brands.csv`, alias table, search log or excluded-candidate file to inspect. The original row-level search history and deduplication decisions therefore could not be reproduced. [I001]

### Model B

Model B explicitly states that Model A’s files were unavailable. Its report is an independent top-down pass, not the promised cross-model adjudication. [I002]

Several citations failed claim matching. The Precision row cited a Fox careers page. The Daniel’s row cited FoxNews.com. The Radiant chain used a transaction database where current direct sources were available. Benjamin Franklin’s local-franchisee treatment leaned on HomeAdvisor. Those citations were rejected or replaced.

## Census corrections

The audit retained Model A’s strongest current operators and added brands that had clear current Austin evidence. Material additions include:

- Austin Air Conditioning and Roger’s Plumbing within SAS Service Partners / Storr Group
- Ja-Mar within Roofing Services Solutions / Dunes Point Capital
- ARS/Rescue Rooter Austin
- Mr. Rooter and Benjamin Franklin local franchise records
- Anderson, Silver Creek, Wilson and Austin Roofing and Construction
- Bats and Bruecher Foundation
- Orkin, Terminix, Hawx, Ranger, EcoShield, Massey, Natran, X Out, ClearDefense, Roberts and Absolute

Quality Foundation Repair was moved from exclusion to inclusion after current official, BBB and named-founder evidence was found. Cool Atmosphere was moved in the opposite direction: it remains in the history but not the active denominator because it is now combined into Austin Air Conditioning.

## Ownership corrections

- Southern/Gryphon: Fox, Precision and Daniel’s have direct current and transaction support.
- Stan’s: Treaty Oak is historical; current chain runs through Master Trades Group to L Catterton.
- Abacus: Wrench is the direct parent; Leonard Green and management retain majority, with TSG and Oak Hill significant minorities.
- Service Wizard: Champions is current; Blackstone is pending unless a closing source emerges.
- Groundworks: KKR is controlling/majority; Cortec retained minority positions.
- Alta: Trivest is non-control minority; founders retained control.
- Franchises: KKR/Neighborly and Apax/Authority Brands are franchisor-level chains, not direct local operating-company ownership.
- Ja-Mar: Dunes Point’s acquisition evidence controls the equity classification despite current local wording.

## Accepted evidence patterns

The strongest chains combine a transaction or legal source with a current parent/portfolio source. Examples include Southern/Gryphon, Stan’s/L Catterton, Abacus/Wrench, Service Experts/Brookfield, Groundworks/KKR-Cortec, Aptive/Citation, HomeTeam/Rollins and Terminix/Rentokil.

Named local-owner records are accepted when current company materials and an identity source agree. Examples include Efficient, Excalibur, Whitestone, Crow’s, Baird, Bats, Stride and X Out.

## Rejected inference patterns

The build rejects:

- Ownership inferred only from shared addresses, phone numbers or website templates
- Independence inferred from the absence of acquisition news
- Franchisor ownership presented as local franchisee ownership
- Minority investment presented as total ownership
- Old acquisition announcements used without a current-owner check
- “Local,” “family,” or “founder” wording treated as a single legal status
- Review, permit or search percentages described as market share
- Claims that ownership caused price, service or employment changes without causal evidence

## Final data quality

The active publication universe contains {headline_denominator} brands. {current_chain_high_conf} records have A/B ownership structures and are not coded unresolved. {unresolved_owner_count} remain in the private/control-unresolved bucket. The graph contains {len(entities)} nodes and {len(relationships)} relationships. The evidence ledger contains {len(sources)} source records. There are {len(conflicts)} preserved conflicts and {len(unresolved)} unresolved questions.

The package is defensible as a dated ownership map. It is not defensible as a complete licensed-contractor census, a revenue market-share study or a legal opinion on beneficial ownership.
"""
(OUT / 'research_audit_memo.md').write_text(research_audit, encoding='utf-8')

verified_findings_md = f"""# Verified Findings and Calculations

**Denominator:** {headline_denominator} active Austin-facing consumer-brand records as of {SNAPSHOT_DATE}.

| Owner type | Brands | Share of 67-brand universe |
|---|---:|---:|
""" + '\n'.join(f"| {k} | {v} | {v/headline_denominator*100:.1f}% |" for k,v in owner_type_counts.items()) + f"""

## Additional findings

- A/B and not unresolved: **{current_chain_high_conf} of {headline_denominator} ({pct(current_chain_high_conf)})**.
- Retained consumer names after a transaction: **{retained_count}**.
- Local franchise records: **{franchise_count}**.
- Private/control-unresolved records: **{unresolved_owner_count}**.
- Current or historical transaction records: **{len(transactions)}**.
- Preserved conflicts: **{len(conflicts)}**.
- Open research questions: **{len(unresolved)}**.

## Sector counts

| Sector | Brands | Share of 67-brand universe |
|---|---:|---:|
""" + '\n'.join(f"| {k} | {v} | {v/headline_denominator*100:.1f}% |" for k,v in sector_counts.items()) + """

## Current multi-brand clusters

- Southern Home Services / Gryphon: Fox, Precision, Daniel’s.
- SAS Service Partners / Storr Group: Austin Air Conditioning, Roger’s Plumbing. Cool Atmosphere is historical/absorbed.
- Neighborly franchisor / KKR: Mr. Rooter Austin, Aire Serv Cedar Park, Aire Serv Round Rock. These are associations through the franchisor, not KKR ownership of the local franchisees.
- Rollins: Orkin and HomeTeam.

## Interpretation rule

These percentages describe **brand records in the publication universe**. They are not market share, revenue share, customer share, job share, permit share, review share or search share.
"""
(OUT / 'verified_findings.md').write_text(verified_findings_md, encoding='utf-8')

rejected_md = """# Unresolved and Rejected Claims

## Claims rejected from publication

1. “Austin’s home-service market is X% private-equity owned.” The available denominator is brands, not revenue or companies.
2. “Brand A is independent because no acquisition announcement was found.” Absence of public news is not ownership evidence.
3. “KKR owns Mr. Rooter Austin.” KKR owns Neighborly; the local Austin franchisee is separately owned.
4. “Apax owns Benjamin Franklin Plumbing of Austin.” Apax owns the franchisor. The local franchisee remains unresolved.
5. “Trivest owns Alta Pest Control.” Trivest’s investment was explicitly non-control minority; founders retained control.
6. “Blackstone owns Service Wizard.” The Blackstone-Champions agreement was announced, but closing was not established by the snapshot.
7. “Massey owns the current EcoShield Austin branch.” Massey acquired an EcoShield Austin division in 2015; the current brand/operator chain is unresolved.
8. “Ja-Mar is locally owned” based only on current site language. Dunes Point’s platform acquisition is direct transaction evidence.
9. “The platform caused higher prices, lower service, layoffs or customer harm.” No causal analysis supports such a statement.
10. Company size rankings based on Google reviews, permits, locations or search visibility. Those measures are not comparable revenue data.

## High-priority unresolved cases

The highest-priority records are Service Wizard’s sponsor closing, Daniel’s current standalone brand status, the Benjamin Franklin and Ram Jack local franchisees, Olshan’s current controller, Advanced Foundation Repair’s general-partner chain, Hawx’s current sponsor, Ranger’s individual controller, EcoShield’s current Austin operator, and the exact legal entities behind several retained acquired brands.

See `master_unresolved.csv` for the full question, current treatment, evidence needed and priority.
"""
(OUT / 'unresolved_and_rejected_claims.md').write_text(rejected_md, encoding='utf-8')

changelog = f"""# Changelog

## Version 1.0 — {SNAPSHOT_DATE}

Initial reconstructed publication package.

### Research-provenance changes

- Recorded that Model A’s named structured files were not available.
- Recorded that Model B did not receive Model A’s files and therefore did not perform a true reconciliation.
- Replaced mismatched Precision and Daniel’s citations.

### Census changes

- Built a 67-brand active publication universe.
- Added the SAS Service Partners/Storr cluster.
- Added Ja-Mar and other current roofing operators.
- Reversed the exclusion of Quality Foundation Repair.
- Added current public-company and local pest-control branches.
- Moved Cool Atmosphere, Dayton Services and Foundation Support Specialists to historical/rebranded status.

### Ownership changes

- Separated current and former sponsors for Stan’s.
- Marked the Blackstone-Champions transaction pending/unresolved.
- Coded Alta as minority-invested and founder-controlled.
- Coded KKR/Neighborly and Apax/Authority Brands at the franchisor level only.
- Updated Groundworks to KKR control with Cortec minority retention.
- Added Ja-Mar → Roofing Services Solutions → Dunes Point Capital.

### Data-quality controls

- Added evidence IDs, access dates, independence groups and evidence notes.
- Required every relationship edge to contain an effective-date marker and source IDs.
- Added conflict and unresolved tables instead of forcing classifications.
- Labeled footprint measures as non-market-share data.

## Future entry template

### Version X.Y — YYYY-MM-DD

**Record affected:**  
**Field changed:**  
**Previous value:**  
**New value:**  
**Effective date:**  
**Reason:**  
**New source IDs:**  
**Submitted by:**  
**Review status:** accepted / rejected / unresolved  
**Reviewer note:**
"""
(OUT / 'changelog.md').write_text(changelog, encoding='utf-8')

# ---------------------------
# Graph files and interactive publication tools
# ---------------------------

# Add brand metadata to graph nodes.
brand_lookup_by_id = {b['brand_id']: b for b in brands}
graph_nodes = []
for e in entities:
    node = dict(e)
    b = brand_lookup_by_id.get(e['entity_id'])
    if b:
        node.update({
            'primary_category': b['primary_category'],
            'categories': b['categories'].split('|'),
            'owner_type': b['current_owner_type'],
            'inclusion_status': b['inclusion_status'],
            'evidence_rating': b['evidence_rating'],
            'ownership_status': b['ownership_verification_status'],
            'current_platform': b['current_platform_or_franchise_system'],
            'ultimate_owner': b['current_ultimate_owner_or_controller'],
        })
    graph_nodes.append(node)

mobile_chains = []
for b in published:
    chain = [b['brand_name']]
    if b['current_platform_or_franchise_system'] and b['current_platform_or_franchise_system'] != b['brand_name']:
        chain.append(b['current_platform_or_franchise_system'])
    if b['current_ultimate_owner_or_controller'] and b['current_ultimate_owner_or_controller'] not in chain:
        chain.append(b['current_ultimate_owner_or_controller'])
    if not b['current_ultimate_owner_or_controller']:
        chain.append('Current controller not separately identified')
    mobile_chains.append({
        'brand_id': b['brand_id'],
        'brand_name': b['brand_name'],
        'primary_category': b['primary_category'],
        'categories': b['categories'].split('|'),
        'owner_type': b['current_owner_type'],
        'chain': chain,
        'platform_or_franchise_system': b['current_platform_or_franchise_system'],
        'ultimate_owner_or_controller': b['current_ultimate_owner_or_controller'],
        'ownership_interest': b['ownership_interest'],
        'ownership_status': b['ownership_verification_status'],
        'evidence_rating': b['evidence_rating'],
        'local_claim_type': b['local_claim_type'],
        'franchise_flag': b['franchise_flag'],
        'retained_brand': b['retained_consumer_brand_after_transaction'],
        'source_ids': source_join(b['presence_source_ids'], b['ownership_source_ids']).split('|'),
        'notes': b['notes'],
    })

graph = {
    'metadata': {
        'title': 'Who Owns Austin’s Home-Service Companies?',
        'snapshot_date': SNAPSHOT_DATE,
        'active_brand_denominator': headline_denominator,
        'node_count': len(graph_nodes),
        'edge_count': len(relationships),
        'default_public_view': 'Current active brands, current parents, sponsor-backed owner type selected by default',
        'warning': 'Brand-record counts and footprint measures are not market share.',
        'edge_types': sorted(ALLOWED_EDGES),
        'evidence_ratings': {'A':'publication grade','B':'strongly supported','C':'qualified','D':'unresolved'},
    },
    'nodes': graph_nodes,
    'edges': relationships,
    'mobile_chains': mobile_chains,
    'views': {
        'default': {'inclusion_status':'published_active','current_edges_only':True,'owner_type':'Sponsor-backed platform','deep_legal_nodes':False},
        'category_filters': list(sector_counts.keys()),
        'owner_type_filters': list(owner_type_counts.keys()),
        'sponsor_platform_view': {'owner_types':['Sponsor-backed platform','Public-company owned','Minority-invested, founder-controlled'],'include_franchisor_associations':True},
        'transaction_timeline_file': 'master_transactions.csv',
    },
}
(OUT / 'graph.json').write_text(json.dumps(graph, indent=2, ensure_ascii=False), encoding='utf-8')


def sector_for_brand(b: dict) -> str:
    p = b['primary_category']
    if p in {'HVAC / plumbing / electrical','HVAC','HVAC / plumbing','Plumbing','HVAC / electrical / plumbing'}:
        return 'HVAC, plumbing and electrical'
    if p in {'Roofing / exterior','Roofing'}:
        return 'Roofing and exterior'
    return p

# Category-specific graph files include current relationships reachable from selected brand nodes.
def filtered_graph_for_sector(sector: str) -> dict:
    selected_brand_ids = {b['brand_id'] for b in published if sector_for_brand(b) == sector}
    included_nodes = set(selected_brand_ids)
    changed = True
    while changed:
        changed = False
        for r in relationships:
            if not r['current_status']:
                continue
            if r['from_entity_id'] in included_nodes and r['to_entity_id'] not in included_nodes:
                included_nodes.add(r['to_entity_id']); changed = True
    return {
        'metadata': {**graph['metadata'], 'filter': sector},
        'nodes': [n for n in graph_nodes if n['entity_id'] in included_nodes],
        'edges': [r for r in relationships if r['current_status'] and r['from_entity_id'] in included_nodes and r['to_entity_id'] in included_nodes],
        'mobile_chains': [c for c in mobile_chains if sector_for_brand(brand_lookup_by_id[c['brand_id']]) == sector],
    }

sector_files = {
    'HVAC, plumbing and electrical':'graph_hvac_plumbing_electrical.json',
    'Roofing and exterior':'graph_roofing_exterior.json',
    'Foundation repair':'graph_foundation_repair.json',
    'Pest control':'graph_pest_control.json',
}
for sector, filename in sector_files.items():
    (OUT / filename).write_text(json.dumps(filtered_graph_for_sector(sector), indent=2, ensure_ascii=False), encoding='utf-8')

sponsor_ids = {c['brand_id'] for c in mobile_chains if c['owner_type'] in {'Sponsor-backed platform','Public-company owned','Minority-invested, founder-controlled','Local franchise operator'}}
included_nodes = set(sponsor_ids)
changed = True
while changed:
    changed = False
    for r in relationships:
        if r['current_status'] and r['from_entity_id'] in included_nodes and r['to_entity_id'] not in included_nodes:
            included_nodes.add(r['to_entity_id']); changed = True
sponsor_graph = {
    'metadata': {**graph['metadata'], 'filter':'sponsor/platform/public/franchise view'},
    'nodes': [n for n in graph_nodes if n['entity_id'] in included_nodes],
    'edges': [r for r in relationships if r['current_status'] and r['from_entity_id'] in included_nodes and r['to_entity_id'] in included_nodes],
    'mobile_chains': [c for c in mobile_chains if c['brand_id'] in sponsor_ids],
}
(OUT / 'graph_sponsor_platform_view.json').write_text(json.dumps(sponsor_graph, indent=2, ensure_ascii=False), encoding='utf-8')

# Self-contained interactive graph HTML.
graph_data_js = json.dumps({'chains': mobile_chains, 'relationships': relationships, 'transactions': transactions}, ensure_ascii=False)
ownership_graph_html = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Who Owns Austin’s Home-Service Companies? — Ownership Graph</title>
<style>
:root{--ink:#111;--muted:#666;--paper:#f7f7f3;--card:#fff;--line:#c9c9c2;--accent:#243a2a;--warn:#79502b;--danger:#713b35}
*{box-sizing:border-box} body{margin:0;font:15px/1.45 system-ui,-apple-system,Segoe UI,Arial,sans-serif;color:var(--ink);background:var(--paper)}
header{padding:28px clamp(18px,4vw,56px) 18px;border-bottom:1px solid var(--line);background:#fff} h1{font-size:clamp(26px,4vw,46px);line-height:1.05;margin:0 0 10px;max-width:1050px} .deck{max-width:900px;color:var(--muted);margin:0}
.controls{position:sticky;top:0;z-index:5;display:flex;gap:10px;flex-wrap:wrap;padding:12px clamp(18px,4vw,56px);background:rgba(247,247,243,.96);border-bottom:1px solid var(--line);backdrop-filter:blur(8px)}
label{font-size:12px;color:var(--muted);display:flex;flex-direction:column;gap:3px} input,select,button{font:inherit;padding:8px 10px;border:1px solid var(--line);border-radius:6px;background:#fff;color:var(--ink)} button{cursor:pointer}.stat{margin-left:auto;align-self:end;color:var(--muted);padding:8px 0}
main{padding:20px clamp(18px,4vw,56px) 60px}.note{max-width:950px;color:var(--muted);margin:0 0 16px}.graph{display:grid;gap:10px}.row{display:grid;grid-template-columns:minmax(210px,1.1fr) 38px minmax(190px,1fr) 38px minmax(230px,1.2fr);align-items:stretch}.node{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:12px;min-height:78px}.node strong{display:block}.meta{font-size:12px;color:var(--muted);margin-top:5px}.arrow{display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:22px}.rating{display:inline-block;padding:1px 6px;border:1px solid var(--line);border-radius:999px;font-size:11px;margin-left:5px}.unresolved{border-left:4px solid var(--danger)}.pending{border-left:4px solid var(--warn)}
.details{display:none;grid-column:1/-1;background:#fff;border:1px dashed var(--line);border-radius:8px;padding:12px;margin-top:-4px}.row.open .details{display:block}.source{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11px}.empty{padding:30px;border:1px dashed var(--line);background:#fff}
@media(max-width:760px){.row{grid-template-columns:1fr}.arrow{transform:rotate(90deg);height:24px}.stat{width:100%;margin:0}.controls{position:static}.node{min-height:0}}
</style></head><body>
<header><h1>Who Owns Austin’s Home-Service Companies?</h1><p class="deck">Current consumer brands, operating platforms, public parents, sponsors and local franchise boundaries. Snapshot: July 26, 2026. The default opens to sponsor-backed brands.</p></header>
<div class="controls">
<label>Search<input id="q" placeholder="Brand, platform or owner"></label>
<label>Sector<select id="sector"><option value="">All sectors</option><option>HVAC, plumbing and electrical</option><option>Roofing and exterior</option><option>Foundation repair</option><option>Pest control</option></select></label>
<label>Owner type<select id="owner"><option value="">All owner types</option></select></label>
<label>Evidence<select id="rating"><option value="">All ratings</option><option>A</option><option>B</option><option>C</option><option>D</option></select></label>
<label><span>View</span><select id="view"><option value="chains">Current chains</option><option value="unresolved">Unresolved only</option><option value="retained">Retained brands</option><option value="franchise">Franchises</option></select></label>
<button id="reset">Reset</button><div id="stat" class="stat"></div>
</div>
<main><p class="note">Each row is a readable ownership chain rather than a force-directed hairball. Open a row for interest type, status, evidence and source IDs. “Franchise of” does not mean the franchisor owns the local operating company.</p><div id="graph" class="graph"></div></main>
<script>
const DATA=__DATA__;
const chains=DATA.chains;
const ownerTypes=[...new Set(chains.map(x=>x.owner_type))].sort();
const ownerSel=document.querySelector('#owner'); ownerTypes.forEach(x=>{const o=document.createElement('option');o.textContent=x;ownerSel.appendChild(o)}); ownerSel.value='Sponsor-backed platform';
function sector(c){const p=c.primary_category; if(['HVAC / plumbing / electrical','HVAC','HVAC / plumbing','Plumbing','HVAC / electrical / plumbing'].includes(p))return 'HVAC, plumbing and electrical'; if(['Roofing / exterior','Roofing'].includes(p))return 'Roofing and exterior'; return p}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function render(){const q=document.querySelector('#q').value.toLowerCase().trim(), sec=document.querySelector('#sector').value, own=ownerSel.value, rating=document.querySelector('#rating').value, view=document.querySelector('#view').value;
let rows=chains.filter(c=>(!q||JSON.stringify(c).toLowerCase().includes(q))&&(!sec||sector(c)===sec)&&(!own||c.owner_type===own)&&(!rating||c.evidence_rating===rating));
if(view==='unresolved')rows=rows.filter(c=>/unresolved|pending|conflict/.test(c.ownership_status)); if(view==='retained')rows=rows.filter(c=>c.retained_brand); if(view==='franchise')rows=rows.filter(c=>c.franchise_flag);
rows.sort((a,b)=>a.brand_name.localeCompare(b.brand_name)); const g=document.querySelector('#graph');g.innerHTML='';document.querySelector('#stat').textContent=`${rows.length} of ${chains.length} active brands`;
if(!rows.length){g.innerHTML='<div class="empty">No records match these filters.</div>';return}
for(const c of rows){const r=document.createElement('div');r.className='row'; const cls=/unresolved|conflict/.test(c.ownership_status)?' unresolved':(/pending/.test(c.ownership_status)?' pending':''); const mid=c.platform_or_franchise_system||'No separate platform identified'; const end=c.ultimate_owner_or_controller||'Current controller unresolved';
r.innerHTML=`<div class="node${cls}"><strong>${esc(c.brand_name)} <span class="rating">${esc(c.evidence_rating)}</span></strong><div class="meta">${esc(sector(c))} · ${esc(c.owner_type)}</div></div><div class="arrow">→</div><div class="node"><strong>${esc(mid)}</strong><div class="meta">${c.franchise_flag?'Franchise system / local operator boundary':'Platform, legal entity or immediate owner'}</div></div><div class="arrow">→</div><div class="node${cls}"><strong>${esc(end)}</strong><div class="meta">${esc(c.ownership_interest)}</div></div><div class="details"><strong>Status</strong>: ${esc(c.ownership_status)}<br><strong>Local wording</strong>: ${esc(c.local_claim_type)}<br><strong>Sources</strong>: <span class="source">${esc(c.source_ids.join(', '))}</span>${c.notes?'<br><strong>Note</strong>: '+esc(c.notes):''}</div>`; r.addEventListener('click',()=>r.classList.toggle('open'));g.appendChild(r)} }
['q','sector','owner','rating','view'].forEach(id=>document.querySelector('#'+id).addEventListener('input',render));document.querySelector('#reset').onclick=()=>{document.querySelector('#q').value='';document.querySelector('#sector').value='';ownerSel.value='Sponsor-backed platform';document.querySelector('#rating').value='';document.querySelector('#view').value='chains';render()};render();
</script></body></html>'''.replace('__DATA__', graph_data_js)
(OUT / 'ownership_graph.html').write_text(ownership_graph_html, encoding='utf-8')

# Filterable table HTML.
table_data_js = json.dumps(published, ensure_ascii=False)
ownership_table_html = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Austin Home-Service Ownership Table</title><style>
body{margin:0;font:14px/1.4 system-ui,-apple-system,Segoe UI,Arial;background:#f7f7f3;color:#111}header{padding:24px 4vw;background:#fff;border-bottom:1px solid #ccc}h1{margin:0 0 8px}.controls{display:flex;gap:10px;flex-wrap:wrap;padding:12px 4vw;position:sticky;top:0;background:#f7f7f3;border-bottom:1px solid #ccc}input,select,button{padding:8px;border:1px solid #bbb;border-radius:5px;background:#fff}main{padding:14px 4vw 50px;overflow:auto}table{border-collapse:collapse;width:100%;min-width:1300px;background:#fff}th,td{padding:9px;border-bottom:1px solid #ddd;text-align:left;vertical-align:top}th{position:sticky;top:58px;background:#eee;cursor:pointer}tr:hover{background:#fafaf5}.small{font-size:12px;color:#666}.badge{padding:2px 6px;border:1px solid #bbb;border-radius:999px;font-size:11px}.stat{padding:8px;color:#666}</style></head><body>
<header><h1>Filterable Austin Home-Service Ownership Table</h1><div>Snapshot July 26, 2026. Brand-record shares are not market share.</div></header><div class="controls"><input id="q" placeholder="Search"><select id="cat"><option value="">All categories</option></select><select id="owner"><option value="">All owner types</option></select><select id="rating"><option value="">All ratings</option><option>A</option><option>B</option><option>C</option><option>D</option></select><button id="download">Download filtered CSV</button><span id="stat" class="stat"></span></div><main><table><thead><tr><th data-k="brand_name">Brand</th><th data-k="primary_category">Category</th><th data-k="current_owner_type">Owner type</th><th data-k="current_platform_or_franchise_system">Platform / franchise</th><th data-k="current_ultimate_owner_or_controller">Ultimate owner / controller</th><th data-k="ownership_interest">Interest</th><th data-k="ownership_verification_status">Status</th><th data-k="evidence_rating">Rating</th><th data-k="local_claim_type">Local wording</th><th data-k="service_area_summary">Austin footprint</th><th data-k="ownership_source_ids">Evidence IDs</th></tr></thead><tbody id="body"></tbody></table></main>
<script>const DATA=__DATA__;const qEl=document.getElementById('q'),catEl=document.getElementById('cat'),ownerEl=document.getElementById('owner'),ratingEl=document.getElementById('rating'),bodyEl=document.getElementById('body'),statEl=document.getElementById('stat'),downloadEl=document.getElementById('download');let sortK='brand_name',sortDir=1,current=[];const cats=[...new Set(DATA.map(x=>x.primary_category))].sort(),owners=[...new Set(DATA.map(x=>x.current_owner_type))].sort();for(const x of cats){catEl.add(new Option(x,x))}for(const x of owners){ownerEl.add(new Option(x,x))}function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}function run(){const qq=qEl.value.toLowerCase(),c=catEl.value,o=ownerEl.value,r=ratingEl.value;current=DATA.filter(x=>(!qq||JSON.stringify(x).toLowerCase().includes(qq))&&(!c||x.primary_category===c)&&(!o||x.current_owner_type===o)&&(!r||x.evidence_rating===r)).sort((a,b)=>String(a[sortK]).localeCompare(String(b[sortK]))*sortDir);bodyEl.innerHTML=current.map(x=>`<tr><td><strong>${esc(x.brand_name)}</strong></td><td>${esc(x.primary_category)}</td><td>${esc(x.current_owner_type)}</td><td>${esc(x.current_platform_or_franchise_system)}</td><td>${esc(x.current_ultimate_owner_or_controller)}</td><td>${esc(x.ownership_interest)}</td><td>${esc(x.ownership_verification_status)}</td><td><span class="badge">${esc(x.evidence_rating)}</span></td><td>${esc(x.local_claim_type)}</td><td>${esc(x.service_area_summary)}</td><td class="small">${esc(x.ownership_source_ids)}</td></tr>`).join('');statEl.textContent=`${current.length} of ${DATA.length} brands`}['q','cat','owner','rating'].forEach(id=>document.getElementById(id).addEventListener('input',run));document.querySelectorAll('th').forEach(th=>th.onclick=()=>{const k=th.dataset.k;if(sortK===k)sortDir*=-1;else{sortK=k;sortDir=1}run()});downloadEl.onclick=()=>{const cols=['brand_name','primary_category','current_owner_type','current_platform_or_franchise_system','current_ultimate_owner_or_controller','ownership_interest','ownership_verification_status','evidence_rating','local_claim_type','service_area_summary','ownership_source_ids'];const csv=[cols.join(','),...current.map(x=>cols.map(k=>'"'+String(x[k]??'').replaceAll('"','""')+'"').join(','))].join('\n');const a=document.createElement('a');const objectUrl=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.href=objectUrl;a.download='austin-home-service-ownership-filtered.csv';a.click();setTimeout(()=>URL.revokeObjectURL(objectUrl),1000)};run();</script></body></html>'''.replace('__DATA__', table_data_js)
(OUT / 'ownership_table.html').write_text(ownership_table_html, encoding='utf-8')

# Acquisition timeline HTML.
timeline_data_js = json.dumps(transactions, ensure_ascii=False)
timeline_html = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Austin Home-Service Acquisition Timeline</title><style>body{margin:0;font:15px/1.45 system-ui;background:#f7f7f3;color:#111}header,.controls,main{padding-left:5vw;padding-right:5vw}header{padding-top:28px;padding-bottom:18px;background:white;border-bottom:1px solid #ccc}h1{margin:0 0 8px}.controls{padding-top:12px;padding-bottom:12px;display:flex;gap:10px;flex-wrap:wrap;position:sticky;top:0;background:#f7f7f3;border-bottom:1px solid #ccc}select,input{padding:8px;border:1px solid #bbb;border-radius:5px;background:#fff}.timeline{max-width:980px;margin:25px 0 60px;border-left:2px solid #bbb;padding-left:22px}.item{position:relative;background:#fff;border:1px solid #ccc;border-radius:8px;padding:14px;margin:0 0 14px}.item:before{content:'';position:absolute;left:-30px;top:20px;width:12px;height:12px;border-radius:50%;background:#fff;border:2px solid #444}.pending{border-left:5px solid #8a5a2b}.historical{opacity:.78}.date{font-weight:700}.meta{color:#666;font-size:12px}.empty{padding:25px;background:#fff;border:1px dashed #bbb}</style></head><body><header><h1>Acquisition and Investment Timeline</h1><div>Closed, historical and pending transactions relevant to the Austin-facing ownership map. Snapshot July 26, 2026.</div></header><div class="controls"><input id="q" placeholder="Search target, buyer or seller"><select id="status"><option value="">All statuses</option></select><select id="year"><option value="">All years</option></select><span id="stat"></span></div><main><div id="timeline" class="timeline"></div></main><script>const DATA=__DATA__;const qEl=document.getElementById('q'),statusEl=document.getElementById('status'),yearEl=document.getElementById('year'),statEl=document.getElementById('stat'),timelineEl=document.getElementById('timeline');const statuses=[...new Set(DATA.map(x=>x.status_as_of_snapshot))].sort(),years=[...new Set(DATA.map(x=>(x.close_date||x.announcement_date||'unknown').slice(0,4)))].sort().reverse();statuses.forEach(x=>statusEl.add(new Option(x,x)));years.forEach(x=>yearEl.add(new Option(x,x)));function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}function run(){const qq=qEl.value.toLowerCase(),st=statusEl.value,yr=yearEl.value;const rows=DATA.filter(x=>(!qq||JSON.stringify(x).toLowerCase().includes(qq))&&(!st||x.status_as_of_snapshot===st)&&(!yr||(x.close_date||x.announcement_date||'').startsWith(yr))).sort((a,b)=>(b.close_date||b.announcement_date).localeCompare(a.close_date||a.announcement_date));statEl.textContent=`${rows.length} transactions`;timelineEl.innerHTML=rows.length?rows.map(x=>`<div class="item ${x.status_as_of_snapshot.includes('pending')?'pending':''} ${x.status_as_of_snapshot.includes('historical')?'historical':''}"><div class="date">${esc(x.close_date||x.announcement_date||'Date unresolved')}</div><strong>${esc(x.target)}</strong><br>${esc(x.buyer)}${x.seller?' from '+esc(x.seller):''}<div class="meta">${esc(x.transaction_type)} · ${esc(x.interest_acquired)} · ${esc(x.status_as_of_snapshot)} · ${esc(x.source_ids)}</div><div>${esc(x.current_effect)}</div>${x.notes?'<div class="meta">'+esc(x.notes)+'</div>':''}</div>`).join(''):'<div class="empty">No matching transactions.</div>'}['q','status','year'].forEach(id=>document.getElementById(id).addEventListener('input',run));run();</script></body></html>'''.replace('__DATA__', timeline_data_js)
(OUT / 'acquisition_timeline.html').write_text(timeline_html, encoding='utf-8')

# Mobile cards HTML.
mobile_html = r'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Austin Home-Service Ownership Cards</title><style>body{margin:0;font:15px/1.45 system-ui;background:#f4f4f0;color:#111}header{padding:24px 18px;background:#fff;border-bottom:1px solid #ccc}.controls{padding:12px 18px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;position:sticky;top:0;background:#f4f4f0;border-bottom:1px solid #ccc}input,select{padding:9px;border:1px solid #bbb;border-radius:6px;min-width:0}.cards{padding:16px;display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px}.card{background:#fff;border:1px solid #ccc;border-radius:10px;padding:14px}.chain{margin:10px 0;font-weight:600}.arrow{color:#777}.meta{font-size:12px;color:#666}.rating{float:right;border:1px solid #aaa;border-radius:999px;padding:1px 7px}</style></head><body><header><h1>Mobile Ownership Cards</h1><div>67 active Austin-facing consumer brands. Snapshot July 26, 2026.</div></header><div class="controls"><input id="q" placeholder="Search"><select id="owner"><option value="">All owner types</option></select><span id="stat" class="meta"></span></div><div id="cards" class="cards"></div><script>const DATA=__DATA__;const qEl=document.getElementById('q'),ownerEl=document.getElementById('owner'),cardsEl=document.getElementById('cards'),statEl=document.getElementById('stat');[...new Set(DATA.map(x=>x.owner_type))].sort().forEach(x=>ownerEl.add(new Option(x,x)));function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}function run(){const qq=qEl.value.toLowerCase(),o=ownerEl.value;const rows=DATA.filter(x=>(!qq||JSON.stringify(x).toLowerCase().includes(qq))&&(!o||x.owner_type===o));statEl.textContent=`${rows.length} of ${DATA.length} brands`;cardsEl.innerHTML=rows.map(x=>`<article class="card"><span class="rating">${esc(x.evidence_rating)}</span><strong>${esc(x.brand_name)}</strong><div class="meta">${esc(x.primary_category)} · ${esc(x.owner_type)}</div><div class="chain">${x.chain.map(esc).join(' <span class="arrow">→</span> ')}</div><div>${esc(x.ownership_interest)}</div><div class="meta">Status: ${esc(x.ownership_status)}<br>Sources: ${esc(x.source_ids.join(', '))}</div></article>`).join('')}qEl.addEventListener('input',run);ownerEl.addEventListener('input',run);run();</script></body></html>'''.replace('__DATA__', json.dumps(mobile_chains, ensure_ascii=False))
(OUT / 'mobile_ownership_cards.html').write_text(mobile_html, encoding='utf-8')

interactive_spec = """# Interactive Graph Specification

## Public default

- Display current active consumer brands only.
- Default owner-type filter: sponsor-backed platform.
- Use a layered chain, not a force-directed network.
- Columns: consumer brand → immediate platform/local operator/franchise system → ultimate owner/controller.
- Show evidence rating and unresolved/pending state on every row.
- Open a row to reveal interest type, local-language coding, evidence IDs and notes.

## Filters

- Search by brand, platform, sponsor, public parent or local owner.
- Sector: HVAC/plumbing/electrical; roofing/exterior; foundation; pest.
- Owner type.
- Evidence rating.
- Unresolved only.
- Retained brands only.
- Franchises only.
- Current vs historical/pending edges.

## Deep view

The optional deep layer adds legal entities, DBAs, holding companies, minority investors, former sponsors, acquisitions, combinations and rebrands. It must preserve edge labels. “Franchise of” cannot render as “subsidiary of.” Pending `Acquired by` edges must not replace current parents.

## Node and edge behavior

- Brand nodes link to mobile ownership cards.
- Sponsor and platform nodes open a list of associated Austin-facing brands.
- Evidence IDs open the source ledger.
- Historical edges use lower opacity.
- Pending edges use a dashed line.
- Minority-investment edges use a distinct line pattern from majority-control edges.
- Unresolved controllers end in an explicit unresolved node or no owner edge; they never default to “independent.”

## Accessibility

- Every graph relationship must also appear as text.
- Keyboard focus must follow the chain order.
- Color cannot be the only signal for pending, minority or unresolved status.
- Mobile layout stacks the chain vertically.
- The graph should remain usable with JavaScript disabled through a static ownership table.

## Files

- `graph.json`: full graph and mobile chains.
- Four category JSON files.
- `graph_sponsor_platform_view.json`.
- `ownership_graph.html`: self-contained public prototype.
- `ownership_table.html`: self-contained fallback and filtering tool.
"""
(OUT / 'interactive_graph_spec.md').write_text(interactive_spec, encoding='utf-8')

# ---------------------------
# Remaining publication assets
# ---------------------------

master_dataset = {
    'metadata': {
        'title': 'Who Owns Austin’s Home-Service Companies?',
        'snapshot_date': SNAPSHOT_DATE,
        'active_brand_denominator': headline_denominator,
        'methodology_file': 'methodology.md',
        'source_ledger_file': 'master_evidence.csv',
        'warning': metrics['denominator_note'],
    },
    'brands': brands,
    'entities': entities,
    'relationships': relationships,
    'transactions': transactions,
    'evidence': sources,
    'footprints': footprints,
    'conflicts': conflicts,
    'unresolved': unresolved,
    'findings': metrics,
}
(OUT / 'master_dataset.json').write_text(json.dumps(master_dataset, indent=2, ensure_ascii=False), encoding='utf-8')
(OUT / 'ownership_cards.json').write_text(json.dumps(mobile_chains, indent=2, ensure_ascii=False), encoding='utf-8')

source_ledger_lines = [
    '# Source Ledger',
    '',
    f'**Snapshot:** {SNAPSHOT_DATE}  ',
    f'**Sources:** {len(sources)}  ',
    '',
    'Source IDs are used across every CSV, JSON graph, article citation and ownership card. A syndication or copied release is not treated as an independent source merely because it has another URL.',
    '',
]
for s in sources:
    date_part = f" — {s['publication_date']}" if s['publication_date'] else ''
    source_ledger_lines.extend([
        f"## {s['source_id']} — {s['title']}",
        '',
        f"- **Publisher:** {s['publisher']}",
        f"- **Type:** {s['source_type']} ({s['primary_secondary']})",
        f"- **Quality:** {s['quality_rating']}",
        f"- **Independence group:** `{s['independence_group']}`",
        f"- **Publication date:** {s['publication_date'] or 'not stated'}",
        f"- **Access date:** {s['access_date']}",
        f"- **URL or file:** {s['url']}",
        f"- **Supports:** {s['supports_claims'] or 'identity or research context'}",
    ])
    if s['notes']:
        source_ledger_lines.append(f"- **Note:** {s['notes']}")
    source_ledger_lines.append('')
(OUT / 'source_ledger.md').write_text('\n'.join(source_ledger_lines), encoding='utf-8')

# Text transaction timeline grouped by effective year.
def tx_sort_date(t: dict) -> str:
    return t['close_date'] or t['announcement_date'] or '0000'

timeline_lines = ['# Acquisition and Investment Timeline','',f'**Snapshot:** {SNAPSHOT_DATE}','','Pending transactions do not replace current-owner relationships. Dates marked by year or month reflect the precision available in the cited source.','']
by_year = defaultdict(list)
for t in sorted(transactions, key=tx_sort_date, reverse=True):
    by_year[(tx_sort_date(t)[:4] or 'Unknown')].append(t)
for year in sorted(by_year, reverse=True):
    timeline_lines.append(f'## {year}')
    timeline_lines.append('')
    for t in by_year[year]:
        date_display = t['close_date'] or t['announcement_date'] or 'date unresolved'
        seller = f" from {t['seller']}" if t['seller'] else ''
        timeline_lines.append(f"- **{date_display}: {t['target']}** — {t['buyer']}{seller}. {t['interest_acquired']}. Status: `{t['status_as_of_snapshot']}`. Current effect: {t['current_effect']} Sources: {t['source_ids']}.")
        if t['notes']:
            timeline_lines.append(f"  - Note: {t['notes']}")
    timeline_lines.append('')
(OUT / 'acquisition_timeline.md').write_text('\n'.join(timeline_lines), encoding='utf-8')

cards_lines = ['# Mobile Ownership Cards','',f'**Snapshot:** {SNAPSHOT_DATE}  ',f'**Active cards:** {len(mobile_chains)}','','Each card separates the consumer brand, immediate platform or franchise system, ultimate owner/controller, interest type, status and evidence.','']
for c in sorted(mobile_chains, key=lambda x: (sector_for_brand(brand_lookup_by_id[x['brand_id']]), x['brand_name'])):
    cards_lines.extend([
        f"## {c['brand_name']}",
        '',
        f"**Chain:** {' → '.join(c['chain'])}  ",
        f"**Category:** {sector_for_brand(brand_lookup_by_id[c['brand_id']])}  ",
        f"**Owner type:** {c['owner_type']}  ",
        f"**Interest:** {c['ownership_interest']}  ",
        f"**Status:** {c['ownership_status']}  ",
        f"**Evidence:** {c['evidence_rating']} — {', '.join(c['source_ids'])}  ",
        f"**Local wording:** {c['local_claim_type']}  ",
    ])
    if c['notes']:
        cards_lines.append(f"**Note:** {c['notes']}  ")
    cards_lines.append('')
(OUT / 'mobile_ownership_cards.md').write_text('\n'.join(cards_lines), encoding='utf-8')

executive_box = f"""# Executive Findings Box

**67 active Austin-facing consumer brands, July 26, 2026**

- **14 ({pct(14)})** sit in sponsor-backed operating platforms.
- **4 ({pct(4)})** have public-company parents.
- **5 ({pct(5)})** are local franchise operators; the franchisor’s owner is not treated as the local operator’s owner.
- **32 ({pct(32)})** are coded to founder, family or local ownership based on named-owner evidence or a current claim.
- **1 ({pct(1)})** is minority-invested but founder-controlled: Alta Pest Control.
- **11 ({pct(11)})** remain private/control unresolved.
- **48 of 67 ({pct(48)})** have A/B current ownership structures and are not coded unresolved.
- **11** established consumer names remain visible after a transaction.

*All percentages use the 67-brand reconstructed publication universe. They are not market share.*
"""
(OUT / 'executive_findings_box.md').write_text(executive_box, encoding='utf-8')

chart_assets = """# Suggested Chart Captions and Factual Alt Text

## 1. Owner-type distribution

**Caption:** Owner classification for 67 active Austin-facing home-service consumer brands as of July 26, 2026. The counts describe brand records, not revenue or market share.

**Alt text:** Horizontal bars show 32 founder, family or local-ownership records; 14 sponsor-backed platform brands; 11 private companies with unresolved control; 5 local franchise operators; 4 public-company-owned brands; and 1 minority-invested founder-controlled brand.

## 2. Active brands by service sector

**Caption:** Active consumer-brand records in the reconstructed Austin publication universe by primary service sector.

**Alt text:** Four bars show 26 HVAC, plumbing and bundled electrical brands; 20 pest-control brands; 12 foundation-repair brands; and 9 roofing or exterior-service brands.

## 3. Current Austin brand clusters

**Caption:** Selected current multi-brand or shared-parent clusters. Franchise associations are labeled separately from direct ownership.

**Alt text:** Southern Home Services connects Fox, Precision and Daniel’s to Gryphon. SAS Service Partners connects Austin Air Conditioning and Roger’s Plumbing to Storr Group. Rollins connects Orkin and HomeTeam. Neighborly connects three local franchise brands to KKR at the franchisor level.

## 4. Acquisition and investment timeline

**Caption:** Selected completed and pending transactions affecting Austin-facing home-service brands. Pending agreements do not replace current owners.

**Alt text:** A timeline from 2008 to 2026 includes Rollins-HomeTeam, Brookfield-Enercare, Southern’s Austin acquisitions, KKR-Groundworks, SAS’s Austin acquisitions, Dunes Point-Ja-Mar, Citation-Aptive, and the pending Blackstone-Champions agreement.

## 5. Evidence-status distribution

**Caption:** Evidence rating for the 67 active brand records.

**Alt text:** The chart shows 27 A-rated records, 21 B-rated records, 9 C-rated records and 10 D-rated records. A and B indicate publication-grade or strongly supported structures; C is qualified; D is unresolved.

## 6. Example mobile ownership chain

**Caption:** Mr. Rooter Plumbing of Austin demonstrates why the local franchisee must be separated from the franchisor and its sponsor.

**Alt text:** The chain runs from Mr. Rooter Plumbing of Austin to a locally owned Austin franchisee, then separately to the Neighborly franchise system and KKR. A note states that KKR does not directly own the Austin operating company based on the evidence reviewed.
"""
(OUT / 'chart_captions_alt_text.md').write_text(chart_assets, encoding='utf-8')

social_newsletter = f"""# Social and Newsletter Summaries

## Social post — data finding

Austin’s home-service market contains more shared ownership than the brand names suggest. We mapped {headline_denominator} active HVAC, plumbing, roofing, foundation and pest-control brands to their current platforms, public parents, sponsors, franchise systems and local owners as of July 26, 2026. The database preserves minority stakes, pending deals and unresolved cases instead of flattening every company into “local” or “PE-owned.”

## Social post — example

Fox, Precision and Daniel’s appear as separate Austin service brands. All three currently lead to Southern Home Services, then to the Gryphon-backed North American Essential Home Services structure. The map shows the consumer names and the ownership chain side by side, with source IDs for every edge.

## Social post — franchise distinction

KKR owns Neighborly. That does not mean KKR directly owns Mr. Rooter Plumbing of Austin or the local Aire Serv operators. The Austin ownership map separates local franchisees from the franchisor’s parent, one of the most common errors in roll-up research.

## Newsletter short

A new Austin ownership database traces 67 active home-service brands through legal entities, platforms, sponsors, public parents and franchise systems. Fourteen brands sit in sponsor-backed operating platforms, four have public-company parents, five are local franchises, and eleven remain unresolved at the controller level. The package includes a filterable table, graph, transaction timeline, source ledger and correction system. Counts are brand-record shares, not market share.

## Newsletter long

Home-service companies often retain their established names after a sale. That makes a normal search for an HVAC, plumbing, roofing, foundation or pest company a poor guide to who owns the business. This project reconstructs the Austin market at the consumer-brand level, then connects each brand to the current operating platform, legal entity, sponsor, public parent or local owner when the evidence supports it.

The July 26, 2026 snapshot contains 67 active brands. It corrects several common classification errors: Alta’s Trivest investment is minority and non-control; KKR’s ownership of Neighborly sits at the franchisor level; the Blackstone-Champions transaction remains pending without closing evidence; and historical divisional sales do not automatically establish the current owner of an active brand. The full database is downloadable and every relationship carries evidence IDs, dates and an evidence note.
"""
(OUT / 'social_newsletter_summaries.md').write_text(social_newsletter, encoding='utf-8')

seo_package = """# SEO Package

## Core metadata

**SEO title:** Who Owns Austin HVAC, Plumbing, Roofing and Pest Companies?

**H1:** Who Owns Austin’s Home-Service Companies? A Verified Map of Private Equity, Roll-Ups, and Local Brands

**Meta description:** Explore a sourced ownership map of 67 Austin-area HVAC, plumbing, roofing, foundation and pest-control brands, including private-equity platforms, public parents, franchises and local owners.

**Suggested URL slug:** `/research/who-owns-austin-home-service-companies/`

## Primary query cluster

- who owns Austin home service companies
- Austin HVAC private equity
- Austin plumbing company ownership
- Austin roofing company ownership
- Austin pest control parent company
- Austin foundation repair ownership
- home service roll-ups Austin
- private equity home services Austin
- is [brand] locally owned
- who owns [brand]
- is [brand] owned by private equity

## Brand-specific opportunities

Priority pages or sections should follow demonstrated ownership complexity, not search volume alone:

- Who owns Fox Service Company?
- Who owns Precision Heating & Air?
- Who owns Daniel’s Plumbing and Air Conditioning?
- Who owns Radiant Plumbing?
- Who owns Stan’s Heating and Air?
- Who owns Abacus Plumbing?
- Who owns Service Wizard?
- Who owns Austin Air Conditioning?
- Who owns Roger’s Plumbing?
- Who owns Ja-Mar Roofing?
- Who owns Groundworks?
- Who owns Aptive?
- Is Alta Pest Control private-equity owned?
- Who owns Mr. Rooter Plumbing of Austin?
- Who owns Terminix and Orkin?

A brand page should not exist unless it contains a verified chain, transaction chronology, local-presence evidence, current/ former owner distinction, uncertainty note and original source work.

## Heading structure

1. Who Owns Austin’s Home-Service Companies?
2. One group, several Austin names
2. The ownership map
2. What the 67-brand denominator shows
2. HVAC, plumbing and bundled electrical
3. Southern Home Services and Gryphon
3. Radiant, Stan’s, Abacus and Goettl
3. Service Experts, Service Wizard and ARS
3. The SAS/Storr cluster
2. Roofing and exterior services
2. Foundation repair
2. Pest control
2. What “local” actually means
2. Selected ownership cards
2. How ownership was verified
2. What the data cannot establish
2. Corrections and updates

## Dataset structured data

Use `Dataset` with:

- `name`
- `description`
- `datePublished`
- `dateModified`
- `temporalCoverage`: `2026-07-26`
- `spatialCoverage`: Austin-Round Rock-Georgetown area
- `creator`
- `publisher`
- `license`
- `isAccessibleForFree`
- `keywords`
- `variableMeasured`
- `distribution` entries using `DataDownload` for each CSV and JSON file
- `includedInDataCatalog` if a persistent research catalog is created
- `measurementTechnique` pointing to the methodology page

Do not put the 67-brand count in `spatialCoverage` or describe it as a market census.

## Article structured data

Use `Article` or `NewsArticle` only if the page meets editorial-news criteria. Include:

- headline and description
- author and publisher
- datePublished / dateModified
- mainEntityOfPage
- about entities for home services, private equity and Austin
- citation links to primary sources
- `isBasedOn` pointing to the dataset and methodology
- `hasPart` for interactive graph, timeline and table

Also use `BreadcrumbList`. Do not use `FAQPage` unless the questions and answers are visibly rendered and the site’s implementation complies with current search-engine guidance.

## Internal-link plan for sulayman-bowles.dev

- Research index → ownership article
- Ownership article → Search Visibility Due Diligence for Buying a Small Business
- Ownership article → Austin home-service market / PE roll-up methodology
- Ownership article → source methodology and correction log
- Search diligence article → ownership dataset as an example of brand/entity separation
- VOID service page → methodology, not an unsupported transaction-experience claim
- Relevant brand pages → master article and category section
- Future acquisition or consolidation research → transaction timeline

Anchor text should identify the exact asset: “Austin home-service ownership database,” “current sponsor and parent map,” or “home-service transaction timeline.”

## Future pages from the verified dataset

1. Category pages for HVAC/plumbing, roofing, foundation and pest only if each includes a distinct graph, findings, transactions and unresolved records.
2. Sponsor/platform profiles where at least two Austin-facing brands or a materially complex chain exist.
3. Brand ownership pages for the priority list above.
4. A corrections/changelog page with dated updates.
5. A methodology page explaining franchise, minority and current-owner rules.
6. A Texas expansion only after systematic state license and entity collection.

Avoid thin pages that merely repeat the parent name and acquisition date.
"""
(OUT / 'seo_package.md').write_text(seo_package, encoding='utf-8')

link_earning = """# Link-Earning and Outreach Package

| Target category | Finding likely to interest them | Asset to send | Outreach angle | Reason not to pitch |
|---|---|---|---|---|
| Austin business reporters | Multiple retained local brands lead to a small set of platforms; SAS/Storr was a missed cluster | Interactive graph + transaction timeline | A reproducible local consolidation map with dated ownership chains | Do not pitch a generic “PE is taking over” claim; the data does not measure market share |
| Austin consumer and housing reporters | “Local” can mean ownership, management, history or franchise operation | Article section + mobile cards | Help homeowners understand who is behind a familiar service name | Avoid service-quality or pricing claims without separate evidence |
| Texas business publications | Sponsor, public-parent and local-family ownership coexist in the same market | Dataset + sponsor/platform graph | Texas home-services M&A shown at the consumer-brand level | Do not overstate completeness outside Austin |
| HVAC and plumbing trade publications | Southern, T3, MTG, Wrench, SAS, ARS and Service Experts use different platform structures | HVAC graph + timeline | A local case study in retained brands and capital structures | Avoid ranking operators by size |
| Roofing trade publications | Ja-Mar’s retained name and current local wording sit inside a documented platform acquisition | Ja-Mar card + roofing graph | Precise treatment of retained local brands after acquisition | Do not imply the wording is deceptive |
| Foundation-repair trade publications | KKR/Cortec control split at Groundworks; several local controllers remain unresolved | Foundation graph + unresolved table | Where public ownership evidence is strong and where it fails | Avoid presenting the list as a complete contractor census |
| Pest-control trade publications | Alta’s non-control minority investment differs from Aptive, Rollins and Rentokil structures | Pest graph + Alta card | Majority, minority, public and family structures in one local market | Do not collapse Trivest into control |
| Private-equity and M&A publications | Brand count differs from platform count; pending and minority deals are preserved | Sponsor graph + master transactions CSV | A transaction-quality data model for local roll-up research | Do not pitch brand-record shares as market penetration |
| Consumer advocates | Franchise and local-language distinctions affect how consumers interpret identity | Franchise cards + methodology | A neutral ownership disclosure tool | Do not claim consumer harm from ownership alone |
| Home inspectors | Foundation, roofing and pest vendor identities can be obscured by brands and franchises | Filterable table | A reference for explaining vendor relationships to clients | Do not ask for endorsement of unresolved records |
| Real-estate agents and brokerages | Homeowners routinely hire these categories during transactions | Mobile cards + article | A practical ownership reference for vendor due diligence | Avoid turning the dataset into a preferred-vendor list |
| Local chambers and business groups | The database preserves real local operators and distinguishes them from platforms | Category table + correction form | Invite documented corrections and local entity evidence | Do not imply chamber membership proves ownership |
| Academic and policy researchers | Transparent brand/entity graph and source-independence fields | Full CSV/JSON package + methodology | Reusable local consolidation dataset with explicit limits | Do not claim causal effects or complete market coverage |

## Best initial pitches

1. **Austin business desk:** Three familiar Austin brands, one Southern/Gryphon chain; two SAS/Storr brands missed by the initial census.
2. **Trade press:** Alta’s minority non-control structure versus Aptive’s majority transaction and Rollins/Rentokil public ownership.
3. **M&A press:** A reproducible rule for separating current, former, pending, majority, minority and franchise relationships.
4. **Consumer desk:** Why a locally operated or family-founded brand may not be locally owned today.

## Evidence package to attach

- One screenshot or live link to the filtered graph
- Relevant brand card
- Transaction row
- Two or three direct source IDs
- Methodology paragraph on the claim being pitched
- Correction contact and changelog link

Never lead with a percentage unless the denominator is stated in the same sentence.
"""
(OUT / 'link_earning_package.md').write_text(link_earning, encoding='utf-8')

reporter_brief = f"""# Reporter Outreach Brief

## Story in one sentence

A source-linked map of {headline_denominator} Austin-facing home-service brands shows how retained local names, sponsor-backed platforms, public parents and local franchises overlap, while preserving 11 unresolved ownership cases instead of forcing an answer.

## Cleanest examples

- **Fox, Precision and Daniel’s:** separate consumer names inside Southern Home Services and the Gryphon-backed NAEHS structure.
- **Austin Air Conditioning and Roger’s Plumbing:** current SAS Service Partners brands backed by Storr Group; Cool Atmosphere is absorbed rather than counted twice.
- **Ja-Mar:** acquired by a Dunes Point-backed platform while current local wording remains on the brand site.
- **Alta:** Trivest minority, non-control investment; founders retained control.
- **Mr. Rooter Austin:** locally owned franchise; KKR owns Neighborly, not the Austin operating company.

## Numbers that can be quoted with the denominator

- 67 active Austin-facing consumer-brand records.
- 14 sponsor-backed platform brands.
- 4 public-company-owned brands.
- 5 local franchise records.
- 11 private/control-unresolved records.
- 48 A/B, non-unresolved ownership structures.

Every number above is a share or count of brand records, not market share.

## What not to say

- Do not say private equity controls a stated percentage of Austin home-service revenue.
- Do not say an ownership structure caused price or service changes.
- Do not describe a franchisor sponsor as the local franchisee’s direct owner.
- Do not call Blackstone the current Champions owner without closing evidence.

## Available assets

Interactive graph, filterable table, transaction timeline, full CSV/JSON download, methodology, source ledger, conflict table and correction system.
"""
(OUT / 'reporter_outreach_brief.md').write_text(reporter_brief, encoding='utf-8')

corrections = """# Corrections and Update System

## Public correction language

This database is a dated ownership map, not a legal opinion. Companies, owners, investors, employees, reporters and readers may submit documented corrections. Please identify the affected brand and field, state the proposed replacement, give the effective date, and attach or link direct evidence.

Useful evidence includes current legal terms, Texas entity or assumed-name filings, trade-license records, completed transaction announcements, sponsor portfolio pages, annual reports, signed company statements and current franchisee documents. Marketing copy, anonymous posts and unexplained screenshots may generate a review but will not automatically change an ownership classification.

## Submission fields

- Name and contact information
- Relationship to the company or record
- Brand and legal entity
- Field disputed
- Current published value
- Proposed value
- Effective date
- Source URL or document
- Whether the document may be published
- Explanation of any confidential material

## Review workflow

1. Log the submission with a received date.
2. Preserve the current public value during review unless it creates a clear and material factual risk.
3. Check the evidence against the same source hierarchy used for the original database.
4. Seek a second source when the correction changes a controlling owner, interest type, transaction status or franchise relationship.
5. Mark the result accepted, rejected or unresolved.
6. Update the relevant CSV, JSON, graph and card together.
7. Add a changelog entry with the prior value, new value, effective date and source IDs.
8. Retain rejected submissions internally with the reason.

## Fast corrections

Typographical errors, broken source links and obvious duplicate records can be corrected directly with a changelog note. Ownership changes, pending-deal closings, minority/majority classifications and franchisee identities require evidence review.

## Changelog entry

**Date:**  
**Brand/entity:**  
**Field:**  
**Old value:**  
**New value:**  
**Effective date:**  
**Source IDs:**  
**Reason:**  
**Review status:**  
**Reviewer:**

## Versioning

- Patch release: citation, spelling, URL or non-substantive identity fix.
- Minor release: new brand, new legal identity, resolved owner or transaction update.
- Major release: geographic expansion, methodology change or denominator rebuild.

The public page should display the snapshot date, latest modified date and direct links to the changelog and correction form.
"""
(OUT / 'corrections_and_updates.md').write_text(corrections, encoding='utf-8')

publication_assets = """# Publication Assets Index

1. **Final article:** `article.md`
2. **Executive findings box:** `executive_findings_box.md`
3. **Interactive graph:** `ownership_graph.html`, `graph.json`, category JSON files, sponsor view JSON
4. **Filterable ownership table:** `ownership_table.html`
5. **Downloadable CSVs:** eight `master_*.csv` files
6. **Downloadable JSON:** `master_dataset.json`, `graph.json`, `ownership_cards.json`
7. **Acquisition timeline:** `acquisition_timeline.html`, `acquisition_timeline.md`
8. **Methodology page:** `methodology.md`
9. **Source ledger:** `master_evidence.csv`, `source_ledger.md`
10. **Correction language:** `corrections_and_updates.md`
11. **Changelog:** `changelog.md`
12. **Mobile ownership cards:** `mobile_ownership_cards.html`, `mobile_ownership_cards.md`, `ownership_cards.json`
13. **Chart captions and alt text:** `chart_captions_alt_text.md`
14. **Social and newsletter copy:** `social_newsletter_summaries.md`
15. **Reporter brief:** `reporter_outreach_brief.md`
16. **SEO package:** `seo_package.md`
17. **Link-earning package:** `link_earning_package.md`
18. **Audit and findings:** `research_audit_memo.md`, `verified_findings.md`, `unresolved_and_rejected_claims.md`
19. **Final adversarial review:** `final_adversarial_review.md`
20. **Combined publication DOCX:** `Austin_Home_Service_Ownership_Publication_Package.docx`
"""
(OUT / 'publication_assets.md').write_text(publication_assets, encoding='utf-8')

adversarial_answers = [
    ('1. Does every mapped brand currently serve Austin?', 'Yes for the 67-brand active denominator based on a current official branch, office, territory or service-area source. Historical, candidate and excluded rows are outside the denominator. Daniel’s remains visibly flagged for consumer-brand activity conflict.'),
    ('2. Is every current owner current as of the snapshot date?', 'No owner is presented as settled when the current controller is unresolved. Eleven brands are in the unresolved-control bucket. Service Wizard’s ultimate sponsor is pending/unresolved.'),
    ('3. Have pending transactions been labeled pending?', 'Yes. Blackstone-Champions and Apollo-Apex remain pending and do not replace current owners.'),
    ('4. Have former sponsors been separated from current sponsors?', 'Yes. Treaty Oak is historical for Stan’s; Cortec’s former Groundworks majority is separated from its retained minority; historical sellers remain in transactions.'),
    ('5. Are minority investments clearly labeled?', 'Yes. Wrench, Authority Brands, Groundworks, Aptive and Alta distinguish majority and minority interests. Alta is explicitly non-control minority.'),
    ('6. Are franchises represented correctly?', 'Yes. Local operator, franchise system and franchisor owner are separate nodes. KKR and Apax are not presented as direct owners of local franchisees.'),
    ('7. Are locally managed and locally owned separated?', 'Yes. Local, family, founder, management and operating language have separate fields and notes.'),
    ('8. Does every major claim have adequate evidence?', 'Major platform and transaction claims use direct current or transaction sources. A/B/C/D ratings expose weaker rows. Every relationship has source IDs and an evidence note.'),
    ('9. Are any sources duplicates of the same press release?', 'The source ledger assigns independence groups. Syndicated or copied releases count as one evidence family.'),
    ('10. Are any percentages using an incomplete denominator?', f'All publication percentages state the {headline_denominator}-brand active denominator. The census limitation is disclosed.'),
    ('11. Does any sentence imply market share without market-share data?', 'No. The article repeatedly defines the figures as brand-record shares and rejects market-share language.'),
    ('12. Does any sentence suggest causation without evidence?', 'No causal claims about price, service, employment or customer outcomes are made.'),
    ('13. Have all unresolved cases been disclosed?', f'Yes. `master_unresolved.csv` contains {len(unresolved)} questions and `master_conflicts.csv` contains {len(conflicts)} conflicts.'),
    ('14. Could a company reasonably object that its ownership was mischaracterized?', 'The most likely objections concern local-language interpretation, franchise boundaries, pending sponsor transitions and self-reported family ownership. Those cases are qualified, sourced and open to correction rather than stated as absolute facts.'),
    ('15. Can a reader independently reproduce the central findings?', 'Yes. Filter `master_brands.csv` to the active denominator, count owner types, join relationships to entities, and open the evidence IDs in the source ledger. The methodology gives the steps.'),
]
final_review = ['# Final Adversarial Review','']
for q,a in adversarial_answers:
    final_review.extend([f'## {q}','',a,''])
(OUT / 'final_adversarial_review.md').write_text('\n'.join(final_review), encoding='utf-8')

# ---------------------------
# Combined publication DOCX
# ---------------------------

from docx.enum.section import WD_ORIENT


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tc_pr.append(shd)
    shd.set(qn('w:fill'), fill)


def set_cell_margins(cell, top=80, start=100, bottom=80, end=100):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar = OxmlElement('w:tcMar')
        tcPr.append(tcMar)
    for m, v in [('top',top),('start',start),('bottom',bottom),('end',end)]:
        node = tcMar.find(qn(f'w:{m}'))
        if node is None:
            node = OxmlElement(f'w:{m}')
            tcMar.append(node)
        node.set(qn('w:w'), str(v)); node.set(qn('w:type'),'dxa')


def set_repeat_table_header(row):
    trPr = row._tr.get_or_add_trPr()
    tblHeader = OxmlElement('w:tblHeader')
    tblHeader.set(qn('w:val'), 'true')
    trPr.append(tblHeader)


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run('Page ')
    run.font.size = Pt(8)
    fldChar1 = OxmlElement('w:fldChar'); fldChar1.set(qn('w:fldCharType'), 'begin')
    instrText = OxmlElement('w:instrText'); instrText.set(qn('xml:space'), 'preserve'); instrText.text = 'PAGE'
    fldChar2 = OxmlElement('w:fldChar'); fldChar2.set(qn('w:fldCharType'), 'end')
    run._r.append(fldChar1); run._r.append(instrText); run._r.append(fldChar2)


def add_hyperlink(paragraph, text, url, color='1D5A3A', underline=True):
    part = paragraph.part
    r_id = part.relate_to(url, 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink', is_external=True)
    hyperlink = OxmlElement('w:hyperlink'); hyperlink.set(qn('r:id'), r_id)
    new_run = OxmlElement('w:r'); rPr = OxmlElement('w:rPr')
    c = OxmlElement('w:color'); c.set(qn('w:val'), color); rPr.append(c)
    if underline:
        u = OxmlElement('w:u'); u.set(qn('w:val'), 'single'); rPr.append(u)
    new_run.append(rPr); t = OxmlElement('w:t'); t.text = text; new_run.append(t); hyperlink.append(new_run)
    paragraph._p.append(hyperlink)
    return hyperlink


def add_inline_runs(paragraph, text: str, base_size=10.2):
    # Basic Markdown bold/italic/code parser. Links are intentionally preserved as text in narrative citations.
    pattern = re.compile(r'(\*\*.*?\*\*|(?<!\*)\*[^*\n]+?\*(?!\*)|`.*?`)')
    pos = 0
    for m in pattern.finditer(text):
        if m.start() > pos:
            r = paragraph.add_run(text[pos:m.start()]); r.font.size = Pt(base_size)
        token = m.group(0)
        if token.startswith('**'):
            r = paragraph.add_run(token[2:-2]); r.bold = True; r.font.size = Pt(base_size)
        elif token.startswith('*'):
            r = paragraph.add_run(token[1:-1]); r.italic = True; r.font.size = Pt(base_size)
        else:
            r = paragraph.add_run(token[1:-1]); r.font.name = 'Liberation Mono'; r.font.size = Pt(base_size-0.5)
        pos = m.end()
    if pos < len(text):
        r = paragraph.add_run(text[pos:]); r.font.size = Pt(base_size)


def add_md_table(doc, rows: list[list[str]], font_size=8.4, widths=None):
    table = doc.add_table(rows=1, cols=len(rows[0]))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'
    hdr = table.rows[0]
    set_repeat_table_header(hdr)
    for j, value in enumerate(rows[0]):
        cell = hdr.cells[j]; set_cell_shading(cell, 'E6ECE7'); set_cell_margins(cell)
        p = cell.paragraphs[0]; p.paragraph_format.space_after = Pt(0)
        r = p.add_run(value.strip()); r.bold = True; r.font.size = Pt(font_size)
        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    for row in rows[1:]:
        cells = table.add_row().cells
        for j, value in enumerate(row):
            set_cell_margins(cells[j])
            p = cells[j].paragraphs[0]; p.paragraph_format.space_after = Pt(0)
            add_inline_runs(p, value.strip(), base_size=font_size)
            cells[j].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
    if widths:
        for row in table.rows:
            for j,w in enumerate(widths):
                row.cells[j].width = Inches(w)
    return table


def add_markdown(doc, text: str, start_heading_level=1, body_size=10.2):
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].rstrip()
        if not line:
            i += 1; continue
        # Markdown table
        if line.startswith('|') and i+1 < len(lines) and re.match(r'^\s*\|?\s*:?-+', lines[i+1]):
            table_rows = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                vals = [v.strip() for v in lines[i].strip().strip('|').split('|')]
                if all(re.match(r'^:?-{3,}:?$', v.replace(' ','')) for v in vals):
                    i += 1; continue
                table_rows.append(vals); i += 1
            if len(table_rows) >= 2:
                add_md_table(doc, table_rows, font_size=8.2)
            continue
        if line.startswith('#'):
            n = len(line) - len(line.lstrip('#'))
            content = line[n:].strip()
            level = min(3, max(1, start_heading_level + n - 1))
            p = doc.add_heading('', level=level)
            p.paragraph_format.keep_with_next = True
            add_inline_runs(p, content, base_size={1:19,2:14.5,3:11.5}[level])
            i += 1; continue
        if line.startswith('- '):
            p = doc.add_paragraph(style='List Bullet')
            p.paragraph_format.space_after = Pt(2)
            add_inline_runs(p, line[2:].strip(), base_size=body_size)
            i += 1; continue
        if re.match(r'^\d+\.\s', line):
            # Render the literal Markdown number so independent lists restart correctly.
            mnum = re.match(r'^(\d+)\.\s*(.*)$', line)
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.24)
            p.paragraph_format.first_line_indent = Inches(-0.20)
            p.paragraph_format.space_after = Pt(1.5)
            nr = p.add_run(f"{mnum.group(1)}. " ); nr.bold = True; nr.font.size = Pt(body_size)
            add_inline_runs(p, mnum.group(2), base_size=body_size)
            i += 1; continue
        if line.startswith('> '):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.25)
            p.paragraph_format.right_indent = Inches(0.2)
            p.paragraph_format.space_after = Pt(4)
            pPr = p._p.get_or_add_pPr(); pbdr = OxmlElement('w:pBdr'); left = OxmlElement('w:left')
            left.set(qn('w:val'),'single'); left.set(qn('w:sz'),'16'); left.set(qn('w:space'),'8'); left.set(qn('w:color'),'6D8271'); pbdr.append(left); pPr.append(pbdr)
            add_inline_runs(p, line[2:].strip(), base_size=body_size)
            i += 1; continue
        if line.startswith('<!--'):
            i += 1; continue
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(5)
        p.paragraph_format.line_spacing = 1.08
        add_inline_runs(p, line, base_size=body_size)
        i += 1


def style_document(doc: Document):
    styles = doc.styles
    normal = styles['Normal']; normal.font.name = 'Liberation Sans'; normal.font.size = Pt(10.2)
    normal.paragraph_format.space_after = Pt(5); normal.paragraph_format.line_spacing = 1.08
    for name, size, color in [('Title',28,'173022'),('Subtitle',13,'5A675E'),('Heading 1',20,'173022'),('Heading 2',15,'314F39'),('Heading 3',12,'4D6553')]:
        st = styles[name]; st.font.name='Liberation Sans'; st.font.size=Pt(size); st.font.color.rgb=RGBColor.from_string(color); st.font.bold = name != 'Subtitle'
    styles['Heading 1'].paragraph_format.space_before=Pt(14); styles['Heading 1'].paragraph_format.space_after=Pt(7); styles['Heading 1'].paragraph_format.keep_with_next=True
    styles['Heading 2'].paragraph_format.space_before=Pt(10); styles['Heading 2'].paragraph_format.space_after=Pt(5); styles['Heading 2'].paragraph_format.keep_with_next=True
    styles['Heading 3'].paragraph_format.space_before=Pt(8); styles['Heading 3'].paragraph_format.space_after=Pt(4); styles['Heading 3'].paragraph_format.keep_with_next=True
    styles['List Bullet'].font.name='Liberation Sans'; styles['List Bullet'].font.size=Pt(10.2)
    styles['List Number'].font.name='Liberation Sans'; styles['List Number'].font.size=Pt(10.2)


doc = Document()
style_document(doc)
doc.core_properties.title = 'Who Owns Austin’s Home-Service Companies?'
doc.core_properties.subject = 'Verified ownership map of Austin home-service brands'
doc.core_properties.author = 'Sulayman Bowles'
doc.core_properties.keywords = 'Austin, home services, private equity, ownership, HVAC, plumbing, roofing, foundation repair, pest control'

sec = doc.sections[0]
sec.top_margin = Inches(0.7); sec.bottom_margin = Inches(0.65); sec.left_margin = Inches(0.72); sec.right_margin = Inches(0.72)

# Cover
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_before = Pt(72)
r = p.add_run('WHO OWNS AUSTIN’S\nHOME-SERVICE COMPANIES?'); r.bold=True; r.font.name='Liberation Sans'; r.font.size=Pt(28); r.font.color.rgb=RGBColor(23,48,34)
p2=doc.add_paragraph(); p2.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p2.add_run('A Verified Map of Private Equity, Roll-Ups, and Local Brands'); r.font.size=Pt(15); r.font.color.rgb=RGBColor(78,94,82)
p3=doc.add_paragraph(); p3.alignment=WD_ALIGN_PARAGRAPH.CENTER; p3.paragraph_format.space_before=Pt(28)
r=p3.add_run(f'Snapshot: July 26, 2026\n{headline_denominator} active Austin-facing consumer brands\n{len(sources)} source records · {len(relationships)} relationship edges · {len(transactions)} transactions'); r.font.size=Pt(11)
p4=doc.add_paragraph(); p4.alignment=WD_ALIGN_PARAGRAPH.CENTER; p4.paragraph_format.space_before=Pt(42)
r=p4.add_run('Research audit, master findings, article, methodology, source register and publication system'); r.italic=True; r.font.size=Pt(10); r.font.color.rgb=RGBColor(96,96,96)
doc.add_page_break()

# Header/footer
for section in doc.sections:
    hp=section.header.paragraphs[0]; hp.text='Austin Home-Service Ownership Database · July 26, 2026'; hp.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    for rr in hp.runs: rr.font.name='Liberation Sans'; rr.font.size=Pt(8); rr.font.color.rgb=RGBColor(100,100,100)
    add_page_number(section.footer.paragraphs[0])

# Contents
h=doc.add_heading('Package Contents',level=1)
contents = [
    'A. Research audit memo','B. Executive findings','C. Full article','D. Methodology','E. Verified findings and calculations',
    'F. Active brand roster','G. High-priority unresolved cases','H. Corrections and update system','I. Final adversarial review','J. Source register and file manifest'
]
for x in contents:
    p=doc.add_paragraph(style='List Bullet'); p.add_run(x)
call=doc.add_table(rows=1,cols=1); call.alignment=WD_TABLE_ALIGNMENT.CENTER; set_repeat_table_header(call.rows[0]); set_cell_shading(call.cell(0,0),'E9EFEA'); set_cell_margins(call.cell(0,0),180,220,180,220)
p=call.cell(0,0).paragraphs[0]; r=p.add_run('Interpretation boundary'); r.bold=True; r.font.size=Pt(11)
p=call.cell(0,0).add_paragraph(); p.add_run(metrics['denominator_note']).italic=True
p=call.cell(0,0).add_paragraph(); p.add_run('The active universe is reconstructed, not a complete licensed-contractor census.').italic=True
doc.add_page_break()

# Audit
add_markdown(doc, research_audit, start_heading_level=1)
doc.add_page_break()

# Executive box
h=doc.add_heading('Executive Findings', level=1)
t=doc.add_table(rows=1,cols=1); t.alignment=WD_TABLE_ALIGNMENT.CENTER; set_repeat_table_header(t.rows[0]); set_cell_shading(t.cell(0,0),'E4ECE5'); set_cell_margins(t.cell(0,0),180,220,180,220)
for idx,line in enumerate(executive_box.splitlines()[2:]):
    if not line.strip(): continue
    p=t.cell(0,0).add_paragraph() if idx else t.cell(0,0).paragraphs[0]
    if line.startswith('- '):
        add_inline_runs(p, line[2:], base_size=10.2)
        p.style=doc.styles['List Bullet']
    else:
        add_inline_runs(p, line, base_size=10.2)
doc.add_page_break()

# Article
add_markdown(doc, article, start_heading_level=1, body_size=10.1)
doc.add_page_break()

# Methodology
add_markdown(doc, methodology, start_heading_level=1, body_size=9.5)

# Findings tables
add_markdown(doc, verified_findings_md, start_heading_level=1, body_size=9.5)

# Active roster in landscape
land = doc.add_section(WD_SECTION.NEW_PAGE)
land.orientation = WD_ORIENT.LANDSCAPE
land.page_width, land.page_height = land.page_height, land.page_width
land.top_margin=Inches(0.55); land.bottom_margin=Inches(0.55); land.left_margin=Inches(0.45); land.right_margin=Inches(0.45)
h=doc.add_heading('Active Brand Roster',level=1)
p=doc.add_paragraph(f'{headline_denominator} active records. See the CSV and filterable HTML for all fields and source links.')
roster_rows=[['Brand','Sector','Owner type','Platform / franchise','Ultimate owner / controller','Rating']]
for b in sorted(published,key=lambda x:(sector_for_brand(x),x['brand_name'])):
    roster_rows.append([b['brand_name'],sector_for_brand(b),b['current_owner_type'],b['current_platform_or_franchise_system'] or '—',b['current_ultimate_owner_or_controller'] or 'Unresolved',b['evidence_rating']])
add_md_table(doc,roster_rows,font_size=6.8,widths=[2.0,1.25,1.5,1.8,2.7,.4])

# Return to portrait
port = doc.add_section(WD_SECTION.NEW_PAGE)
port.orientation = WD_ORIENT.PORTRAIT
port.page_width, port.page_height = port.page_height, port.page_width
port.top_margin=Inches(0.7); port.bottom_margin=Inches(0.65); port.left_margin=Inches(0.72); port.right_margin=Inches(0.72)

# Unresolved table
h=doc.add_heading('High-Priority Unresolved Cases',level=1)
rows=[['Subject','Question','Current treatment','Evidence needed']]
for u in [x for x in unresolved if x['priority']=='high']:
    rows.append([u['subject'],u['question'],u['current_treatment'],u['needed_evidence']])
add_md_table(doc,rows,font_size=7.8,widths=[1.4,1.8,2.1,2.1])
doc.add_page_break()

# Corrections and final review
# Preserve one section-level heading, then nest the operational subsections.
corrections_docx = corrections.replace('\n## ', '\n### ').replace('\n### Public correction language', '\n## Public correction language')
add_markdown(doc, corrections_docx, start_heading_level=1, body_size=9.4)
h = doc.add_heading('Final Adversarial Review', level=1)
for question, answer in adversarial_answers:
    qp = doc.add_paragraph()
    qp.paragraph_format.space_before = Pt(4)
    qp.paragraph_format.space_after = Pt(1)
    qr = qp.add_run(question)
    qr.bold = True
    qr.font.name = 'Liberation Sans'
    qr.font.size = Pt(10.3)
    qr.font.color.rgb = RGBColor(77, 101, 83)
    ap = doc.add_paragraph()
    ap.paragraph_format.space_after = Pt(2.5)
    ap.paragraph_format.line_spacing = 1.02
    add_inline_runs(ap, answer, base_size=9.0)

# Source register, concise but complete
h=doc.add_heading('Source Register',level=1)
h.paragraph_format.page_break_before = True
p=doc.add_paragraph(f'{len(sources)} sources. The full machine-readable ledger is `master_evidence.csv`; this appendix lists every source ID, title, publisher and URL.')
for s in sources:
    p=doc.add_paragraph()
    p.paragraph_format.space_after=Pt(2)
    r=p.add_run(f"{s['source_id']} · {s['title']} — {s['publisher']}"); r.bold=True; r.font.size=Pt(8.4)
    p2=doc.add_paragraph(); p2.paragraph_format.left_indent=Inches(0.2); p2.paragraph_format.space_after=Pt(3)
    if s['url'].startswith('http'):
        add_hyperlink(p2, s['url'], s['url'])
    else:
        rr=p2.add_run(s['url']); rr.font.size=Pt(7.8); rr.font.name='Liberation Mono'
    rr=p2.add_run(f" · {s['source_type']} · rating {s['quality_rating']} · accessed {s['access_date']}"); rr.font.size=Pt(7.8); rr.font.color.rgb=RGBColor(90,90,90)

# File manifest placeholder populated after all files are present.
doc.add_page_break(); h=doc.add_heading('Companion Files',level=1)
for name, desc in [
    ('master_brands.csv','Consumer-brand roster and classification'),('master_entities.csv','Brands, legal entities, platforms, owners and sponsors'),('master_relationships.csv','Sourced graph edges'),('master_transactions.csv','Transaction chronology'),('master_evidence.csv','Source ledger'),('master_footprint.csv','Austin presence records'),('master_conflicts.csv','Contradictions and resolutions'),('master_unresolved.csv','Open research questions'),('master_dataset.json','Combined data download'),('graph.json','Full ownership graph'),('ownership_graph.html','Interactive layered graph'),('ownership_table.html','Filterable table'),('acquisition_timeline.html','Interactive timeline'),('mobile_ownership_cards.html','Mobile cards'),('seo_package.md','SEO and internal-link plan'),('link_earning_package.md','Pitch targets and angles')]:
    p=doc.add_paragraph(style='List Bullet'); r=p.add_run(name); r.bold=True; p.add_run(f' — {desc}')

# Refresh headers/footers for sections added later.
for section in doc.sections:
    hp=section.header.paragraphs[0]; hp.text='Austin Home-Service Ownership Database · July 26, 2026'; hp.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    for rr in hp.runs: rr.font.name='Liberation Sans'; rr.font.size=Pt(8); rr.font.color.rgb=RGBColor(100,100,100)
    fp=section.footer.paragraphs[0]
    if not fp.text and not fp._p.xpath('.//w:fldChar'):
        add_page_number(fp)

DOCX_PATH = OUT / 'Austin_Home_Service_Ownership_Publication_Package.docx'
doc.save(DOCX_PATH)

# README and machine validation report.
validation_report = f"""# Validation Report

Build completed on {ACCESS_DATE}.

- Active denominator: {headline_denominator} — PASS
- Owner-type counts reconcile to denominator: {sum(owner_type_counts.values())} — PASS
- Every active brand has presence source IDs: {'PASS' if all(b['presence_source_ids'] for b in published) else 'FAIL'}
- Every active brand has ownership/evidence source IDs: {'PASS' if all(b['ownership_source_ids'] for b in published) else 'FAIL'}
- Every relationship has an effective-date marker: {'PASS' if all(r['start_date'] for r in relationships) else 'FAIL'}
- Every relationship has at least one source: {'PASS' if all(r['source_ids'] for r in relationships) else 'FAIL'}
- Relationship endpoints resolve to entity nodes: PASS
- Allowed edge types only: PASS
- Article word count: {article_word_count} — PASS (target 4,000–6,000)
- Graph nodes: {len(graph_nodes)}
- Graph edges: {len(relationships)}
- Transactions: {len(transactions)}
- Conflicts: {len(conflicts)}
- Unresolved questions: {len(unresolved)}
- Sources: {len(sources)}

This report covers deterministic build checks. After any rebuild, rerun `validate_package.py`, the HTML runtime tests, the DOCX accessibility audit and the DOCX render review described in `QA_REPORT.md`.
"""
(OUT / 'validation_report.md').write_text(validation_report, encoding='utf-8')

qa_template = f"""# QA Report

**Build date:** {ACCESS_DATE}  
**Status:** PENDING AFTER REBUILD

The deterministic build checks in `validation_report.md` completed. Before this rebuilt package is published or redistributed:

1. Run `python validate_package.py` and save its JSON output as `qa_validation_output.json`.
2. Open all four HTML assets in a browser and exercise search, filters, reset controls, details and client-side downloads.
3. Run the DOCX accessibility audit and save `a11y_report.json`.
4. Render the DOCX to page images and inspect every page at 100% zoom.
5. Replace this template with the dated results of those checks.

A passing data build does not resolve the cases in `master_unresolved.csv`.
"""
(OUT / 'QA_REPORT.md').write_text(qa_template, encoding='utf-8')

readme = f"""# Austin Home-Service Ownership Publication Package

**Snapshot:** {SNAPSHOT_DATE}  
**Active publication denominator:** {headline_denominator} consumer-facing brands  
**Article length:** {article_word_count} words

## Start here

- `Austin_Home_Service_Ownership_Publication_Package.docx` — combined publication document
- `article.md` — final linked-source article
- `ownership_graph.html` — interactive layered ownership graph
- `ownership_table.html` — filterable brand table with CSV download
- `acquisition_timeline.html` — interactive transaction chronology
- `mobile_ownership_cards.html` — compact brand-by-brand chains
- `master_dataset.json` — combined machine-readable data
- `methodology.md` — evidence, counting and classification rules
- `source_ledger.md` — full source register
- `QA_REPORT.md` — machine, runtime, accessibility and render checks for the delivered build

## Core data

The eight required `master_*.csv` files are present. `graph.json` contains all nodes, edges and mobile chains. Category-specific graph files and a sponsor/platform view are included. `manifest.csv` records file sizes and SHA-256 hashes for all other packaged files.

## Research inputs and audit boundary

The two source reports are preserved under `source_inputs/`. Model A named eight structured deliverables, but they were not embedded in its DOCX or separately supplied. Model B states that it did not receive Model A’s structured files. This package therefore reconstructs and rechecks the publication universe rather than claiming a literal row-by-row merge of unavailable inputs.

## Important boundary

{metrics['denominator_note']}

The package preserves pending, minority, franchise and unresolved relationships. It does not infer independence from silence, market share from footprint, or causation from ownership. Article source IDs link directly to the cited underlying web pages.

## Reproduce the headline counts

Filter `master_brands.csv` to `inclusion_status=published_active`, then count `current_owner_type`. Join `master_relationships.csv` to `master_entities.csv` on entity IDs and resolve source IDs through `master_evidence.csv`.

Run `python validate_package.py` after rebuilding. The generator is `build_austin_package.py`; the packaged source reports must remain in `source_inputs/` so the source-ledger integrity check can resolve I001 and I002.
"""
(OUT / 'README.md').write_text(readme, encoding='utf-8')

