# Validation Report

Delivered build validated on 2026-07-26.

- Active denominator: 67 — PASS
- Owner-type counts reconcile to denominator: 67 — PASS
- Every active brand has current Austin-presence evidence: PASS
- Every active brand has ownership evidence or a documented unresolved-current-owner basis: PASS
- Every relationship has an effective-date marker, current-status flag, evidence rating, source ID, access date and evidence note: PASS
- Relationship endpoints resolve to entity nodes: PASS
- Allowed edge types only: PASS
- Article word count excluding linked URLs: 4,255 — PASS (target 4,000–6,000)
- Linked article citations: 179 — PASS
- Graph nodes: 170
- Graph edges: 102
- Transactions: 29
- Conflicts: 20
- Unresolved questions: 25
- Sources: 130
- Machine-readable JSON and CSV integrity checks: PASS
- HTML JavaScript syntax and browser runtime tests: PASS
- DOCX ZIP/OOXML integrity: PASS
- DOCX accessibility: 0 high-severity and 0 medium-severity findings — PASS
- DOCX render: 30 pages rendered and visually inspected — PASS

The 128 low-severity accessibility findings are raw URL link-text warnings in the source register. Full URLs are retained there so readers can reproduce the research and inspect the precise cited pages.
