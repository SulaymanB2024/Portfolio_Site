# Publication Assets Index

1. **Final article:** `article.md`
2. **Executive findings box:** `executive_findings_box.md`
3. **Interactive graph:** `ownership_graph.html`, `graph.json`, category JSON files, sponsor view JSON
4. **Filterable ownership table:** `ownership_table.html`
5. **Downloadable CSVs:** eight `master_*.csv` files
6. **Downloadable JSON:** `master_dataset.json`, `graph.json`, `ownership_cards.json`
7. **Acquisition timeline:** `acquisition_timeline.html`, `acquisition_timeline.md`
8. **Methodology page:** `methodology.md`
9. **Source ledger:** `master_evidence.csv`, `source_ledger.md`
10. **Correction language:** `corrections_and_updates.md`
11. **Changelog:** `changelog.md`
12. **Mobile ownership cards:** `mobile_ownership_cards.html`, `mobile_ownership_cards.md`, `ownership_cards.json`
13. **Chart captions and alt text:** `chart_captions_alt_text.md`
14. **Social and newsletter copy:** `social_newsletter_summaries.md`
15. **Reporter brief:** `reporter_outreach_brief.md`
16. **SEO package:** `seo_package.md`
17. **Link-earning package:** `link_earning_package.md`
18. **Audit and findings:** `research_audit_memo.md`, `verified_findings.md`, `unresolved_and_rejected_claims.md`
19. **Final adversarial review:** `final_adversarial_review.md`
20. **Combined publication DOCX:** `Austin_Home_Service_Ownership_Publication_Package.docx`
