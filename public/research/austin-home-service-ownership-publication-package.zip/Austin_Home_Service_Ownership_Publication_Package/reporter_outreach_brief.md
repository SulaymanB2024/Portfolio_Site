# Reporter Outreach Brief

## Story in one sentence

A source-linked map of 67 Austin-facing home-service brands shows how retained local names, sponsor-backed platforms, public parents and local franchises overlap, while preserving 11 unresolved ownership cases instead of forcing an answer.

## Cleanest examples

- **Fox, Precision and Daniel’s:** separate consumer names inside Southern Home Services and the Gryphon-backed NAEHS structure.
- **Austin Air Conditioning and Roger’s Plumbing:** current SAS Service Partners brands backed by Storr Group; Cool Atmosphere is absorbed rather than counted twice.
- **Ja-Mar:** acquired by a Dunes Point-backed platform while current local wording remains on the brand site.
- **Alta:** Trivest minority, non-control investment; founders retained control.
- **Mr. Rooter Austin:** locally owned franchise; KKR owns Neighborly, not the Austin operating company.

## Numbers that can be quoted with the denominator

- 67 active Austin-facing consumer-brand records.
- 14 sponsor-backed platform brands.
- 4 public-company-owned brands.
- 5 local franchise records.
- 11 private/control-unresolved records.
- 48 A/B, non-unresolved ownership structures.

Every number above is a share or count of brand records, not market share.

## What not to say

- Do not say private equity controls a stated percentage of Austin home-service revenue.
- Do not say an ownership structure caused price or service changes.
- Do not describe a franchisor sponsor as the local franchisee’s direct owner.
- Do not call Blackstone the current Champions owner without closing evidence.

## Available assets

Interactive graph, filterable table, transaction timeline, full CSV/JSON download, methodology, source ledger, conflict table and correction system.
