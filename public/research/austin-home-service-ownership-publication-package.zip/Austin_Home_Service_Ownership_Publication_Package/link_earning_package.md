# Link-Earning and Outreach Package

| Target category | Finding likely to interest them | Asset to send | Outreach angle | Reason not to pitch |
|---|---|---|---|---|
| Austin business reporters | Multiple retained local brands lead to a small set of platforms; SAS/Storr was a missed cluster | Interactive graph + transaction timeline | A reproducible local consolidation map with dated ownership chains | Do not pitch a generic “PE is taking over” claim; the data does not measure market share |
| Austin consumer and housing reporters | “Local” can mean ownership, management, history or franchise operation | Article section + mobile cards | Help homeowners understand who is behind a familiar service name | Avoid service-quality or pricing claims without separate evidence |
| Texas business publications | Sponsor, public-parent and local-family ownership coexist in the same market | Dataset + sponsor/platform graph | Texas home-services M&A shown at the consumer-brand level | Do not overstate completeness outside Austin |
| HVAC and plumbing trade publications | Southern, T3, MTG, Wrench, SAS, ARS and Service Experts use different platform structures | HVAC graph + timeline | A local case study in retained brands and capital structures | Avoid ranking operators by size |
| Roofing trade publications | Ja-Mar’s retained name and current local wording sit inside a documented platform acquisition | Ja-Mar card + roofing graph | Precise treatment of retained local brands after acquisition | Do not imply the wording is deceptive |
| Foundation-repair trade publications | KKR/Cortec control split at Groundworks; several local controllers remain unresolved | Foundation graph + unresolved table | Where public ownership evidence is strong and where it fails | Avoid presenting the list as a complete contractor census |
| Pest-control trade publications | Alta’s non-control minority investment differs from Aptive, Rollins and Rentokil structures | Pest graph + Alta card | Majority, minority, public and family structures in one local market | Do not collapse Trivest into control |
| Private-equity and M&A publications | Brand count differs from platform count; pending and minority deals are preserved | Sponsor graph + master transactions CSV | A transaction-quality data model for local roll-up research | Do not pitch brand-record shares as market penetration |
| Consumer advocates | Franchise and local-language distinctions affect how consumers interpret identity | Franchise cards + methodology | A neutral ownership disclosure tool | Do not claim consumer harm from ownership alone |
| Home inspectors | Foundation, roofing and pest vendor identities can be obscured by brands and franchises | Filterable table | A reference for explaining vendor relationships to clients | Do not ask for endorsement of unresolved records |
| Real-estate agents and brokerages | Homeowners routinely hire these categories during transactions | Mobile cards + article | A practical ownership reference for vendor due diligence | Avoid turning the dataset into a preferred-vendor list |
| Local chambers and business groups | The database preserves real local operators and distinguishes them from platforms | Category table + correction form | Invite documented corrections and local entity evidence | Do not imply chamber membership proves ownership |
| Academic and policy researchers | Transparent brand/entity graph and source-independence fields | Full CSV/JSON package + methodology | Reusable local consolidation dataset with explicit limits | Do not claim causal effects or complete market coverage |

## Best initial pitches

1. **Austin business desk:** Three familiar Austin brands, one Southern/Gryphon chain; two SAS/Storr brands missed by the initial census.
2. **Trade press:** Alta’s minority non-control structure versus Aptive’s majority transaction and Rollins/Rentokil public ownership.
3. **M&A press:** A reproducible rule for separating current, former, pending, majority, minority and franchise relationships.
4. **Consumer desk:** Why a locally operated or family-founded brand may not be locally owned today.

## Evidence package to attach

- One screenshot or live link to the filtered graph
- Relevant brand card
- Transaction row
- Two or three direct source IDs
- Methodology paragraph on the claim being pitched
- Correction contact and changelog link

Never lead with a percentage unless the denominator is stated in the same sentence.
