# Mobile Ownership Cards

**Snapshot:** 2026-07-26  
**Active cards:** 67

Each card separates the consumer brand, immediate platform or franchise system, ultimate owner/controller, interest type, status and evidence.

## Advanced Foundation Repair

**Chain:** Advanced Foundation Repair → Advanced Foundation Repair, LP → Current controller unresolved  
**Category:** Foundation repair  
**Owner type:** Private/control unresolved  
**Interest:** legal entity and current Austin operation verified; controller not established  
**Status:** unresolved_control  
**Evidence:** D — S132, S133  
**Local wording:** none relied upon  

## All in One Foundation Repair

**Chain:** All in One Foundation Repair → Robert J. Knight  
**Category:** Foundation repair  
**Owner type:** Founder/family/local ownership  
**Interest:** owner identified by business profile; local claim current  
**Status:** verified_local_owner  
**Evidence:** B — S136, S137  
**Local wording:** locally owned  

## Baird Foundation Repair

**Chain:** Baird Foundation Repair → John Baird and Melanie Baird  
**Category:** Foundation repair  
**Owner type:** Founder/family/local ownership  
**Interest:** sole owners stated in current company material  
**Status:** verified_current_chain  
**Evidence:** A — S134  
**Local wording:** family owned  

## Bats Foundation Repair

**Chain:** Bats Foundation Repair → Brent Parks  
**Category:** Foundation repair  
**Owner type:** Founder/family/local ownership  
**Interest:** principal owner/managing member identified  
**Status:** verified_current_chain  
**Evidence:** A — S138  
**Local wording:** locally owned  

## Bruecher Foundation

**Chain:** Bruecher Foundation → Bruecher family / local owners  
**Category:** Foundation repair  
**Owner type:** Founder/family/local ownership  
**Interest:** family-business claim current; exact equity holders unresolved  
**Status:** self_reported_local_current  
**Evidence:** C — S142  
**Local wording:** family owned  

## CenTex Foundation Repair

**Chain:** CenTex Foundation Repair → Current controller unresolved  
**Category:** Foundation repair  
**Owner type:** Private/control unresolved  
**Interest:** founder history and current operation known; present equity unclear  
**Status:** unresolved_control  
**Evidence:** D — S130  
**Local wording:** founder history only  

## Douglas Foundation Repair

**Chain:** Douglas Foundation Repair → Current controller unresolved  
**Category:** Foundation repair  
**Owner type:** Private/control unresolved  
**Interest:** current Austin operation verified; controller not established  
**Status:** unresolved_control  
**Evidence:** D — S131  
**Local wording:** none relied upon  

## G.L. Hunt Foundation Repair

**Chain:** G.L. Hunt Foundation Repair → Gary Hunt / Hunt family  
**Category:** Foundation repair  
**Owner type:** Founder/family/local ownership  
**Interest:** family ownership stated in current company materials  
**Status:** verified_local_owner  
**Evidence:** B — S135  
**Local wording:** family owned  

## Groundworks

**Chain:** Groundworks → Groundworks Companies, LLC → KKR; Cortec retains minority positions  
**Category:** Foundation repair  
**Owner type:** Sponsor-backed platform  
**Interest:** KKR controlling/majority; Cortec minority  
**Status:** verified_current_chain  
**Evidence:** A — S048, S049, S050  
**Local wording:** national platform serving Austin  

## Olshan Foundation Repair

**Chain:** Olshan Foundation Repair → Current controlling owner unresolved  
**Category:** Foundation repair  
**Owner type:** Private/control unresolved  
**Interest:** current Austin presence verified; controller not established  
**Status:** unresolved_control  
**Evidence:** D — S128  
**Local wording:** no local/family label assigned  

## Quality Foundation Repair

**Chain:** Quality Foundation Repair → Simon Wallace  
**Category:** Foundation repair  
**Owner type:** Founder/family/local ownership  
**Interest:** founder/owner identified by current independent profile and active business evidence  
**Status:** verified_local_owner  
**Evidence:** B — S139, S140, S141  
**Local wording:** local operator  
**Note:** Reverses Model A’s exclusion. The company has a current Austin address, active official site, and a named founder/owner trail.  

## Ram Jack Austin

**Chain:** Ram Jack Austin → Ram Jack franchise system → Local franchisee identity unresolved  
**Category:** Foundation repair  
**Owner type:** Local franchise operator  
**Interest:** independently owned franchise; local owner unresolved  
**Status:** verified_franchisor_local_operator_unresolved  
**Evidence:** B — S129  
**Local wording:** independently owned and operated franchise  

## ABC Home & Commercial Services

**Chain:** ABC Home & Commercial Services → Jenkins family / Bobby Jenkins  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Founder/family/local ownership  
**Interest:** controlling family ownership stated; exact cap table not public  
**Status:** verified_current_chain  
**Evidence:** B — S100  
**Local wording:** locally owned and operated; family owned  

## ARS/Rescue Rooter Austin

**Chain:** ARS/Rescue Rooter Austin → American Residential Services, LLC → GI Partners; Charlesbank and management retain significant interests  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Sponsor-backed platform  
**Interest:** GI Partners majority; Charlesbank and management significant minority  
**Status:** verified_current_chain  
**Evidence:** A — S026, S027, S028  
**Local wording:** national platform brand  

## Abacus Plumbing, Air Conditioning & Electrical

**Chain:** Abacus Plumbing, Air Conditioning & Electrical → Wrench Group, LLC → Leonard Green & Partners and management; TSG Consumer Partners and Oak Hill minority  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Sponsor-backed platform  
**Interest:** Leonard Green and management majority; TSG and Oak Hill significant minority  
**Status:** verified_current_chain  
**Evidence:** A — S015, S016, S017  
**Local wording:** retained consumer brand within platform  

## AirFix Mechanical

**Chain:** AirFix Mechanical → AirFix Mechanical, LLC → Exact equity owner unresolved  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Founder/family/local ownership  
**Interest:** current legal entity and local operation verified; controller unresolved  
**Status:** verified_entity_control_unresolved  
**Evidence:** C — S116  
**Local wording:** locally owned claim  

## Aire Serv of Cedar Park

**Chain:** Aire Serv of Cedar Park → Neighborly / Aire Serv franchise system → Local franchisee legal identity unresolved; KKR owns Neighborly franchisor  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Local franchise operator  
**Interest:** local franchisee; franchisor sponsor ownership separate  
**Status:** verified_franchisor_local_operator_partial  
**Evidence:** B — S034, S030, S036  
**Local wording:** independently owned/operated franchise  

## Aire Serv of Round Rock

**Chain:** Aire Serv of Round Rock → Neighborly / Aire Serv franchise system → Chris Rattray local owner/operator; KKR owns Neighborly franchisor  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Local franchise operator  
**Interest:** local franchisee ownership; franchisor sponsor ownership separate  
**Status:** verified_franchise_structure  
**Evidence:** A — S035, S030, S036  
**Local wording:** locally owned/operated franchise  

## Austin Air Conditioning

**Chain:** Austin Air Conditioning → SAS Service Partners → Storr Group  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Sponsor-backed platform  
**Interest:** Storr-backed platform; seller rollover equity documented  
**Status:** verified_current_chain  
**Evidence:** A — S041, S037, S040, S044  
**Local wording:** locally operated retained brand after acquisition  

## Austin Major Air & Heat

**Chain:** Austin Major Air & Heat → Adoni Enterprises, Inc. (alternate legal identity lead) → Current controller unresolved  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Private/control unresolved  
**Interest:** operating identity lead only  
**Status:** unresolved_control  
**Evidence:** D — S117  
**Local wording:** none relied upon  
**Note:** Included as a current operating company, but not classified as independent or locally owned without stronger current equity evidence.  

## Benjamin Franklin Plumbing of Austin

**Chain:** Benjamin Franklin Plumbing of Austin → Authority Brands / Benjamin Franklin Plumbing → Local franchisee unresolved; Apax majority and BCI minority at franchisor level  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Local franchise operator  
**Interest:** franchisee interest unresolved; Apax majority/BCI minority at franchisor  
**Status:** verified_franchisor_local_operator_unresolved  
**Evidence:** B — S033, S031, S032  
**Local wording:** locally operated franchise; owner name unresolved  

## Christianson Air Conditioning & Plumbing

**Chain:** Christianson Air Conditioning & Plumbing → Christianson family  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Founder/family/local ownership  
**Interest:** family ownership stated; exact current equity allocation not public  
**Status:** self_reported_local_current  
**Evidence:** B — S109  
**Local wording:** family owned  

## Crow’s Plumbing Service

**Chain:** Crow’s Plumbing Service → Jack Crow  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Founder/family/local ownership  
**Interest:** managing member identified; current company and license evidence  
**Status:** verified_local_owner  
**Evidence:** B — S114, S115  
**Local wording:** local operator  

## Daniel’s Plumbing & Air Conditioning

**Chain:** Daniel’s Plumbing & Air Conditioning → Southern Home Services → Gryphon Investors via North American Essential Home Services  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Sponsor-backed platform  
**Interest:** Gryphon majority; management meaningful minority at holding-company level  
**Status:** verified_chain_brand_activity_conflict  
**Evidence:** A — S004, S003, S005, S006, S007  
**Local wording:** retained Austin brand after acquisition  
**Note:** Southern’s current brand page and site map list Daniel’s. Consumer-facing routing/brand consolidation signals remain inconsistent, so the brand is counted as current-facing but flagged.  

## Efficient AC, Electric & Plumbing

**Chain:** Efficient AC, Electric & Plumbing → George Drazic and Molly Drazic  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Founder/family/local ownership  
**Interest:** current owners identified by company  
**Status:** verified_current_chain  
**Evidence:** A — S107  
**Local wording:** 100% local ownership stated  

## Excalibur Plumbing

**Chain:** Excalibur Plumbing → Excalibur Plumbing, LLC → Blake Smith  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Founder/family/local ownership  
**Interest:** managing member/owner evidence  
**Status:** verified_current_chain  
**Evidence:** A — S110, S111  
**Local wording:** locally owned  

## Fox Service Company

**Chain:** Fox Service Company → Southern Home Services → Gryphon Investors via North American Essential Home Services  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Sponsor-backed platform  
**Interest:** Gryphon majority; management meaningful minority at holding-company level  
**Status:** verified_current_chain  
**Evidence:** A — S101, S002, S005, S006, S007  
**Local wording:** retained Austin brand after acquisition  

## Goettl Air Conditioning & Plumbing

**Chain:** Goettl Air Conditioning & Plumbing → Cortec Group  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Sponsor-backed platform  
**Interest:** control percentage not publicly specified  
**Status:** verified_current_chain  
**Evidence:** B — S018, S019  
**Local wording:** national platform brand; Dayton Services rebranded  

## McCullough Heating & Air Conditioning

**Chain:** McCullough Heating & Air Conditioning → Local ownership asserted; exact current equity holders unresolved  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Founder/family/local ownership  
**Interest:** current local ownership claim; president identified, exact cap table unavailable  
**Status:** self_reported_local_current  
**Evidence:** B — S105, S106  
**Local wording:** locally owned  

## Mr. Rooter Plumbing of Austin

**Chain:** Mr. Rooter Plumbing of Austin → Neighborly / Mr. Rooter franchise system → Brett Bidwell owns local franchisee; KKR owns Neighborly franchisor  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Local franchise operator  
**Interest:** local franchisee ownership; franchisor separately sponsor-owned  
**Status:** verified_franchise_structure  
**Evidence:** A — S029, S030  
**Local wording:** locally owned franchise  

## Precision Heating & Air

**Chain:** Precision Heating & Air → Southern Home Services → Gryphon Investors via North American Essential Home Services  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Sponsor-backed platform  
**Interest:** Gryphon majority; management meaningful minority at holding-company level  
**Status:** verified_current_chain  
**Evidence:** A — S102, S001, S005, S006, S007  
**Local wording:** retained Austin brand after acquisition  

## Radiant Plumbing, Air Conditioning & Electrical

**Chain:** Radiant Plumbing, Air Conditioning & Electrical → T3 Services Group → The Riverside Company  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Sponsor-backed platform  
**Interest:** investment/control percentage not publicly specified  
**Status:** verified_current_chain  
**Evidence:** A — S103, S008, S009, S010  
**Local wording:** retained Austin brand after investment  

## Reliant Plumbing

**Chain:** Reliant Plumbing → Max Hicks / Hicks family  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Founder/family/local ownership  
**Interest:** founder/family ownership stated; exact cap table not public  
**Status:** verified_local_owner  
**Evidence:** B — S108  
**Local wording:** family owned and locally operated  

## Roger’s Plumbing

**Chain:** Roger’s Plumbing → SAS Service Partners → Storr Group  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Sponsor-backed platform  
**Interest:** Storr-backed platform; founder joined platform  
**Status:** verified_current_chain  
**Evidence:** A — S042, S038, S040  
**Local wording:** retained Leander/Austin brand after acquisition  

## Service Wizard Heating & Air Conditioning

**Chain:** Service Wizard Heating & Air Conditioning → Champions Group Holdings → Ultimate sponsor unresolved at snapshot; last closed sponsor Odyssey, Blackstone acquisition announced  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Sponsor-backed platform  
**Interest:** platform acquisition verified; sponsor transfer pending/unconfirmed  
**Status:** verified_platform_ultimate_owner_pending  
**Evidence:** B — S025, S023, S024  
**Local wording:** retained Austin brand after acquisition  
**Note:** No public closing confirmation was located for the announced Blackstone transaction by the July 26, 2026 snapshot.  

## Stan’s Heating, Air, Plumbing & Electrical

**Chain:** Stan’s Heating, Air, Plumbing & Electrical → The Master Trades Group → L Catterton  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Sponsor-backed platform  
**Interest:** L Catterton control through Master Trades Group  
**Status:** verified_current_chain  
**Evidence:** A — S104, S011, S013, S014  
**Local wording:** retained Austin brand after acquisition  

## Strand Brothers Service Experts

**Chain:** Strand Brothers Service Experts → Service Experts / Enercare → Brookfield Infrastructure  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Public-company owned  
**Interest:** wholly owned within Brookfield-controlled Enercare structure  
**Status:** verified_current_chain  
**Evidence:** A — S021, S020, S022  
**Local wording:** retained local name within national platform  

## Whitestone Plumbing

**Chain:** Whitestone Plumbing → Ben Helton  
**Category:** HVAC, plumbing and electrical  
**Owner type:** Founder/family/local ownership  
**Interest:** owner identified by current business profile; company asserts local ownership  
**Status:** verified_local_owner  
**Evidence:** B — S112, S113  
**Local wording:** locally owned  

## A-Tex Pest Management

**Chain:** A-Tex Pest Management → Local ownership asserted; exact equity holders unresolved  
**Category:** Pest control  
**Owner type:** Founder/family/local ownership  
**Interest:** current local claim and president/CEO lead; cap table unavailable  
**Status:** self_reported_local_current  
**Evidence:** C — S143, S144  
**Local wording:** locally owned  

## Absolute Pest Management

**Chain:** Absolute Pest Management → Tony Ragan / Ragan family  
**Category:** Pest control  
**Owner type:** Founder/family/local ownership  
**Interest:** president and family ownership stated  
**Status:** verified_local_owner  
**Evidence:** B — S166  
**Local wording:** locally family owned  

## Alta Pest Control

**Chain:** Alta Pest Control → Founders retain control; Trivest Partners is minority investor  
**Category:** Pest control  
**Owner type:** Minority-invested, founder-controlled  
**Interest:** Trivest non-control minority; founders retain operational and financial control  
**Status:** verified_current_chain  
**Evidence:** A — S149, S054  
**Local wording:** Austin-founded company with minority outside capital  

## Aptive Environmental

**Chain:** Aptive Environmental → Citation Capital; management retains significant interest  
**Category:** Pest control  
**Owner type:** Sponsor-backed platform  
**Interest:** Citation majority; management significant minority  
**Status:** verified_current_chain  
**Evidence:** A — S053, S052  
**Local wording:** national branch  

## Berrett Home Services / Berrett Pest Control

**Chain:** Berrett Home Services / Berrett Pest Control → Nathan Berrett / Berrett family  
**Category:** Pest control  
**Owner type:** Founder/family/local ownership  
**Interest:** founder/president and family operation identified  
**Status:** verified_current_chain  
**Evidence:** A — S147, S148  
**Local wording:** family owned and operated  

## Bulwark Exterminating

**Chain:** Bulwark Exterminating → Seever family  
**Category:** Pest control  
**Owner type:** Founder/family/local ownership  
**Interest:** family ownership stated in current company material  
**Status:** verified_local_owner  
**Evidence:** B — S146  
**Local wording:** family owned  

## ClearDefense Pest Control

**Chain:** ClearDefense Pest Control → Founders John-Mark Bolton, Chris Cunningham and Jason Brown; current allocation not public  
**Category:** Pest control  
**Owner type:** Founder/family/local ownership  
**Interest:** founder-led company; current cap table not public  
**Status:** verified_founder_led_partial  
**Evidence:** B — S164  
**Local wording:** founder led  

## EcoShield Pest Solutions

**Chain:** EcoShield Pest Solutions → Current Austin operator/controller unresolved  
**Category:** Pest control  
**Owner type:** Private/control unresolved  
**Interest:** current brand presence verified; 2015 divisional sale does not establish current brand ownership  
**Status:** unresolved_control_historical_conflict  
**Evidence:** D — S158, S059  
**Local wording:** national/multi-market branch  

## Hawx Pest Control

**Chain:** Hawx Pest Control → Hawx Services → Last documented sponsor PCM Growth/PCM Encore; current continuity unresolved  
**Category:** Pest control  
**Owner type:** Private/control unresolved  
**Interest:** 2021 acquisition documented; current controller not independently reconfirmed  
**Status:** unresolved_current_sponsor  
**Evidence:** D — S155, S058  
**Local wording:** national/multi-market branch  

## HomeTeam Pest Defense

**Chain:** HomeTeam Pest Defense → Rollins, Inc.  
**Category:** Pest control  
**Owner type:** Public-company owned  
**Interest:** wholly owned public-company subsidiary/brand  
**Status:** verified_current_chain  
**Evidence:** A — S145, S055, S056  
**Local wording:** national branch  

## Massey Services

**Chain:** Massey Services → Massey family / Tony Massey  
**Category:** Pest control  
**Owner type:** Founder/family/local ownership  
**Interest:** family control stated by current company  
**Status:** verified_current_chain  
**Evidence:** A — S159, S160  
**Local wording:** family owned  

## Natran Green Pest Control

**Chain:** Natran Green Pest Control → Gordon Doran  
**Category:** Pest control  
**Owner type:** Founder/family/local ownership  
**Interest:** founder/owner/CEO identified  
**Status:** verified_current_chain  
**Evidence:** A — S161  
**Local wording:** locally founded  

## Orkin

**Chain:** Orkin → Rollins, Inc.  
**Category:** Pest control  
**Owner type:** Public-company owned  
**Interest:** wholly owned public-company brand/subsidiary  
**Status:** verified_current_chain  
**Evidence:** A — S153, S056  
**Local wording:** national branch  

## Pest Wranglers

**Chain:** Pest Wranglers → Wranglers Service Group, Inc. → Local owners; individual controller unresolved  
**Category:** Pest control  
**Owner type:** Founder/family/local ownership  
**Interest:** local ownership asserted; legal entity lead available  
**Status:** self_reported_local_current  
**Evidence:** C — S151  
**Local wording:** locally owned  

## Ranger Termite & Pest Control

**Chain:** Ranger Termite & Pest Control → Ranger Termite & Pest Control, Inc. → Current controller unresolved due conflicting owner/president references  
**Category:** Pest control  
**Owner type:** Private/control unresolved  
**Interest:** operating company current; equity conflict unresolved  
**Status:** unresolved_control_conflict  
**Evidence:** D — S156, S157  
**Local wording:** local operating history only  

## Roberts Termite & Pest Control

**Chain:** Roberts Termite & Pest Control → Roberts family / local owners  
**Category:** Pest control  
**Owner type:** Founder/family/local ownership  
**Interest:** family ownership asserted; exact equity holders not public  
**Status:** self_reported_local_current  
**Evidence:** C — S165  
**Local wording:** family owned  

## Romney Pest Control

**Chain:** Romney Pest Control → Greg Romney and family  
**Category:** Pest control  
**Owner type:** Founder/family/local ownership  
**Interest:** founder/family ownership stated  
**Status:** verified_local_owner  
**Evidence:** B — S150  
**Local wording:** locally owned  

## Stride Pest Control

**Chain:** Stride Pest Control → Stride Pest Control, LLC → Tyson Kearns  
**Category:** Pest control  
**Owner type:** Founder/family/local ownership  
**Interest:** owner and legal entity identified in current company material  
**Status:** verified_current_chain  
**Evidence:** A — S152  
**Local wording:** locally owned  

## Terminix

**Chain:** Terminix → Terminix / Rentokil North America → Rentokil Initial plc  
**Category:** Pest control  
**Owner type:** Public-company owned  
**Interest:** completed strategic acquisition  
**Status:** verified_current_chain  
**Evidence:** A — S154, S057  
**Local wording:** national branch  

## X Out Pest Services

**Chain:** X Out Pest Services → X Out Pest Services, LLC → Dewey Petersen  
**Category:** Pest control  
**Owner type:** Founder/family/local ownership  
**Interest:** managing member identified  
**Status:** verified_local_owner  
**Evidence:** B — S162, S163  
**Local wording:** local operator  

## Anderson Roofing & Construction

**Chain:** Anderson Roofing & Construction → Anderson family / local owners  
**Category:** Roofing and exterior  
**Owner type:** Founder/family/local ownership  
**Interest:** family ownership asserted; exact current equity holders not public  
**Status:** self_reported_local_current  
**Evidence:** C — S124  
**Local wording:** family owned and operated  

## Austin Roofing and Construction

**Chain:** Austin Roofing and Construction → Current controlling partners unresolved  
**Category:** Roofing and exterior  
**Owner type:** Private/control unresolved  
**Interest:** current private partnership verified; control allocation unavailable  
**Status:** unresolved_control  
**Evidence:** D — S127  
**Local wording:** local office; ownership not inferred  

## Hall Roofing & Construction

**Chain:** Hall Roofing & Construction → Erik Hall  
**Category:** Roofing and exterior  
**Owner type:** Founder/family/local ownership  
**Interest:** owner/leader identified in current company materials  
**Status:** verified_local_owner  
**Evidence:** B — S120  
**Local wording:** local owner-operated  

## Ja-Mar Roofing & Sheet Metal

**Chain:** Ja-Mar Roofing & Sheet Metal → Roofing Services Solutions → Dunes Point Capital  
**Category:** Roofing and exterior  
**Owner type:** Sponsor-backed platform  
**Interest:** acquired by sponsor-backed platform  
**Status:** verified_current_chain  
**Evidence:** A — S047, S045, S046  
**Local wording:** retained Austin brand; current site also uses local-owner wording  
**Note:** The current “local owners” wording is treated as management/operating language unless the company documents a post-transaction equity structure.  

## Kidd Roofing

**Chain:** Kidd Roofing → D.R. Kidd Company, Inc. → Current controller unresolved  
**Category:** Roofing and exterior  
**Owner type:** Private/control unresolved  
**Interest:** executive identity available; equity control not established  
**Status:** unresolved_control  
**Evidence:** C — S118, S119  
**Local wording:** private-company history; no ownership conclusion  

## Longhorn Roofing

**Chain:** Longhorn Roofing → Tom Green  
**Category:** Roofing and exterior  
**Owner type:** Founder/family/local ownership  
**Interest:** current owner/leader identified  
**Status:** verified_local_owner  
**Evidence:** B — S123  
**Local wording:** locally owned  

## RoofCrafters

**Chain:** RoofCrafters → RoofCrafters, Inc. → Family/local ownership asserted; exact controller unresolved  
**Category:** Roofing and exterior  
**Owner type:** Founder/family/local ownership  
**Interest:** current entity and local/family claim; cap table unavailable  
**Status:** self_reported_local_current  
**Evidence:** C — S121, S122  
**Local wording:** family-owned / locally based  

## Silver Creek Exterior & Construction

**Chain:** Silver Creek Exterior & Construction → Local owners; identities unresolved  
**Category:** Roofing and exterior  
**Owner type:** Founder/family/local ownership  
**Interest:** local ownership asserted; exact owners not established  
**Status:** self_reported_local_current  
**Evidence:** C — S125  
**Local wording:** locally owned  

## Wilson Roofing

**Chain:** Wilson Roofing → Current controller unresolved  
**Category:** Roofing and exterior  
**Owner type:** Private/control unresolved  
**Interest:** current operation verified; no publication-grade controller evidence  
**Status:** unresolved_control  
**Evidence:** D — S126  
**Local wording:** none relied upon  
