# Final Adversarial Review

## 1. Does every mapped brand currently serve Austin?

Yes for the 67-brand active denominator based on a current official branch, office, territory or service-area source. Historical, candidate and excluded rows are outside the denominator. Daniel’s remains visibly flagged for consumer-brand activity conflict.

## 2. Is every current owner current as of the snapshot date?

No owner is presented as settled when the current controller is unresolved. Eleven brands are in the unresolved-control bucket. Service Wizard’s ultimate sponsor is pending/unresolved.

## 3. Have pending transactions been labeled pending?

Yes. Blackstone-Champions and Apollo-Apex remain pending and do not replace current owners.

## 4. Have former sponsors been separated from current sponsors?

Yes. Treaty Oak is historical for Stan’s; Cortec’s former Groundworks majority is separated from its retained minority; historical sellers remain in transactions.

## 5. Are minority investments clearly labeled?

Yes. Wrench, Authority Brands, Groundworks, Aptive and Alta distinguish majority and minority interests. Alta is explicitly non-control minority.

## 6. Are franchises represented correctly?

Yes. Local operator, franchise system and franchisor owner are separate nodes. KKR and Apax are not presented as direct owners of local franchisees.

## 7. Are locally managed and locally owned separated?

Yes. Local, family, founder, management and operating language have separate fields and notes.

## 8. Does every major claim have adequate evidence?

Major platform and transaction claims use direct current or transaction sources. A/B/C/D ratings expose weaker rows. Every relationship has source IDs and an evidence note.

## 9. Are any sources duplicates of the same press release?

The source ledger assigns independence groups. Syndicated or copied releases count as one evidence family.

## 10. Are any percentages using an incomplete denominator?

All publication percentages state the 67-brand active denominator. The census limitation is disclosed.

## 11. Does any sentence imply market share without market-share data?

No. The article repeatedly defines the figures as brand-record shares and rejects market-share language.

## 12. Does any sentence suggest causation without evidence?

No causal claims about price, service, employment or customer outcomes are made.

## 13. Have all unresolved cases been disclosed?

Yes. `master_unresolved.csv` contains 25 questions and `master_conflicts.csv` contains 20 conflicts.

## 14. Could a company reasonably object that its ownership was mischaracterized?

The most likely objections concern local-language interpretation, franchise boundaries, pending sponsor transitions and self-reported family ownership. Those cases are qualified, sourced and open to correction rather than stated as absolute facts.

## 15. Can a reader independently reproduce the central findings?

Yes. Filter `master_brands.csv` to the active denominator, count owner types, join relationships to entities, and open the evidence IDs in the source ledger. The methodology gives the steps.
