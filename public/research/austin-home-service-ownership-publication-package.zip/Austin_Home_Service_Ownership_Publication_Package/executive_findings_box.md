# Executive Findings Box

**67 active Austin-facing consumer brands, July 26, 2026**

- **14 (20.9%)** sit in sponsor-backed operating platforms.
- **4 (6.0%)** have public-company parents.
- **5 (7.5%)** are local franchise operators; the franchisor’s owner is not treated as the local operator’s owner.
- **32 (47.8%)** are coded to founder, family or local ownership based on named-owner evidence or a current claim.
- **1 (1.5%)** is minority-invested but founder-controlled: Alta Pest Control.
- **11 (16.4%)** remain private/control unresolved.
- **48 of 67 (71.6%)** have A/B current ownership structures and are not coded unresolved.
- **11** established consumer names remain visible after a transaction.

*All percentages use the 67-brand reconstructed publication universe. They are not market share.*
