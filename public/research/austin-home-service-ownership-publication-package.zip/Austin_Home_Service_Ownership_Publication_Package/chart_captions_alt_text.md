# Suggested Chart Captions and Factual Alt Text

## 1. Owner-type distribution

**Caption:** Owner classification for 67 active Austin-facing home-service consumer brands as of July 26, 2026. The counts describe brand records, not revenue or market share.

**Alt text:** Horizontal bars show 32 founder, family or local-ownership records; 14 sponsor-backed platform brands; 11 private companies with unresolved control; 5 local franchise operators; 4 public-company-owned brands; and 1 minority-invested founder-controlled brand.

## 2. Active brands by service sector

**Caption:** Active consumer-brand records in the reconstructed Austin publication universe by primary service sector.

**Alt text:** Four bars show 26 HVAC, plumbing and bundled electrical brands; 20 pest-control brands; 12 foundation-repair brands; and 9 roofing or exterior-service brands.

## 3. Current Austin brand clusters

**Caption:** Selected current multi-brand or shared-parent clusters. Franchise associations are labeled separately from direct ownership.

**Alt text:** Southern Home Services connects Fox, Precision and Daniel’s to Gryphon. SAS Service Partners connects Austin Air Conditioning and Roger’s Plumbing to Storr Group. Rollins connects Orkin and HomeTeam. Neighborly connects three local franchise brands to KKR at the franchisor level.

## 4. Acquisition and investment timeline

**Caption:** Selected completed and pending transactions affecting Austin-facing home-service brands. Pending agreements do not replace current owners.

**Alt text:** A timeline from 2008 to 2026 includes Rollins-HomeTeam, Brookfield-Enercare, Southern’s Austin acquisitions, KKR-Groundworks, SAS’s Austin acquisitions, Dunes Point-Ja-Mar, Citation-Aptive, and the pending Blackstone-Champions agreement.

## 5. Evidence-status distribution

**Caption:** Evidence rating for the 67 active brand records.

**Alt text:** The chart shows 27 A-rated records, 21 B-rated records, 9 C-rated records and 10 D-rated records. A and B indicate publication-grade or strongly supported structures; C is qualified; D is unresolved.

## 6. Example mobile ownership chain

**Caption:** Mr. Rooter Plumbing of Austin demonstrates why the local franchisee must be separated from the franchisor and its sponsor.

**Alt text:** The chain runs from Mr. Rooter Plumbing of Austin to a locally owned Austin franchisee, then separately to the Neighborly franchise system and KKR. A note states that KKR does not directly own the Austin operating company based on the evidence reviewed.
